﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UHFDemo
{
    public partial class IceTestSetting : Form
    {
        public int IceTestCnt = 0;
        public IceTestSetting()
        {
            InitializeComponent();
        }

        private void btn_Ice_OK_Click(object sender, EventArgs e)
        {
            IceTestCnt = int.Parse(tb_Ice_Total.Text);
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btn_Ice_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void IceTestSetting_Load(object sender, EventArgs e)
        {
            tb_Ice_Total.Text = "" + IceTestCnt;
        }
    }
}
