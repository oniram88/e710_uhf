﻿namespace UHFDemo
{
    partial class IceTestSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tb_Ice_Total = new System.Windows.Forms.TextBox();
            this.btn_Ice_OK = new System.Windows.Forms.Button();
            this.btn_Ice_Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "测试标签总数：";
            // 
            // tb_Ice_Total
            // 
            this.tb_Ice_Total.Location = new System.Drawing.Point(148, 45);
            this.tb_Ice_Total.Name = "tb_Ice_Total";
            this.tb_Ice_Total.Size = new System.Drawing.Size(118, 21);
            this.tb_Ice_Total.TabIndex = 1;
            this.tb_Ice_Total.Text = "0";
            // 
            // btn_Ice_OK
            // 
            this.btn_Ice_OK.Location = new System.Drawing.Point(64, 156);
            this.btn_Ice_OK.Name = "btn_Ice_OK";
            this.btn_Ice_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_Ice_OK.TabIndex = 2;
            this.btn_Ice_OK.Text = "确认";
            this.btn_Ice_OK.UseVisualStyleBackColor = true;
            this.btn_Ice_OK.Click += new System.EventHandler(this.btn_Ice_OK_Click);
            // 
            // btn_Ice_Cancel
            // 
            this.btn_Ice_Cancel.Location = new System.Drawing.Point(278, 156);
            this.btn_Ice_Cancel.Name = "btn_Ice_Cancel";
            this.btn_Ice_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Ice_Cancel.TabIndex = 3;
            this.btn_Ice_Cancel.Text = "取消";
            this.btn_Ice_Cancel.UseVisualStyleBackColor = true;
            this.btn_Ice_Cancel.Click += new System.EventHandler(this.btn_Ice_Cancel_Click);
            // 
            // IceTestSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 247);
            this.Controls.Add(this.btn_Ice_Cancel);
            this.Controls.Add(this.btn_Ice_OK);
            this.Controls.Add(this.tb_Ice_Total);
            this.Controls.Add(this.label1);
            this.Name = "IceTestSetting";
            this.Text = "冰柜测试设置";
            this.Load += new System.EventHandler(this.IceTestSetting_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_Ice_Total;
        private System.Windows.Forms.Button btn_Ice_OK;
        private System.Windows.Forms.Button btn_Ice_Cancel;
    }
}