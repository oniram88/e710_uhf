﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.ExceptionServices;
using System.Threading;
using System.Windows.Forms;

namespace UHFDemo
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        [HandleProcessCorruptedStateExceptions]
        static void Main()
        {
            try
            {
                //设置应用程序处理异常方式：ThreadException处理
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                //处理UI线程异常
                Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
                //处理非UI线程异常
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);


                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                Application.Run(new DemoMain());
            }
            catch (Exception ex)
            {
                LogUnhandledException(ex.Message + Environment.NewLine + ex.StackTrace);
            }



        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            LogUnhandledException(e.ExceptionObject.ToString());
        }

        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            LogUnhandledException(e.Exception.Message +  Environment.NewLine + e.Exception.StackTrace);
        }

        static void LogUnhandledException(string msg)
        {
            StreamWriter sw = new StreamWriter(Application.StartupPath + "\\record.txt", true);
            sw.WriteLine(DateTime.Now.ToString());
            sw.WriteLine(msg);
            sw.Close();
        }
    }
}