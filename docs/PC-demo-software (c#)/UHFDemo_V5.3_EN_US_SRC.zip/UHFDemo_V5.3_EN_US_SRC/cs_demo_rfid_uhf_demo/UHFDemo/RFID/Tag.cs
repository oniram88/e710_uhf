﻿using RFID_API_ver1;
using System;

namespace UHFDemo
{
    #region Tag
    public enum TagVendor
    {
        NormalTag = 0x00,
        JoharTag_1 = 0x10,
        AsTag = 0x20,
        AlTogether = 0x80,
    }
    #endregion Tag
}