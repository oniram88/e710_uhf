﻿using RFID_API_ver1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDKTest
{
    public partial class Form1 : Form
    {
        private Reader reader;
        private ReaderType readerType = ReaderType.SERIAL;
        private Channels channels = Channels.One;
        private List<Antenna> antList = null;
        public enum HistoryType
        {
            Normal = 0x00,          //  Color.Indigo
            Success = 0x01,         //  Color.blue
            Failed = 0x02,          //  Color.red
        }
        public Form1()
        {

            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");//en
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshComPorts();
            cmbBaudrate.SelectedIndex = 0;
            antList = new List<Antenna>();
            antType1.Checked = true;
        }

        private void RefreshComPorts()
        {
            cmbComPort.Items.Clear();
            string[] portNames = SerialPort.GetPortNames();
            if (portNames != null && portNames.Length > 0)
            {
                cmbComPort.Items.AddRange(portNames);
            }
            cmbComPort.SelectedIndex = cmbComPort.Items.Count - 1;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string arg1 = string.Empty;
            int arg2 = 0;

            if (btnConnect.Text.Equals("Connect"))
            {
                readerType = ReaderType.SERIAL;
                arg1 = cmbComPort.Text.Trim();
                arg2 = Convert.ToInt32(cmbBaudrate.Text);

                reader = Reader.Create(readerType, channels, arg1, arg2);
                reader.MessageTransport += PrintTransportLog;
                reader.ExceptionReceived += Reader_ExceptionReceived;
                reader.FirmwareVersionCallback += ReshFirmwareVersion;
                reader.FrequencyCallback += Reader_FrequencyCallback;
                reader.SettingStatusCallback += Reader_SettingStatusCallback;
                reader.GpioPinsCallback += Reader_GpioPinsCallback;
                reader.Connect();

                btnConnect.Text = "DisConnect";

                Thread.Sleep(5);
                reader.GetFrequencyRegion();

                groupBox24.Enabled = false;
            }
            else if (btnConnect.Text.Equals("DisConnect")) 
            {
                reader.MessageTransport -= PrintTransportLog;
                reader.ExceptionReceived -= Reader_ExceptionReceived;
                reader.FirmwareVersionCallback -= ReshFirmwareVersion;
                reader.FrequencyCallback -= Reader_FrequencyCallback;
                reader.SettingStatusCallback -= Reader_SettingStatusCallback;
                reader.GpioPinsCallback -= Reader_GpioPinsCallback;
                

                reader.Disconnect();
                reader = null;
                btnConnect.Text = "Connect";
                Thread.Sleep(5);

                groupBox24.Enabled = true;
            }


        }

        private void Reader_GpioPinsCallback(object sender, GpioPinsEventArgs e)
        {
            BeginInvoke(new ThreadStart(delegate ()
            {
                foreach (GpioPin gpi in e.gpios)
                {
                    if (gpi.ID == 1)
                    {
                        if (gpi.High)
                        {
                            rdbGpio1High.Checked = true;
                        }
                        else
                        {
                            rdbGpio1Low.Checked = true;
                        }
                    }
                    else if (gpi.ID == 2)
                    {
                        if (gpi.High)
                        {
                            rdbGpio2High.Checked = true;
                        }
                        else
                        {
                            rdbGpio2Low.Checked = true;
                        }
                    }
                }
            }));
        }

        private void Reader_SettingStatusCallback(object sender, SettingEventArgs e)
        {
            
        }

        private void Reader_FrequencyCallback(object sender, FreqEventArgs e)
        {
            
        }

        private void ReshFirmwareVersion(object sender, FirmwareVersionEventArgs e)
        {
            BeginInvoke(new ThreadStart(delegate ()
            {
                string fwVer = string.Format("{0:x2}.{1:x2}", e.Info.Major, e.Info.Minor);
                txtFirmwareVersion.Text = fwVer;
                RecordOpHistory(HistoryType.Normal, string.Format("Chip Type：{0}", e.Info.Chip));
            }));
        }

        private void Reader_ExceptionReceived(object sender, ExceptionReceivedEventArgs e)
        {
            
        }

        private void PrintTransportLog(object sender, MessageTransportEventArgs e)
        {
            string strLog = string.Format("{0:5}: {1}", (e.Tx ? "Send" : "Recv"), ByteUtils.ToHex(e.TransportData, "", " "));
            HistoryType flag = (e.Tx ? HistoryType.Success : HistoryType.Failed);
            WriteLog(lrtxtLog, strLog, flag);
            Thread.Sleep(1);
        }

        private void btnGetFirmwareVersion_Click(object sender, EventArgs e)
        {
            try
            {
                txtFirmwareVersion.Text = "";
                RecordOpHistory(HistoryType.Normal, "Firmware version");
                reader.GetFirmwareVersion();

            }
            catch (Exception ex)
            {

            }
        }

        public void RecordOpHistory(HistoryType type, string strLog)
        {
            WriteLog(lrtxtLog, strLog, type);
        }

        public void WriteLog(RichTextBox logRichTxt, string strLog, HistoryType nType)
        {
            logRichTxt.BeginInvoke(new ThreadStart((MethodInvoker)delegate () {
                if (nType == HistoryType.Normal)
                {
                    logRichTxt.AppendText(string.Format("\r\n{0} {1}", DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff"), strLog));
                    logRichTxt.SelectionColor = Color.Indigo;
                }
                else if (nType == HistoryType.Success)
                {
                    logRichTxt.AppendText(string.Format("\r\n{0} {1}", DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff"), strLog));
                    logRichTxt.SelectionColor = Color.Blue;
                }
                else if (nType == HistoryType.Failed)
                {
                    logRichTxt.AppendText(string.Format("\r\n{0} {1}", DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss.fff"), strLog));
                    logRichTxt.SelectionColor = Color.Red;
                }

                logRichTxt.Select(logRichTxt.TextLength, 0);
                logRichTxt.ScrollToCaret();
            }));
        }

        private void btnSetWorkAntenna_Click(object sender, EventArgs e)
        {

        }

        private void btnGetWorkAntenna_Click(object sender, EventArgs e)
        {

        }

        private void btnReadGpioValue_Click(object sender, EventArgs e)
        {
            try
            {
                RecordOpHistory(HistoryType.Normal, "Get the Gpio level");
                reader.ReadGpioValue();
            }
            catch (Exception ex)
            {

            }
        }

        private void btnWriteGpio3Value_Click(object sender, EventArgs e)
        {
            try
            {
                GpioPin gpo = new GpioPin(3, false);
                if (rdbGpio3High.Checked == true)
                {
                    gpo.High = true;
                }
                else if (rdbGpio3Low.Checked == true)
                {
                    gpo.High = false;
                }
                else
                {
                    MessageBox.Show("Select the output level of the GPIO first");
                    return;
                }
                RecordOpHistory(HistoryType.Normal, string.Format("WriteGPIO {1}", gpo));
                reader.WriteGpioValue(gpo);
            }
            catch (Exception ex)
            {

            }
        }

        private void btnWriteGpio4Value_Click(object sender, EventArgs e)
        {
            try
            {
                GpioPin gpo = new GpioPin(4, false);
                if (rdbGpio4High.Checked == true)
                {
                    gpo.High = true;
                }
                else if (rdbGpio4Low.Checked == true)
                {
                    gpo.High = false;
                }
                else
                {
                    MessageBox.Show("Select the output level of the GPIO first");
                    return;
                }
                RecordOpHistory(HistoryType.Normal, string.Format("写GPIO {1}", gpo.ToString()));
                reader.WriteGpioValue(gpo);
            }
            catch (Exception ex)
            {

            }
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {

            if (btnInventory.Text == "Inventory")
            {
                btnInventory.Text = "Stop";

                InventoryCfg inventoryCfg = null;
                List<InventoryAntenna> list = new List<InventoryAntenna>();

                switch (channels)
                {
                    case Channels.One:
                        {
                            //单天线盘存配置实例（天线1进行盘存）
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 0), 0));
                            inventoryCfg = new CustomizedSessionTargetInventoryCfg(list, Session.S1, Target.A, 1);
                            inventoryCfg.ExecuteTime = -1;
                            inventoryCfg.CmdInterval = 0;
                        }
                        break;
                    case Channels.Eight:
                        {
                            //多天线盘存存配置实例
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 0), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 1), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 2), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 3), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 4), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 5), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 6), 1));
                            list.Add(new InventoryAntenna((Antenna)Enum.ToObject(typeof(Antenna), 7), 1));

                            inventoryCfg = new FastSwitchAntInventoryCfg(list, 0, 1);
                        }
                        break;
                }
                //盘存
                reader.TagRead += Reader_TagRead;
                reader.CommandStatistics += Reader_CommandStatistics;
                reader.setInventoryCfg(inventoryCfg);
                reader.StartReading();
            }
            else
            {
                btnInventory.Text = "Inventory";
                reader.StopReading();

            }

        }

        private void Reader_TagRead(object sender, TagReadDataEventArgs e)
        {
            //Inventory data is returned via TagReadDataEventArgs;
            BeginInvoke(new ThreadStart(delegate ()
            {
                
            }));
        }

        private void Reader_CommandStatistics(object sender, CommandstatisticsEventArgs e)
        {
            //After triggering, it means that the current inventory has ended;
            BeginInvoke(new ThreadStart(delegate ()
            {
                reader.TagRead -= Reader_TagRead;
                reader.CommandStatistics -= Reader_CommandStatistics;
                txtCmdTagCount.Text = String.Format("{0}", e.RoundTotalRead);
            }));
        }

        private void antType_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton btn = (RadioButton)sender;
            if (!btn.Checked)
                return;
            switch (btn.Name)
            {
                case "antType1":
                    channels = Channels.One;
                    break;
                case "antType8":
                    channels = Channels.Eight;
                    break;
            }

            antList.Clear();
            antList.Add(Antenna.Ant1);
            if ((int)channels > 1)
            {
                antList.Add(Antenna.Ant2);
                antList.Add(Antenna.Ant3);
                antList.Add(Antenna.Ant4);
            }
            if ((int)channels > 4)
            {
                antList.Add(Antenna.Ant5);
                antList.Add(Antenna.Ant6);
                antList.Add(Antenna.Ant7);
                antList.Add(Antenna.Ant8);
            }
        }
    }
}
