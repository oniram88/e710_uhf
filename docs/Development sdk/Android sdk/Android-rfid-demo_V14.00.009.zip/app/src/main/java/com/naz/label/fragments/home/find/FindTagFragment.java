package com.naz.label.fragments.home.find;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.base.BaseDialogFragment;
import com.naz.label.fragments.home.inventory.InventoryTagFragment;
import com.naz.label.util.ToastUtils;
import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseFragment;
import com.naz.label.databinding.FragmentFindTagBinding;
import com.naz.label.util.BeeperHelper;
import com.naz.label.util.ReaderHelper;
import com.naz.label.widget.ConvenientSeekBar;
import com.naz.label.util.XLog;
import com.payne.reader.Reader;
import com.payne.reader.base.BaseInventory;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.AntennaCount;
import com.payne.reader.bean.config.ClearMaskId;
import com.payne.reader.bean.config.Cmd;
import com.payne.reader.bean.config.MaskAction;
import com.payne.reader.bean.config.MaskId;
import com.payne.reader.bean.config.MaskTarget;
import com.payne.reader.bean.config.MemBank;
import com.payne.reader.bean.config.Session;
import com.payne.reader.bean.config.Target;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.InventoryTag;
import com.payne.reader.bean.receive.InventoryTagEnd;
import com.payne.reader.bean.receive.OutputPower;
import com.payne.reader.bean.receive.Success;
import com.payne.reader.bean.send.InventoryConfig;
import com.payne.reader.bean.send.InventoryParam;
import com.payne.reader.bean.send.MaskConfig;
import com.payne.reader.util.CheckUtils;

import java.lang.ref.WeakReference;

public class FindTagFragment extends BaseDialogFragment<FragmentFindTagBinding> {
    private static FindTagFragment sFragment;
    private boolean mInitOK;
    /**
     * param
     */
    private volatile InventoryParam mParam;
    /**
     * is running
     */
    private volatile boolean mRunning;

    private InnerHandler mHandler;

    /**
     * last used hex string
     */
    private volatile String mLastHexStr;
    /**
     * last update's timestamp
     */
    private long mLastMs;

    private Consumer<byte[]> mConsumer = new Consumer<byte[]>() {
        @Override
        public void accept(byte[] bytes) throws Exception {
            long ms = System.currentTimeMillis();
            if (ms - mLastMs > 100) {
                int p = binding.barVp.getProgress();
                binding.barVp.setProgress(p - 2);
            }
        }
    };
    private Consumer<Success> successConsumer = success -> {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ToastUtils.makeText(binding.getRoot(), getString(R.string.set_success), Toast.LENGTH_SHORT).show();
                }
            });
        }
    };
    private Consumer<Failure> failureConsumer = new Consumer<Failure>() {
        @Override
        public void accept(Failure failure) throws Exception {
            FragmentActivity activity = getActivity();
            if (activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastUtils.makeText(binding.getRoot(), getString(R.string.set_error), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    };
    private ConvenientSeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new ConvenientSeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(ConvenientSeekBar seekBar, int progress, boolean fromUser) {

        }

        @Override
        public void onStartTrackingTouch(ConvenientSeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(ConvenientSeekBar seekBar) {
            int progress = seekBar.getProgress();
            /*这里需要设置为临时功率，掉电会恢复原值, 此处不要用另一个方法设置功率，容易损坏flash*/
            Reader reader = ReaderHelper.getReader();
            reader.setOutputPowerUniformly((byte) progress, successConsumer, failureConsumer);
        }
    };

    public FindTagFragment() {
        sFragment = this;
    }

    public static FindTagFragment get() {
        return sFragment;
    }

    @Override
    protected FragmentFindTagBinding getViewBinding() {
        return FragmentFindTagBinding.inflate(getLayoutInflater());
    }

    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        InventoryTagFragment fragment = InventoryTagFragment.get();
        if (fragment != null && fragment.mSelectedEPC != null) {
            binding.etAddress.setText(fragment.mSelectedEPC.split("\n")[0]);
            fragment.mSelectedEPC = null;
        }
        binding.csb.setMax(GlobalCfg.get().getMaxOutPower());
        binding.btnSet.setOnClickListener(v -> {
            startStop(!mRunning);
        });
        Reader reader = ReaderHelper.getReader();
        reader.addOriginalDataReceivedCallback(mConsumer);

        reader.getOutputPower(new Consumer<OutputPower>() {
            @Override
            public void accept(OutputPower outputPower) throws Exception {
                byte[] powers = outputPower.getOutputPower();

                FragmentActivity activity = getActivity();
                if (activity != null) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (powers.length > 0) {
                                binding.csb.setProgress(powers[0]);
                            }
                        }
                    });
                }
            }
        }, null);

        binding.csb.setOnSeekBarChangeListener(onSeekBarChangeListener);
    }

    private void setInventoryConfig() {
        if (mHandler == null) {
            mHandler = new InnerHandler(this);
        }
        if (mParam == null) {
            mParam = new InventoryParam();
            mParam.setAntennaCount(AntennaCount.SINGLE_CHANNEL);
            mParam.setSession(Session.S0);
            mParam.setTarget(Target.B);
            mParam.setLoopCount(-1);
        }
        BaseInventory inventory = mParam.getInventory();

        InventoryConfig config = new InventoryConfig.Builder()
                .setInventoryParam(mParam)
                .setInventory(inventory)
                .setOnInventoryTagSuccess((Consumer<InventoryTag>) mHandler)
                .setOnInventoryTagEndSuccess(new Consumer<InventoryTagEnd>() {
                    @Override
                    public void accept(InventoryTagEnd inventoryTagEnd) throws Exception {
                        if (inventoryTagEnd.isFinished()) {
                            XLog.w("inventoryTagEnd.isFinished()");
                            return;
                        }
                        Reader reader = ReaderHelper.getReader();
                        reader.startInventory();/*onEnd*/
                    }
                })
                .setOnFailure((failure) -> {
                    Reader reader = ReaderHelper.getReader();
                    reader.startInventory();/*OnFailure*/
                })
                .build();
        Reader reader = ReaderHelper.getReader();
        reader.setInventoryConfig(config);
    }

    public void startStop(boolean start) {
        if (start) {
            if (mRunning) {
                XLog.w("Ignore.Search is running...");
                return;
            }
            String hexMaskValue = binding.etAddress.getText().toString().trim().replace(" ", "");
            if (CheckUtils.isNotHexString(hexMaskValue)) {
                binding.etAddress.setError(getString(R.string.must_input_hexadecimal_string));
                binding.etAddress.requestFocus();
                return;
            }
            XLog.i("Start Find:" + hexMaskValue);

            Reader reader = ReaderHelper.getReader();
            if (!mInitOK) {
                reader.stopInventory();
                setInventoryConfig();
                mInitOK = true;
            }
            setCancelable(false);
            mRunning = true;
            binding.btnSet.setText(getString(R.string.stop));

            if (hexMaskValue.equals(mLastHexStr)) {
                reader.startInventory();/*equals*/
            } else {
                MaskId maskId = MaskId.TAG_MASK_NO1;
                MaskTarget maskTarget = MaskTarget.Inventoried_S0;
                MaskAction action = MaskAction.Action4;
                MemBank memBank = MemBank.EPC;
                byte startAddress = 32;
                int length = hexMaskValue.length() * 4;
                byte selectLength = (byte) length;

                MaskConfig config = new MaskConfig.Builder()
                        .setFunction(maskId)
                        .setTarget(maskTarget)
                        .setAction(action)
                        .setMemBank(memBank)
                        .setMaskBitStartAddress(startAddress)
                        .setMaskBitLength(selectLength)
                        .setMaskValue(hexMaskValue)
                        .build();
                reader.setTagMask(config, success -> {
                            mLastHexStr = hexMaskValue;
                            reader.startInventory();/*setTagMask ok*/
                        }, failure -> {
                            mLastHexStr = null;
                            promptUi(getString(R.string.filter_tag_error));
                        }
                );
            }
        } else if (mRunning) {
            setCancelable(true);
            mRunning = false;
            binding.btnSet.setText(getString(R.string.search_tags));
            binding.barVp.setProgress(0);
            ReaderHelper.getReader().stopInventory();

            mHandler.removeCallbacksAndMessages(null);
        }
    }

    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }
        activity.runOnUiThread(() -> {
            ToastUtils.makeText(getView().findViewById(R.id.cl), msg, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.getRoot().setKeepScreenOn(true);
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.getRoot().setKeepScreenOn(false);
        startStop(false);
    }

    @Override
    public void onDestroy() {
        mInitOK = false;
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }

        Reader reader = ReaderHelper.getReader();
        reader.removeCallback(Cmd.SET_TEMPORARY_OUTPUT_POWER);
        reader.removeOriginalDataReceivedCallback(mConsumer);
        if (mLastHexStr != null) {
            reader.clearTagMask(ClearMaskId.TAG_MASK_NO1, null, null);
        }
        sFragment = null;
        super.onDestroy();
    }

    private static class InnerHandler extends Handler implements Consumer<InventoryTag> {
        private final int MSG_REFRESH = 0;
        private WeakReference<FindTagFragment> mWeakReference;
        private boolean mEnableBeep = true;

        private long mLastPerBeepMs;
        private long mBeepInterval = 200;

        public InnerHandler(FindTagFragment fragment) {
            mWeakReference = new WeakReference<>(fragment);
        }

//        int min;
//        int max;

        @Override
        public void accept(InventoryTag inventoryTag) throws Exception {
            int rssi = inventoryTag.getRssi();
//            if (min > rssi) {
//                min = rssi;
//            }
//            if (max < rssi) {
//                max = rssi;
//            }
//            XLog.i("rssi->" + inventoryTag + "\n" + min + "," + max);

            Message msg = Message.obtain();
            msg.what = MSG_REFRESH;
            msg.obj = rssi;
            sendMessage(msg);
        }

        @Override
        public void handleMessage(@NonNull Message msg) {
            FindTagFragment fragment = mWeakReference.get();
            if (fragment == null || fragment.isRemoving() || fragment.binding == null) {
                return;
            }
            switch (msg.what) {
                case MSG_REFRESH: {
                    if (!fragment.mRunning) {
                        fragment.binding.barVp.setProgress(0);
                    } else {
                        fragment.mLastMs = System.currentTimeMillis();
                        Integer rssi = (Integer) msg.obj;
//                        XLog.i("rssi = " + rssi);
                        if (rssi != null) {
                            if (mEnableBeep) {
                                if (rssi > -35) {
                                    BeeperHelper.beep(BeeperHelper.SOUND_FILE_TYPE_NORMAL);
                                } else {
                                    long ms = System.currentTimeMillis();
                                    if (ms - mLastPerBeepMs > mBeepInterval) {
                                        mLastPerBeepMs = ms;
                                        BeeperHelper.beep(BeeperHelper.SOUND_FILE_TYPE_NORMAL);
                                    }
                                }
                            }
                            fragment.binding.barVp.setProgress(120 + rssi);
                        }
                    }
                }
                break;
            }
        }
    }
}