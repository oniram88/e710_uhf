package com.naz.label.base;

import android.content.Context;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Space;
import android.widget.Toast;

import androidx.annotation.LayoutRes;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import com.naz.label.util.LanguageUtils;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * base activity
 *
 * @author naz
 * Date 2020/3/30
 */
public abstract class OldBaseActivity extends AppCompatActivity {
    private Unbinder unbinder;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String language = LanguageUtils.getLanguage();
        LanguageUtils.updateLanguage(this, language);
        int resId = getLayoutResId();
        if (resId <= 0) {
            ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            setContentView(new Space(this), lp);
        } else {
            setContentView(resId);
        }
        unbinder = ButterKnife.bind(this);
        initView();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        String language = LanguageUtils.getLanguage();
        Context context = LanguageUtils.updateLanguage(newBase, language);
        super.attachBaseContext(context);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
    }

    /**
     * @param msg 内容
     */
    public void showToast(String msg) {
        if ("main".equalsIgnoreCase(Thread.currentThread().getName())) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } else {
            runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * @param strResId 文字资源Id
     */
    public void showToast(@StringRes int strResId) {
        if ("main".equalsIgnoreCase(Thread.currentThread().getName())) {
            Toast.makeText(this, getString(strResId), Toast.LENGTH_SHORT).show();
        } else {
            runOnUiThread(() -> Toast.makeText(this, getString(strResId), Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * 布局id
     *
     * @return 布局id
     */
    @LayoutRes
    public abstract int getLayoutResId();

    /**
     * 初始化View
     */
    public abstract void initView();
}
