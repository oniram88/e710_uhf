package com.naz.label.acts;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.databinding.ActTempLineChartBinding;
import com.naz.label.fragments.home.temp.TempTag2Fragment;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ShowTempResultChartActivity extends BaseActivity<ActTempLineChartBinding> {
    //    private TextView status;
    private TextView totalNumber;
    private TextView upperLimit;
    private TextView upperLimitNo;
    private TextView lowerLimit;
    private TextView lowerLimitNo;
    private TextView interval;
    private TextView startTime;
    private LineChart lineChart;

    public static void start(Context context) {
        Intent starter = new Intent(context, ShowTempResultChartActivity.class);
        context.startActivity(starter);
    }

    @Override
    protected ActTempLineChartBinding getViewBinding() {
        return ActTempLineChartBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView() {
        lineChart = (LineChart) findViewById(R.id.temperature_display);

//        status = (TextView) findViewById(R.id.rtc_test_status);
        totalNumber = (TextView) findViewById(R.id.rtc_test_total_number);
        upperLimit = (TextView) findViewById(R.id.rtc_test_temp_upper_limit);
        upperLimitNo = (TextView) findViewById(R.id.rtc_test_temp_upper_limit_number);
        lowerLimit = (TextView) findViewById(R.id.rtc_test_temp_lower_limit);
        lowerLimitNo = (TextView) findViewById(R.id.rtc_test_temp_lower_limit_number);
        interval = (TextView) findViewById(R.id.rtc_test_temp_interval);
        startTime = (TextView) findViewById(R.id.rtc_test_temp_start_time);

        int topTemp = TempTag2Fragment.tempUpperLimit;
        int bottomTemp = TempTag2Fragment.tempLowerLimit;
        int intervalMs = TempTag2Fragment.measInterval;
        int measCount = TempTag2Fragment.measCount;
        long timeStamp = TempTag2Fragment.timeStamp;

        List<Entry> rawData = new ArrayList<>();
        float max = 0;
        float min = 0;
        int overMaxCount = 0;
        int overMinCount = 0;

        int size = TempTag2Fragment.mList.size();
        for (int i = 0; i < size; i++) {
            float temp = TempTag2Fragment.mList.get(i);
            rawData.add(new Entry((float) i, temp));

            if (i == 0) {
                max = min = temp;
            } else {
                if (max < temp) {
                    max = temp;
                }
                if (min > temp) {
                    min = temp;
                }

            }
            if (topTemp < temp) {
                overMaxCount++;
            }
            if (bottomTemp > temp) {
                overMinCount++;
            }
        }
        LineDataSet dataSet = new LineDataSet(rawData, "℃");
        dataSet.setColor(Color.RED);
        dataSet.setCircleColor(Color.BLUE);
        dataSet.setCircleRadius(3);

        LineData lineData = new LineData(dataSet);
        lineChart.setData(lineData);

        ValueFormatter formatter = new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return new DecimalFormat("#.00").format(value);
            }
        };
        lineChart.getAxisLeft().setValueFormatter(formatter);
        lineChart.getAxisRight().setValueFormatter(formatter);
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

        lineChart.notifyDataSetChanged();
        lineChart.invalidate();

//        status.setText(buffer.testingCount != 0 ? "Testing" : "End");
        totalNumber.setText("" + measCount);
        upperLimit.setText(topTemp + "℃");
        lowerLimit.setText(bottomTemp + "℃");
        interval.setText(intervalMs + "S");
        upperLimitNo.setText(overMaxCount + "");
        lowerLimitNo.setText(overMinCount + "");
        startTime.setText(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date(timeStamp)));
    }
}
