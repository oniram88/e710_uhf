package com.naz.label.acts.log;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.databinding.ActivityLogBinding;
import com.naz.label.util.FileUtils;
import com.naz.label.util.XLog;
import com.payne.reader.util.ThreadPool;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.concurrent.Future;

/**
 * @author naz
 */
public class LogActivity extends BaseActivity<ActivityLogBinding> {
    private String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "InventoryTesting-log.txt";

    private LogAdapter mAdapter;
    private File mCrashFile;

    private File mFile;
    private Future<?> mSubmit;

    private InnerHandler mHandler = new InnerHandler(this);

    private CompoundButton.OnCheckedChangeListener ocl = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            switch (buttonView.getId()) {
                case R.id.log: {
                    XLog.enableShowLog(isChecked);
                }
                break;
                case R.id.sdkLog: {
                    XLog.enableSdkLog(isChecked);
                }
                break;
                case R.id.saveLog: {
                    XLog.enableSaveLog(isChecked);
                    if (mAdapter != null) {
                        loadLogs();
                    }
                }
                break;
            }
        }
    };

    public static void start(Context context) {
        Intent starter = new Intent(context, LogActivity.class);
        starter.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
        context.startActivity(starter);
    }

    @Override
    protected ActivityLogBinding getViewBinding() {
        return ActivityLogBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        onNewIntent(getIntent());
    }

    @Override
    public void initView() {
        this.setTitle(R.string.operation_log);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mCrashFile = FileUtils.getCrashFile(this);

        binding.lvLog.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new LogAdapter(this, R.layout.item_act_log);
        binding.lvLog.setAdapter(mAdapter);

        mAdapter.setOnItemLongClickListener((view) -> {
            if (canOperate()) {
                return true;
            }
            mAdapter.toggleMode();
            return true;
        });
        mAdapter.setOnClickListener((view) -> {
            if (canOperate()) {
                return;
            }
            int position = (int) view.getTag();
            if (view.getId() == R.id.btnItemDelLog) {
                delItem(position);
            } else {
                openItem(position);
            }
        });

        binding.log.setEnabled(false);
        binding.sdkLog.setEnabled(false);
        binding.saveLog.setEnabled(false);
        binding.log.setChecked(XLog.sShowLog);
        binding.sdkLog.setChecked(XLog.isShowSDKLog());
        binding.saveLog.setChecked(XLog.isSaveLogToFile());

        binding.text.setOnLongClickListener(new View.OnLongClickListener() {
            int scrollY;

            @Override
            public boolean onLongClick(View v) {
                int sy = binding.llText.getScrollY();
                if (sy == scrollY) {
                    binding.llText.fullScroll(View.FOCUS_UP);
                } else {
                    binding.llText.fullScroll(View.FOCUS_DOWN);
                }
                scrollY = sy;
                return true;
            }
        });
    }

    private boolean canOperate() {
        int taskSize = XLog.getTaskSize();
        if (taskSize > 0) {
            Toast.makeText(this, "日志还在写入，请稍后再试." + taskSize, Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    private void delItem(int position) {
        String str = mAdapter.getData(position);
        if (str == null) {
            return;
        }
        String fileName = str.split("\n")[0];
        File file;
        if (fileName.startsWith("/storage")) {
            file = new File(fileName);
        } else {
            file = new File(FileUtils.getSaveLogDir(this), fileName);
        }
        if (file.delete()) {
            mAdapter.remove(position);
        } else {
            ToastUtils.makeText(binding.lvLog, "删除失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void openItem(int position) {
        String str = mAdapter.getData(position);
        if (str == null) {
            return;
        }
        String name = str.split("\n")[0];
        File file;
        if (name.startsWith("/storage")) {
            file = new File(name);
        } else {
            file = new File(FileUtils.getSaveLogDir(this), name);
        }

        openFile(file);
    }

    private void openFile(File file) {
        binding.pbWait.setVisibility(View.VISIBLE);
        binding.llText.setVisibility(View.VISIBLE);
        mFile = file;
        mSubmit = ThreadPool.submit(mHandler);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri uri = intent.getData();
        if (uri != null) {
            String path = uri.getPath();
            if (path != null) {
                openFile(new File(path));
            }
            XLog.i("uri:" + uri);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadLogs();
    }

    private void loadLogs() {
        String rStorage = Manifest.permission.READ_EXTERNAL_STORAGE;
        String wStorage = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(rStorage) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{rStorage, wStorage}, 666);
                ToastUtils.makeText(binding.getRoot(), "请授予SD卡权限", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        mAdapter.clear();

        if (mCrashFile != null && mCrashFile.exists()) {
            mAdapter.addData(mCrashFile.getAbsolutePath());
        }
        File inverntroyFile = new File(path);
        if (inverntroyFile.exists()) {
            String fileSizeStr = FileUtils.formatFileSize(inverntroyFile.length());
            mAdapter.addData(inverntroyFile + "\n" + fileSizeStr);
        }

        File file = FileUtils.getSaveLogDir(this);
        File[] files = file.listFiles();
        if (files != null && files.length > 0) {
            for (File f : files) {
                String fileSizeStr = FileUtils.formatFileSize(f.length());
                mAdapter.addData(f + "\n" + fileSizeStr);
            }
        }
        StringBuilder sb = new StringBuilder();
        FileUtils.getAvailableAndTotalSpace(sb);
        int taskSize = XLog.getTaskSize();
        String text = sb.append(" Task:")
                .append(taskSize).toString();
        binding.tvSpace.setText(text);

        binding.log.setEnabled(true);
        binding.sdkLog.setEnabled(true);
        binding.saveLog.setEnabled(true);
        binding.log.setOnCheckedChangeListener(ocl);
        binding.sdkLog.setOnCheckedChangeListener(ocl);
        binding.saveLog.setOnCheckedChangeListener(ocl);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        loadLogs();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (binding.pbWait.getVisibility() == View.VISIBLE) {
            binding.pbWait.setVisibility(View.GONE);
            if (mSubmit != null) {
                mSubmit.cancel(true);
            }
            return;
        }
        if (binding.llText.getVisibility() == View.VISIBLE) {
            binding.llText.setVisibility(View.GONE);
            binding.llText.scrollTo(0, 0);
            mFile = null;

            return;
        }
        super.onBackPressed();
    }

    private static class InnerHandler extends Handler implements Runnable {
        private final int MSG_SHOW = 1;
        private final int MSG_ = 2;
        private WeakReference<LogActivity> mWr;

        InnerHandler(LogActivity a) {
            mWr = new WeakReference<>(a);
        }

        @Override
        public void run() {
            LogActivity a = mWr.get();
            if (a == null || a.isFinishing()) {
                return;
            }
            String str = FileUtils.readFile2String(a.mFile, "UTF-8");
            Message message = Message.obtain();
            message.what = MSG_SHOW;
            message.obj = str;
            sendMessage(message);
        }

        @Override
        public void handleMessage(Message msg) {
            LogActivity a = mWr.get();
            if (a == null || a.isFinishing()) {
                return;
            }
            switch (msg.what) {
                case MSG_SHOW:
                    a.binding.text.setText((String) msg.obj);
                    a.binding.pbWait.setVisibility(View.GONE);
                    break;
                case MSG_:
                    break;
                default:
                    break;
            }
        }
    }
}