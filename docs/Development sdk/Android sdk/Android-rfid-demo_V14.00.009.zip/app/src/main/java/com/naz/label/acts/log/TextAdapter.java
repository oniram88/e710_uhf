package com.naz.label.acts.log;

import android.content.Context;
import android.graphics.Color;
import android.view.View;

import com.naz.label.R;
import com.naz.label.adapter.BaseMultiItemRecyclerAdapter;
import com.naz.label.adapter.BaseViewHolder;
import com.naz.label.databinding.ItemActTextBinding;

/**
 *
 */
public class TextAdapter extends BaseMultiItemRecyclerAdapter<String> {
    public TextAdapter(Context context, int baseLayoutResId) {
        super(context, baseLayoutResId);
    }

    @Override
    protected Class<? extends BaseViewHolder<String>> onBindViewTypeToViewHolder(int viewType) {
        return TextViewHolder.class;
    }

    private static class TextViewHolder extends BaseViewHolder<String> {
        private ItemActTextBinding mBinding;

        public TextViewHolder(View view) {
            super(view);
            mBinding = ItemActTextBinding.bind(view);
        }

        @Override
        public void onBindData(int adapterPosition) {
            String text = getData(adapterPosition);
            mBinding.tvTitle.setText(text);
        }
    }
}
