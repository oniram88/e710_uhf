//package com.naz.label.ui.home;
//
//import android.content.Context;
//import android.os.Bundle;
//
//import com.naz.label.util.XLog;
//
//import android.view.View;
//
//import androidx.annotation.IdRes;
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.Fragment;
//import androidx.fragment.app.FragmentManager;
//import androidx.fragment.app.FragmentTransaction;
//import androidx.navigation.NavDestination;
//import androidx.navigation.NavOptions;
//import androidx.navigation.Navigator;
//import androidx.navigation.fragment.FragmentNavigator;
//
//import com.naz.label.util.XLog;
//
//import java.lang.reflect.Field;
//import java.util.ArrayDeque;
//import java.util.List;
//import java.util.Map;
//
///**
// * @author naz
// * Date 2021/1/28
// */
//@Navigator.Name("fragment")
//public class CustomNavigator extends FragmentNavigator {
//    private static final String TAG = "CustomNavigator";
//    private final Context mContext;
//    private final FragmentManager mFragmentManager;
//    private final int mContainerId;
//
//    public CustomNavigator(@NonNull Context context, @NonNull FragmentManager manager, int containerId) {
//        super(context, manager, containerId);
//        mContext = context;
//        mFragmentManager = manager;
//        mContainerId = containerId;
//    }
//
//    @Nullable
//    @Override
//    public NavDestination navigate(@NonNull Destination destination, @Nullable Bundle args, @Nullable NavOptions navOptions, @Nullable Navigator.Extras navigatorExtras) {
//        if (mFragmentManager.isStateSaved()) {
//            XLog.i(TAG, "Ignoring navigate() call: FragmentManager has already saved its state");
//            return null;
//        }
//        String className = destination.getClassName();
//        if (className.charAt(0) == '.') {
//            className = mContext.getPackageName() + className;
//        }
////        final Fragment frag = instantiateFragment(mContext, mFragmentManager,
////                className, args);
////        frag.setArguments(args);
//        final FragmentTransaction ft = mFragmentManager.beginTransaction();
//
//        int enterAnim = navOptions != null ? navOptions.getEnterAnim() : -1;
//        int exitAnim = navOptions != null ? navOptions.getExitAnim() : -1;
//        int popEnterAnim = navOptions != null ? navOptions.getPopEnterAnim() : -1;
//        int popExitAnim = navOptions != null ? navOptions.getPopExitAnim() : -1;
//        if (enterAnim != -1 || exitAnim != -1 || popEnterAnim != -1 || popExitAnim != -1) {
//            enterAnim = enterAnim != -1 ? enterAnim : 0;
//            exitAnim = exitAnim != -1 ? exitAnim : 0;
//            popEnterAnim = popEnterAnim != -1 ? popEnterAnim : 0;
//            popExitAnim = popExitAnim != -1 ? popExitAnim : 0;
//            ft.setCustomAnimations(enterAnim, exitAnim, popEnterAnim, popExitAnim);
//        }
//
//        List<Fragment> fragments = mFragmentManager.getFragments();
//        for (Fragment fragment : fragments) {
////            XLog.i(TAG, "navigate: " + fragment.getClass().getName());
//            ft.hide(fragment);
//        }
//        String tag = String.valueOf(destination.getId());
//        Fragment frag = mFragmentManager.findFragmentByTag(tag);
//        if (frag == null) {
//            frag = instantiateFragment(mContext, mFragmentManager, className, args);
//            frag.setArguments(args);
//            ft.add(mContainerId, frag, tag);
//        }
//        ft.show(frag);
//
//        ArrayDeque<Integer> mBackStack = null;
//        try {
//            Field field = FragmentNavigator.class.getDeclaredField("mBackStack");
//            field.setAccessible(true);
//            mBackStack = (ArrayDeque<Integer>) field.get(this);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
////        ft.replace(mContainerId, frag);
//        ft.setPrimaryNavigationFragment(frag);
//
//        final @IdRes int destId = destination.getId();
//        final boolean initialNavigation = mBackStack != null && mBackStack.isEmpty();
//        // Build first class singleTop behavior for fragments
//        final boolean isSingleTopReplacement = navOptions != null && !initialNavigation
//                && navOptions.shouldLaunchSingleTop()
//                && (mBackStack != null ? mBackStack.peekLast() : -1) == destId;
//
//        boolean isAdded;
//        if (initialNavigation) {
//            isAdded = true;
//        } else if (isSingleTopReplacement) {
//            // Single Top means we only want one instance on the back stack
//            if (mBackStack != null && mBackStack.size() > 1) {
//                // If the Fragment to be replaced is on the FragmentManager's
//                // back stack, a simple replace() isn't enough so we
//                // remove it from the back stack and put our replacement
//                // on the back stack in its place
//                Integer peekLast = mBackStack.peekLast();
//                mFragmentManager.popBackStack(generateBackStackName(mBackStack.size(), peekLast), FragmentManager.POP_BACK_STACK_INCLUSIVE);
//                ft.addToBackStack(generateBackStackName(mBackStack.size(), destId));
//            }
//            isAdded = false;
//        } else {
//            ft.addToBackStack(generateBackStackName((mBackStack != null ? mBackStack.size() : 0) + 1, destId));
//            isAdded = true;
//        }
//        if (navigatorExtras instanceof Extras) {
//            Extras extras = (Extras) navigatorExtras;
//            for (Map.Entry<View, String> sharedElement : extras.getSharedElements().entrySet()) {
//                ft.addSharedElement(sharedElement.getKey(), sharedElement.getValue());
//            }
//        }
//        ft.setReorderingAllowed(true);
//        ft.commit();
//        // The commit succeeded, update our view of the world
//        if (isAdded) {
//            if (mBackStack != null) {
//                mBackStack.add(destId);
//            }
//            return destination;
//        } else {
//            return null;
//        }
//    }
//
//    private String generateBackStackName(int backStackIndex, int destId) {
//        return backStackIndex + "-" + destId;
//    }
//}
