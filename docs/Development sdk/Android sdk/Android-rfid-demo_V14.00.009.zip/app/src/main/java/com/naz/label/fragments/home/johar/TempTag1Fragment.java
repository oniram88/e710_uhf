package com.naz.label.fragments.home.johar;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.naz.label.GlobalCfg;
import com.naz.label.fragments.home.temp.TempTag2Fragment;
import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.BaseFragment;
import com.naz.label.bean.TemperatureBeanWrapper;
import com.naz.label.databinding.FragmentTempTag1Binding;
import com.naz.label.util.BeeperHelper;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.XLog;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.Beeper;
import com.payne.reader.bean.config.ClearMaskId;
import com.payne.reader.bean.config.Cmd;
import com.payne.reader.bean.config.FastTidType;
import com.payne.reader.bean.config.MaskAction;
import com.payne.reader.bean.config.MaskId;
import com.payne.reader.bean.config.MaskTarget;
import com.payne.reader.bean.config.MemBank;
import com.payne.reader.bean.config.ReadMode;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.OperationTag;
import com.payne.reader.bean.receive.Success;
import com.payne.reader.bean.receive.Version;
import com.payne.reader.bean.send.CustomSessionReadConfig;
import com.payne.reader.bean.send.MaskConfig;
import com.payne.reader.util.ArrayUtils;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author naz
 * Date 2020/7/9
 */
public class TempTag1Fragment extends BaseFragment<FragmentTempTag1Binding> {
    private static TempTag1Fragment sFragment;
    private TempTag2Fragment mTempTag2Fragment;

    private double p1 = 0.0001517;
    private double p2 = -0.003199;
    private double p3 = 1.551;
    private double p4 = -62.8;
    private double p11 = 0.003351;
    private double p22 = -0.7194;
    private double p33 = 54.94;
    private double p44 = -1388.07;

    private FastTidType mFastTidType;
    private boolean mShowLog;

    private TempTag1Adapter mAdapter;
    private CustomSessionReadConfig mYHReaderConfig;
    private CustomSessionReadConfig mXYConfig;
    private volatile CustomSessionReadConfig mReadConfig;

    private volatile static boolean sCbYHChecked;
    private volatile static boolean sCbXYChecked;
    private volatile static boolean sSetOK;
    private volatile String mEpcStr;

    private InnerHandler mHandler = new InnerHandler(this);

    private Consumer<OperationTag> mOnReadSuccess = new Consumer<OperationTag>() {
        @Override
        public void accept(OperationTag operationTag) throws Exception {
            if (!isResumed() || isRemoving() || isDetached()) {
                return;
            }
            if (mHandler != null) {
                Message message = Message.obtain();
                message.obj = operationTag;
                mHandler.sendMessage(message);
            }
        }
    };
    private Consumer<Failure> mReadFailureConsumer = this::errorResult;

    private Consumer<Success> mClearSuccessConsumer = success -> {
        sSetOK = true;
        if (!isResumed() || isHidden() || isDetached()) {
            return;
        }
        promptUi(getString(R.string.set_success));
    };
    private Consumer<Failure> mClearFailureConsumer = failure -> {
        sSetOK = false;
        if (!isResumed() || isHidden() || isDetached()) {
            return;
        }
        promptUi(getString(R.string.set_error));
    };

    private Consumer<Success> mModeSuccessConsumer = success -> {
        if (!isResumed() || isHidden() || isDetached()) {
            return;
        }
        setTempType(mFastTidType);
    };
    private Consumer<Failure> mModeFailureConsumer = failure -> {
        if (!isResumed() || isHidden() || isDetached()) {
            return;
        }
        if (mFastTidType == FastTidType.DISABLE) {
            promptUi(getString(R.string.reset_error));
        } else {
            promptUi(getString(R.string.set_error));
        }
    };

    public TempTag1Fragment() {
        sFragment = this;
    }

    public static TempTag1Fragment get() {
        return sFragment;
    }

    @Override
    protected FragmentTempTag1Binding getViewBinding() {
        return FragmentTempTag1Binding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        mAdapter = new TempTag1Adapter(new CopyOnWriteArrayList<>());
        LinearLayoutManager recyclerLayoutManager = new LinearLayoutManager(getContext());
        binding.recycler.setItemAnimator(null);
        binding.recycler.setLayoutManager(recyclerLayoutManager);
        binding.recycler.setAdapter(mAdapter);

        mYHReaderConfig = new CustomSessionReadConfig.Builder()
                .setPasswords("00000000")
                .setUserStartAddress((byte) 0x06)
                .setUserLength((byte) 0x04)
                .setReadMode(ReadMode.MODE3)
                .build();
        mXYConfig = new CustomSessionReadConfig.Builder().build();

        View.OnClickListener listener = v -> {
            if (v == binding.btnReadTag) {
                startStop(!v.isSelected());
            } else if (v == binding.btnClear) {
                mAdapter.getData().clear();
                mAdapter.notifyDataSetChanged();
            }
        };
        binding.btnReadTag.setOnClickListener(listener);
        binding.btnClear.setOnClickListener(listener);

        CompoundButton.OnCheckedChangeListener ocl = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int id = buttonView.getId();
                switch (id) {
                    case R.id.cbYH:
                        sCbYHChecked = isChecked;
                        if (sCbYHChecked) {
                            sCbXYChecked = false;
                            binding.cbXY.setChecked(false);

                            clearTagMask();
                        }
                        break;
                    case R.id.cbXY:
                        sCbXYChecked = isChecked;
                        if (sCbXYChecked) {
                            sCbYHChecked = false;
                            binding.cbYH.setChecked(false);

                            clearTagMask();
                        }
                        break;
                    case R.id.cbOther:
                        if (mFastTidType != FastTidType.DISABLE) {
                            clearTagMask();
                        }
                        binding.cbYH.setChecked(false);
                        binding.cbXY.setChecked(false);
                        binding.cbOther.setChecked(false);
                        mTempTag2Fragment = new TempTag2Fragment();
                        mTempTag2Fragment.show(getActivity());
                        break;
                }
            }
        };
        binding.cbYH.setChecked(sCbYHChecked);
        binding.cbYH.setOnCheckedChangeListener(ocl);
        binding.cbXY.setChecked(sCbXYChecked);
        binding.cbXY.setOnCheckedChangeListener(ocl);

        binding.cbOther.setOnCheckedChangeListener(ocl);
    }

    /**
     * 获取盘存的数据
     *
     * @return List<InventoryTagBean>
     */
    public List<TemperatureBeanWrapper> getTags() {
        return mAdapter.getData();
    }

    @Override
    public void onResume() {
        super.onResume();
        mShowLog = XLog.isShowLog();
        refreshUI();
    }

    public void refreshUI() {
        Version version = GlobalCfg.get().getVersion();
        if (version != null) {
            Version.ChipType chipType = version.getChipType();
            if (chipType == Version.ChipType.R2000 || chipType == Version.ChipType.FDW) {
                binding.cbOther.setVisibility(View.VISIBLE);
            } else {
                binding.cbOther.setVisibility(View.GONE);
            }
        } else {
            binding.cbOther.setVisibility(View.GONE);
        }
    }


    @Override
    public void onPause() {
        super.onPause();
        startStop(false);

        if (!sCbYHChecked && !sCbXYChecked) {
            clearTagMask();
        }
    }

    private void clearTagMask() {
        ReaderHelper.getReader().clearTagMask(ClearMaskId.TAG_MASK_NO1, mClearSuccessConsumer, mClearFailureConsumer);
        setReadTemperature(FastTidType.DISABLE);
    }

    private void setReadTemperature(FastTidType fastTidType) {
        mFastTidType = fastTidType;
        ReaderHelper.getReader().setImpinjFastTid(fastTidType, false, mModeSuccessConsumer, mModeFailureConsumer);
    }

    private void setTempType(FastTidType fastTidType) {
        MaskConfig config = null;
        switch (fastTidType) {
            case AXZON_TAG:
                mReadConfig = mXYConfig;
                ReaderHelper.getReader().readTag(mReadConfig, mOnReadSuccess, mReadFailureConsumer);
                return;
            case JOHAR_TAG:
                mReadConfig = mYHReaderConfig;
                config = new MaskConfig.Builder()
                        .setFunction(MaskId.TAG_MASK_NO1)
                        .setTarget(MaskTarget.JOHAR)
                        .setAction(MaskAction.Action4)
                        .setMemBank(MemBank.EPC)
                        .setMaskBitStartAddress((byte) 0x01)
                        .setMaskBitLength((byte) 0x01)
                        .setMaskValue("00")
                        .build();
                break;
            default:
                return;
        }

        Consumer<Success> successConsumer = success -> {
            ReaderHelper.getReader().readTag(mReadConfig, mOnReadSuccess, mReadFailureConsumer);
        };
        ReaderHelper.getReader().setTagMask(config, successConsumer, failure -> promptUi(getString(R.string.init_error)));
    }

    /**
     * 开始或者停止读标签
     *
     * @param startRead bool
     */
    public void startStop(boolean startRead) {
        if (mTempTag2Fragment != null && mTempTag2Fragment.isVisible()) {
            mTempTag2Fragment.startStop(startRead);
            return;
        }
        if (startRead) {
            if (binding.btnReadTag.isSelected()) {
                return;
            }
            if (!sSetOK || (!sCbYHChecked && !sCbXYChecked)) {
                return;
            }
            binding.cbYH.setEnabled(false);
            binding.cbXY.setEnabled(false);
            binding.cbOther.setEnabled(false);
            binding.btnReadTag.setText(R.string.stop_inventory);
            binding.btnReadTag.setSelected(true);
            mEpcStr = binding.etEpc.getText().toString().trim();

            if (sCbYHChecked) {
                setReadTemperature(FastTidType.JOHAR_TAG);
            } else if (sCbXYChecked) {
                setReadTemperature(FastTidType.AXZON_TAG);
            }
        } else {
            binding.cbYH.setEnabled(true);
            binding.cbXY.setEnabled(true);
            binding.cbOther.setEnabled(true);
            binding.btnReadTag.setSelected(false);
            binding.btnReadTag.setText(R.string.start_inventory);
            ReaderHelper.getReader().stopInventory();
        }
    }

    private void onRecv(OperationTag operationTag) {
        if (operationTag.isEndTag() && binding.btnReadTag.isSelected()) {
            ReaderHelper.getReader().readTag(mReadConfig, mOnReadSuccess, mReadFailureConsumer);
        }
        if (sCbYHChecked) {
            onYHData(operationTag);
        } else if (sCbXYChecked) {
            onXYData(operationTag);
        }
    }

    private void onXYData(OperationTag operationTag) {
        String strEpc = operationTag.getStrEpc();
        if (mEpcStr != null && !strEpc.startsWith(mEpcStr)) {
            return;
        }
        strEpc = strEpc.replace(" ", "");
        byte[] bytes = ArrayUtils.hexStringToBytes(strEpc);

        int srcPos = bytes.length - 4;
        if (srcPos < 0) {
            return;
        }
        byte[] tmpBytes = new byte[4];
        System.arraycopy(bytes, srcPos, tmpBytes, 0, 4);
        int Adc = ArrayUtils.byteArrayToInt(tmpBytes, 0, 2, true);
        String end3Str = strEpc.substring(strEpc.length() - 3);
        int Cali = Integer.parseInt(end3Str, 16) - 256;
        double xAdc = (Adc - Cali) / 100.00 + 10;
        double temp;
        if ((Adc - Cali) < 6052) {
            temp = p1 * xAdc * xAdc * xAdc + p2 * xAdc * xAdc + p3 * xAdc + p4;
        } else {
            temp = p11 * xAdc * xAdc * xAdc + p22 * xAdc * xAdc + p33 * xAdc + p44;
        }
        if (mShowLog) {
            XLog.w(strEpc + ", Temp= " + temp + ", end3Str=" + end3Str + ", Adc= " + Adc + ", Cali= " + Cali + ", xAdc= " + xAdc);
        }
        if (temp > 150 || temp < -40) {
            temp = 0;
        }

        TemperatureBeanWrapper bean = new TemperatureBeanWrapper(operationTag, temp);
        List<TemperatureBeanWrapper> data = mAdapter.getData();
        for (TemperatureBeanWrapper datum : data) {
            if (datum.getEpc().equals(bean.getEpc())) {
                if (datum.isValid(temp)) {
                    toBeep();
                    datum.setTagBean(operationTag, temp);
                    mAdapter.notifyDataSetChanged();
                }
                return;
            }
        }
        toBeep();
        data.add(0, bean);
        mAdapter.notifyDataSetChanged();
    }

    private void onYHData(OperationTag operationTag) {
        String strEpc = operationTag.getStrData();
        if (mEpcStr != null && !strEpc.startsWith(mEpcStr)) {
            return;
        }
        //            String strData = "F2 08 F3 2F FF EC 20 00".replace(" ", "");
        byte[] bytes = ArrayUtils.hexStrToByteArr(strEpc, " ");
        int senData = checkYhData(bytes);
        if (senData < 0) {
            XLog.w("senData = " + senData);
            return;
        }
        int D2 = (senData >> 3) & 0xFFFF;
        XLog.i("D2: " + D2);
        short Δ1 = (short) (((bytes[4] & 0xFF) << 8) | (bytes[5] & 0xFF));
        XLog.i("Δ1: " + Δ1);
        double temp = 11109.6 / (24 + (D2 + Δ1) / 375.3) - 290;
        if (temp > 125) {
            temp = temp * 1.2 - 25;
        }
        TemperatureBeanWrapper bean = new TemperatureBeanWrapper(operationTag, temp);
        List<TemperatureBeanWrapper> data = mAdapter.getData();
        for (TemperatureBeanWrapper datum : data) {
            if (datum.getEpc().equals(bean.getEpc())) {
                if (datum.isValid(temp)) {
                    toBeep();
                    datum.setTagBean(operationTag, temp);
                    mAdapter.notifyDataSetChanged();
                }
                return;
            }
        }
        toBeep();
        data.add(0, bean);
        mAdapter.notifyDataSetChanged();
    }

    private void errorResult(Failure failure) {
        if (!isResumed() || isHidden() || isDetached()) {
            return;
        }
        byte errorCode = failure.getErrorCode();
        XLog.e("errorResult." + Cmd.getNameForCmd(failure.getCmd()) + "->" + Failure.getNameForResultCode(errorCode));

        if (binding.btnReadTag.isSelected()) {
            ReaderHelper.getReader().readTag(mReadConfig, mOnReadSuccess, mReadFailureConsumer);
        }
    }

    /**
     * Get senData
     *
     * @param bytes 源数据
     * @return value >=0 : success
     * value = -1 : Failed to verify data length
     * value = -2 : Sensor data HEADER verification failed
     * value = -3 : Sensing data SEN_DATA[23:19] needs to be 00100b, otherwise the data is invalid
     * value = -4 : Sensor data verification failed
     * value = -5 : Detect chips that are not LTU32 version
     */
    private int checkYhData(byte[] bytes) {
        //校验数据长度
        if (bytes.length != 8) {
            return -1;
        }
        //传感数据 HEADER 需要为 0xF，否则数据无效
        if (((bytes[0] >> 4) & 0x0F) != 0x0F) {
            return -2;
        }
        if (((bytes[2] >> 4) & 0x0F) != 0x0F) {
            return -2;
        }
        //检测是不是LTU32版本的芯片,USR区0x09[15:12] == 0010b
        if (((bytes[6] >> 4) & 0x0F) != 0x02) {
            return -5;
        }
        int senData = ((((bytes[0] & 0x0F) << 8) | (bytes[1] & 0xFF)) << 12) | ((bytes[2] & 0x0F) << 8) | (bytes[3] & 0xFF);
        //传感数据 SEN_DATA[23:19] 需要为 00100b，否则数据无效
        if (((senData >> 19) & 0x1F) != 0x04) {
            return -3;
        }
        //传感数据需通过以下校验，否则数据无效
        if (((senData >> 2) & 1) != (~(((senData >> 14) & 1) ^ ((senData >> 11) & 1) ^ ((senData >> 8) & 1) ^ ((senData >> 5) & 1)) & 1)) {
            return -4;
        }
        if (((senData >> 1) & 1) != (~(((senData >> 13) & 1) ^ ((senData >> 10) & 1) ^ ((senData >> 7) & 1) ^ ((senData >> 4) & 1)) & 1)) {
            return -4;
        }
        if ((senData & 1) != (~(((senData >> 12) & 1) ^ ((senData >> 9) & 1) ^ ((senData >> 6) & 1) ^ ((senData >> 3) & 1)) & 1)) {
            return -4;
        }
        return senData;
    }

    /**
     * 提示
     *
     * @param msg msg
     */
    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null && isResumed() && binding != null) {
            activity.runOnUiThread(() -> ToastUtils.makeText(binding.getRoot(), msg, Toast.LENGTH_SHORT).show());
        }
    }

    private void toBeep() {
        if (BeeperHelper.getBeeperType() != Beeper.QUIET) {
            BeeperHelper.beep(BeeperHelper.SOUND_FILE_TYPE_SHORT);
        }
    }

    @Override
    public void onDestroy() {
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }
        super.onDestroy();
    }

    private static class InnerHandler extends Handler {
        private WeakReference<TempTag1Fragment> mWr;

        public InnerHandler(TempTag1Fragment fragment) {
            mWr = new WeakReference<>(fragment);
        }

        @Override
        public void handleMessage(@NonNull Message msg) {
            TempTag1Fragment fragment = mWr.get();
            if (fragment == null) {
                return;
            }
            OperationTag operationTag = (OperationTag) msg.obj;
            fragment.onRecv(operationTag);
        }
    }
}