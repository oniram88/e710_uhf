package com.naz.label.fragments.set.gpio;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.OldBaseFragment;
import com.naz.label.util.ReaderHelper;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.GpioInType;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.GpioOut;
import com.payne.reader.bean.receive.Success;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author naz
 * Date 2020/4/7
 */
public class ReaderGpioFragment extends OldBaseFragment {
    @BindView(R.id.radio_group_gpio1)
    RadioGroup radioGroupGpio1;
    @BindView(R.id.radio_group_gpio2)
    RadioGroup radioGroupGpio2;
    @BindView(R.id.radio_group_gpio3)
    RadioGroup radioGroupGpio3;
    @BindView(R.id.radio_group_gpio4)
    RadioGroup radioGroupGpio4;
    @BindView(R.id.cl_parent)
    ConstraintLayout clParent;

    @Override
    public int getLayoutResId() {
        return R.layout.fragment_reader_gpio;
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
    }

    @OnClick({R.id.btn_get, R.id.btn_set_gpio3, R.id.btn_set_gpio4})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_get:
                ReaderHelper.getReader().readGpio(this::updateUi, failure -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_set_gpio3:
                boolean gpio3High = radioGroupGpio3.getCheckedRadioButtonId() == R.id.rb_high_gpio3;
                ReaderHelper.getReader().writeGpio(GpioInType.Gpio3, gpio3High, successConsumer, failureConsumer);
                break;
            case R.id.btn_set_gpio4:
                boolean gpio4High = radioGroupGpio4.getCheckedRadioButtonId() == R.id.rb_high_gpio4;
                ReaderHelper.getReader().writeGpio(GpioInType.Gpio4, gpio4High, successConsumer, failureConsumer);
                break;
            default:
        }
    }

    private Consumer<Success> successConsumer = success -> promptUi(getString(R.string.set_success));
    private Consumer<Failure> failureConsumer = failure -> promptUi(getString(R.string.set_error));

    private void updateUi(GpioOut gpioOut) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity != null) {
            activity.runOnUiThread(() -> {
                if (gpioOut.getGpios()[0].isHigh()) {
                    radioGroupGpio1.check(R.id.rb_high_gpio1);
                } else {
                    radioGroupGpio1.check(R.id.rb_low_gpio1);
                }
                if (gpioOut.getGpios()[1].isHigh()) {
                    radioGroupGpio2.check(R.id.rb_high_gpio2);
                } else {
                    radioGroupGpio2.check(R.id.rb_low_gpio2);
                }
            });
        }
    }

    /**
     * 提示
     *
     * @param msg msg
     */
    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> ToastUtils.makeText(clParent, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
