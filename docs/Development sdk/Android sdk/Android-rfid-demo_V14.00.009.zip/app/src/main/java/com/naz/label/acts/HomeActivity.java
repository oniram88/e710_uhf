package com.naz.label.acts;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.bean.t30.DevicePower;
import com.naz.label.bean.LogBean;
import com.naz.label.bean.t30.TriggerKey;
import com.naz.label.bean.type.Key;
import com.naz.label.bean.type.LinkType;
import com.naz.label.databinding.ActivityHomeBinding;
import com.naz.label.fragments.set.ReaderCfgFragment;
import com.naz.label.fragments.set.ble.ReaderBleFragment;
import com.naz.label.util.BeeperHelper;
import com.naz.label.util.LiveDataBus;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.ScreenUtils;
import com.naz.label.util.StringFormat;
import com.naz.label.dialog.ExportExcelDialog;
import com.naz.label.fragments.home.access.AccessTagFragment;
import com.naz.label.fragments.home.find.FindTagFragment;
import com.naz.label.fragments.home.inventory.InventoryTagFragment;
import com.naz.label.fragments.home.johar.TempTag1Fragment;
import com.naz.label.util.InputUtils;
import com.naz.label.widget.VerticalDrawerLayout;
import com.naz.label.util.BatteryUtils;
import com.naz.label.util.StartActivityUtils;
import com.naz.label.util.ToastUtils;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.reader.Reader;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.Cmd;
import com.payne.reader.bean.config.CmdStatus;
import com.payne.reader.bean.config.ResultCode;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.Version;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.List;

import io.reactivex.disposables.Disposable;

/**
 * @author naz
 */
public class HomeActivity extends BaseActivity<ActivityHomeBinding> {
    private final int MSG_REFRESH_UI = 0;
    private final int MSG_REFRESH_POWER = 1;

    public static HomeActivity sHomeActivity;
    private AlertDialog mExitDialog;
    private Consumer<TriggerKey> mTriggerKeyConsumer;

    private Disposable mDisposable;

    private volatile int sCurrLevel;
    private BroadcastReceiver mBatteryReceiver;

    private volatile boolean mIsSleep;
    private volatile boolean mIsRecharge = false;
    private boolean mAllowShow = true;
    private AlertDialog mAlertDialog;

    @SuppressLint("HandlerLeak")
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case MSG_REFRESH_UI: {
//                    delayInitUI();
                }
                break;
                case MSG_REFRESH_POWER: {
                    refreshPower();
                }
                break;
            }
        }
    };
    private DrawerLayout.DrawerListener mDL = new DrawerLayout.SimpleDrawerListener() {

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {
            boolean openL = binding.drawerLayout.isDrawerOpen(GravityCompat.START);
            if (openL) {
                binding.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_OPEN, GravityCompat.START);
                binding.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, GravityCompat.END);
            } else {
                binding.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, GravityCompat.START);
                binding.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_OPEN, GravityCompat.END);
            }
        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {
            InputUtils.hideInputMethod(HomeActivity.this);
            binding.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, GravityCompat.START);
            binding.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, GravityCompat.END);
        }
    };
    private Consumer<Version> successConsumer = version -> {
        runOnUiThread(() -> {
            ReaderHelper.getReader().removeCallback(Cmd.GET_FIRMWARE_VERSION);
            GlobalCfg.get().setVersion(version);
        });
    };
    private Consumer<DevicePower> powerConsumer = devicePower -> {
        runOnUiThread(() -> {
            int v = devicePower.getDevicePower();
            int powerLevel = (v - 3500) / 65;
            binding.appbar.btnMainPower.setImageResource(BatteryUtils.getPowerPic(powerLevel));
        });
    };
    private Consumer<Failure> failureConsumer = failure -> XLog.w(Cmd.getNameForCmd(failure.getCmd()) + ",获取失败:" + Failure.getNameForResultCode(failure.getErrorCode()));

    //<editor-fold desc="Top Btn mL">
    private View.OnClickListener mL = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_main_select_tag: {
                    binding.drawerLayout.openDrawer(GravityCompat.START);
                }
                break;
                case R.id.btn_main_invent_tag: {
                    showInvent();
                }
                break;
                case R.id.btn_main_access_tag: {
                    showAccess();
                }
                break;
                case R.id.btn_main_temp_tag: {
                    showTemp();
                }
                break;
                case R.id.btn_main_cfg: {
                    VerticalDrawerLayout menu = InventoryTagFragment.get().getVdlMenu();
                    if (menu.isDrawerOpen()) {
                        menu.closeDrawer();
                    }
                    ReaderCfgFragment fragment = ReaderCfgFragment.get();
                    if (fragment != null) {
                        fragment.refreshUI();
                    }
                    binding.drawerLayout.openDrawer(GravityCompat.END);
                }
                break;
                case R.id.btn_main_extra: {
                    if (Build.VERSION.SDK_INT > 23) {
                        int x = ScreenUtils.dp2px(HomeActivity.this, 512);
                        v.showContextMenu(x, ScreenUtils.dp2px(HomeActivity.this, 45));
                    } else {
                        v.showContextMenu();
                    }
                }
                break;
            }
        }
    };

    private void showInvent() {
        boolean selected = binding.appbar.btnMainInventTag.isSelected();
        if (selected) {
            return;
        }
        binding.appbar.btnMainInventTag.setSelected(true);
        binding.appbar.btnMainAccessTag.setSelected(false);
        binding.appbar.btnMainTempTag.setSelected(false);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.show(InventoryTagFragment.get());
        ft.hide(AccessTagFragment.get());
        ft.hide(TempTag1Fragment.get());
        ft.commitAllowingStateLoss();
    }

    private void showAccess() {
        boolean selected = binding.appbar.btnMainAccessTag.isSelected();
        if (selected) {
            return;
        }
        binding.appbar.btnMainInventTag.setSelected(false);
        binding.appbar.btnMainAccessTag.setSelected(true);
        binding.appbar.btnMainTempTag.setSelected(false);

        AccessTagFragment fragment = AccessTagFragment.get();

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.hide(InventoryTagFragment.get());
        ft.show(fragment);
        ft.hide(TempTag1Fragment.get());
        ft.commitAllowingStateLoss();

        fragment.refreshUI();
    }

    private void showTemp() {
        boolean selected = binding.appbar.btnMainTempTag.isSelected();
        if (selected) {
            return;
        }
        binding.appbar.btnMainInventTag.setSelected(false);
        binding.appbar.btnMainAccessTag.setSelected(false);
        binding.appbar.btnMainTempTag.setSelected(true);

        TempTag1Fragment fragment = TempTag1Fragment.get();

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.hide(InventoryTagFragment.get());
        ft.hide(AccessTagFragment.get());
        ft.show(fragment);
        ft.commitAllowingStateLoss();

        fragment.refreshUI();
    }
    //</editor-fold>

    private void refreshPower() {
        ReaderHelper.getDefaultHelper().getDevicePower(powerConsumer, failureConsumer);
        mHandler.removeMessages(MSG_REFRESH_POWER);
        mHandler.sendEmptyMessageDelayed(MSG_REFRESH_POWER, 14000);
    }

    public static void start(Context context) {
        Intent starter = new Intent(context, HomeActivity.class);
        context.startActivity(starter);
    }

    @Override
    protected ActivityHomeBinding getViewBinding() {
        return ActivityHomeBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView() {
        sHomeActivity = this;
        binding.appbar.btnMainInventTag.setSelected(true);
        try {
            InventoryTagFragment fragment = InventoryTagFragment.get();
            if (fragment == null) {
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.vpMain, new InventoryTagFragment())
                        .add(R.id.vpMain, new AccessTagFragment())
                        .add(R.id.vpMain, new TempTag1Fragment())
                        .hide(AccessTagFragment.get())
                        .hide(TempTag1Fragment.get())
                        .commitAllowingStateLoss();
            } else {
                getSupportFragmentManager().beginTransaction()
                        .show(fragment)
                        .commitAllowingStateLoss();
            }
        } catch (Exception e) {
            XLog.e("e = " + Log.getStackTraceString(e));
        }
//
//        binding.appbar.loadingLayer.setVisibility(View.VISIBLE);
//        mHandler.sendEmptyMessageDelayed(MSG_REFRESH_UI, 1024);
//    }
//
//    private void delayInitUI() {
        binding.drawerLayout.addDrawerListener(mDL);

//        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
//        if (SelectTagFragment.get() == null) {
//            ft.add(R.id.dwSubFll, new SelectTagFragment());
//            ft.add(R.id.dwSubFlr, new ReaderCfgFragment());
//        } else {
//            ft.show(SelectTagFragment.get());
//            ft.show(ReaderCfgFragment.get());
//        }
//        ft.commitAllowingStateLoss();

        binding.appbar.btnMainSelectTag.setOnClickListener(mL);
        binding.appbar.btnMainInventTag.setOnClickListener(mL);
        binding.appbar.btnMainAccessTag.setOnClickListener(mL);
        binding.appbar.btnMainTempTag.setOnClickListener(mL);
        binding.appbar.btnMainCfg.setOnClickListener(mL);
        binding.appbar.btnMainExtra.setOnClickListener(mL);
        registerForContextMenu(binding.appbar.btnMainExtra);

        registScreenReceiver();
        registBatteryReceiver();

        setupReader();

        binding.appbar.loadingLayer.setVisibility(View.GONE);

        LiveDataBus.getInstance().getLiveData().observe(this, liveDataBusBean -> {
            switch (liveDataBusBean.mCmd) {
                case LiveDataBus.BUS_SHOW_ACCESS:
                    showAccess();
                    break;
                case LiveDataBus.BUS_SHOW_FIND:
                    new FindTagFragment().show(HomeActivity.this);
                    break;
            }
        });
    }

    private void setupReader() {
        Reader reader = ReaderHelper.getReader();
        if (reader == null || !reader.isConnected()) {
            XLog.w("stop init cfg.");
            return;
        }
        reader.getFirmwareVersion(successConsumer, failureConsumer);
        BeeperHelper.beep(BeeperHelper.SOUND_FILE_TYPE_NORMAL);
        BeeperHelper.setup();

        Intent intent = getIntent();
        if (intent.hasExtra("timeout")) {/*只有打印机RFID连接界面过来时，可能携带*/
            long cmdTimeout = intent.getLongExtra("timeout", 8000L);
            reader.setCmdTimeout(cmdTimeout);
        } else {
            long cmdTimeout = Hawk.get(Key.CMD_TIMEOUT, 6000L);/*总的指令超时时间*/
            reader.setCmdTimeout(cmdTimeout);/*进来时配置超时*/
        }

        Consumer<CmdStatus> commandStatusCallback = cmdStatus -> {
            if (binding.appbar.logView == null || cmdStatus.getStatus() == ResultCode.REQUEST_TIMEOUT) {
                return;
            }
            if (binding.appbar.logView.getVisibility() == View.VISIBLE) {
                String status = StringFormat.formatTempLabel2(cmdStatus.getCmd(), cmdStatus.getStatus());
                if (cmdStatus.getCmd() == Cmd.SET_WORK_ANTENNA) {
                    status += getString(R.string.stitch_ant) + (reader.getCacheWorkAntenna() + 1);
                }
                if (cmdStatus.getStatus() == ResultCode.ANTENNA_MISSING_ERROR) {
                    status += getString(R.string.stitch_ant) + (cmdStatus.getAntId() + 1);
                }
                LogBean bean = new LogBean(status, cmdStatus.getStatus() == ResultCode.SUCCESS);
                runOnUiThread(() -> binding.appbar.logView.addData(bean));
            }
        };
        reader.setCommandStatusCallback(commandStatusCallback);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean enableLog = Hawk.get(Key.ENABLE_OPERATE_LOG, false);
        binding.appbar.logView.setVisibility(enableLog ? View.VISIBLE : View.GONE);

        setupBT();
    }

    private void setupBT() {
        LinkType linkType = GlobalCfg.get().getLinkType();
        if (linkType == null) {
            return;
        }
        if (mTriggerKeyConsumer != null) {
            return;
        }
        switch (linkType) {
            case LINK_TYPE_BLUETOOTH:
                mTriggerKeyConsumer = triggerKey -> {
                    boolean isPress = triggerKey.isEnable();
                    boolean sleep = isSleep();
                    XLog.i("Sleep: " + sleep + ",扣扳机: " + isPress);
//                    if (sleep) {
//                        return;
//                    }
                    runOnUiThread(() -> {
                        if (mIsRecharge && isPress) {
                            showRechargeDialog(true, false);
                            mHandler.postDelayed(() -> pressKeyEvent(true), 1000);
                        } else {
                            if (isPress) {
                                pressKeyEvent(!mPressed);
                            } else {
                                if (Hawk.get(Key.KEY_F4_LONG_PRESS, true)) {
                                    pressKeyEvent(false);
                                }
                            }
                        }
                    });
                };
                ReaderHelper readerHelper = ReaderHelper.getDefaultHelper();
                readerHelper.setTriggerKeyCallback(mTriggerKeyConsumer);
                readerHelper.setRechargeCallback(rechargeBean -> {
                    runOnUiThread(() -> {
                        mIsRecharge = rechargeBean.isRecharge();
                        XLog.w("充电? " + mIsRecharge);
                        showRechargeDialog(mIsRecharge, true);
                    });
                });
                mHandler.removeMessages(MSG_REFRESH_POWER);
                mHandler.sendEmptyMessageDelayed(MSG_REFRESH_POWER, 2000);
                break;
            default:
                break;
        }
    }

    private void showRechargeDialog(boolean show, boolean sendOpen) {
        if (mIsRecharge) {
            binding.emptyView.setVisibility(View.VISIBLE);
        } else {
            binding.emptyView.setVisibility(View.GONE);
        }
        if (show) {
            if (mAllowShow) {
                if (mAlertDialog == null) {
                    mAlertDialog = new AlertDialog.Builder(this)
                            .setTitle(R.string.alert_dialog_title)
                            .setMessage(R.string.app_in_recharge_mode)
                            .setCancelable(false)
                            .setPositiveButton(R.string.sure, (dialog, which) -> {
                                mAllowShow = false;
                                dialog.dismiss();
                            }).create();
                }
                if (mAlertDialog.isShowing()) {
                    mAllowShow = false;
                    mAlertDialog.dismiss();
                } else {
                    mAlertDialog.show();
                }
            }
        } else {
            if (mAlertDialog != null) {
                mAlertDialog.dismiss();
            }
            if (sendOpen) {
                ReaderHelper.getDefaultHelper().openCloseModule((byte) 0x01, true, true,
//                    success -> showToast(R.string.open_module_success),
                        success -> {
                        },
                        failure -> showToast(R.string.open_module_error));
            }
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        boolean isBle = GlobalCfg.get().getLinkType() == LinkType.LINK_TYPE_BLUETOOTH;
        menu.findItem(R.id.menu_ble_module).setVisible(isBle);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_reset:
                showToast(R.string.reset_reader);
                ReaderHelper.getReader().reset(failure -> runOnUiThread(() -> showToast(R.string.reset_error)));
                BeeperHelper.beep(BeeperHelper.SOUND_FILE_TYPE_NORMAL);
                return true;
            case R.id.menu_monitor:
                StartActivityUtils.startActivity(this, MonitorActivity.class);
                return true;
            case R.id.menu_language_switch:
                StartActivityUtils.startActivity(this, LanguageSwitchActivity.class);
                return true;
            case R.id.menu_other_connection:
                new SwitchConnectFragment().show(this);
                return true;
            case R.id.menu_export_excel:
                getStoragePermission();
                return true;
            case R.id.menu_ble_module:
                new ReaderBleFragment().show(this);
                return true;
            case R.id.menu_setting:
                StartActivityUtils.startActivity(this, SettingActivity.class);
                return true;
            case R.id.menu_about:
                StartActivityUtils.startActivity(this, AboutActivity.class);
                return true;
            case R.id.menu_find:
                new FindTagFragment().show(this);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * 获取存储权限
     */
    private void getStoragePermission() {
        boolean perOk;
        if (android.os.Build.VERSION.SDK_INT > 22) {
            perOk = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        } else {
            perOk = true;
        }
        if (perOk) {
            showExportExcel();
            return;
        }
        mDisposable = new RxPermissions(this)
                .requestEachCombined(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(permission -> {
                    if (permission.granted) {
                        showExportExcel();
                    } else if (permission.shouldShowRequestPermissionRationale) {
                        showToast(R.string.get_location_permission_fail);
                    } else {
                        new AlertDialog.Builder(this)
                                .setMessage(R.string.get_storage_permission)
                                .setNegativeButton(R.string.cancel, null)
                                .setPositiveButton(R.string.to_open, (dialog, which) -> StartActivityUtils.startPermissionActivity(this))
                                .create()
                                .show();
                    }
                });
    }

    private void showExportExcel() {
        String title;
        List<?> tags;
        boolean enablePhase = false;
        boolean enableTemperature = false;
        Fragment fragment = InventoryTagFragment.get();
        XLog.i("fragment = " + fragment);
        if (fragment != null && fragment.isVisible()) {
            title = getString(R.string.Inventory_label);
            InventoryTagFragment inventoryTagFragment = (InventoryTagFragment) fragment;
            tags = inventoryTagFragment.getTags();
            enablePhase = inventoryTagFragment.isEnablePhase();
//            enableTemperature = inventoryTagFragment.isEnableTemperature();
        } else if ((fragment = AccessTagFragment.get()) != null && fragment.isVisible()) {
            title = getString(R.string.access_tag);
            AccessTagFragment accessTagFragment = (AccessTagFragment) fragment;
            tags = accessTagFragment.getTags();
        } else if ((fragment = TempTag1Fragment.get()) != null && fragment.isVisible()) {
            title = getString(R.string.temperature);
            TempTag1Fragment joharTagFragment = (TempTag1Fragment) fragment;
            tags = joharTagFragment.getTags();
        } else {
            return;
        }
        if (tags == null || tags.size() == 0) {
            ToastUtils.makeText(null, R.string.export_excel_error, Toast.LENGTH_SHORT).show();
            return;
        }
        new ExportExcelDialog()
                .setTitle(title)
                .setTags(tags)
                .setPhase(enablePhase)
                .setTemperature(enableTemperature)
                .show(this);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        XLog.w("keyCode = " + keyCode);
        if (keyCode == KeyEvent.KEYCODE_F4 && GlobalCfg.get().getLinkType() != LinkType.LINK_TYPE_BLUETOOTH) {
            if (Hawk.get(Key.KEY_F4_LONG_PRESS, true)) {
                pressKeyEvent(true);
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_F4 && GlobalCfg.get().getLinkType() != LinkType.LINK_TYPE_BLUETOOTH) {
            if (Hawk.get(Key.KEY_F4_LONG_PRESS, true)) {
                pressKeyEvent(false);
            } else {
                pressKeyEvent(!mPressed);
            }
        }
        return super.onKeyUp(keyCode, event);
    }

    /**
     * 扳机按键是否按下事件
     *
     * @param isPress bool
     */
    boolean mPressed;

    private void pressKeyEvent(boolean isPress) {
        if (mPressed == isPress) {
            return;
        }
        mPressed = isPress;
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)
                || binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
            return;
        }
        FindTagFragment fragment = FindTagFragment.get();
        if (fragment != null && fragment.isResumed() && fragment.isVisible()) {
            fragment.startStop(isPress);/*扳机*/
        } else if (binding.appbar.btnMainInventTag.isSelected()) {
            InventoryTagFragment f = InventoryTagFragment.get();
            if (f != null && f.isVisible()) {
                f.startStop(isPress);/*扳机*/
            }
        } else if (binding.appbar.btnMainAccessTag.isSelected()) {
            AccessTagFragment f = AccessTagFragment.get();
            if (f != null && f.isVisible()) {
                f.startStop(isPress);/*扳机*/
            }
        } else if (binding.appbar.btnMainTempTag.isSelected()) {
            TempTag1Fragment f = TempTag1Fragment.get();
            if (f != null && f.isVisible()) {
                f.startStop(isPress);/*扳机*/
            }
        }
    }

    public boolean isSleep() {
        boolean isSleep = mIsSleep;
//        this.mIsSleep = false;
        return isSleep;
    }

    //注册屏幕唤醒/锁屏广播
    private void registScreenReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mScreenReceiver, filter);
    }

    public static int getBatteryLevel() {
        if (sHomeActivity == null) {
            return 100;
        }
        return sHomeActivity.sCurrLevel;
    }

    public void registBatteryReceiver() {
        if (mBatteryReceiver != null) {
            XLog.i("Battery have registed...");
            return;
        }
        LinkType linkType = GlobalCfg.get().getLinkType();
        if (linkType != LinkType.LINK_TYPE_SERIAL_PORT) {
            XLog.i("No need regist battery receiver");
            return;
        }
        mBatteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                sCurrLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(mBatteryReceiver, filter);
    }

    private void unregisterBatteryReceiver() {
        if (mBatteryReceiver != null) {
            XLog.i("unregister...");
            try {
                unregisterReceiver(mBatteryReceiver);
                mBatteryReceiver = null;
            } catch (Exception e) {
                XLog.w(Log.getStackTraceString(e));
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START);
            return;
        }
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
            binding.drawerLayout.closeDrawer(GravityCompat.END);
            return;
        }

        VerticalDrawerLayout menu = InventoryTagFragment.get().getVdlMenu();
        if (menu != null && menu.isDrawerOpen()) {
            menu.closeDrawer();
            return;
        }
        FindTagFragment findTagFragment = FindTagFragment.get();
        if (findTagFragment != null && findTagFragment.isVisible()) {
            return;
        }
//        ActivityLifecycleUtils.gotoDesktop(this);
        askForOut();
    }

    private void askForOut() {
        if (mExitDialog != null && mExitDialog.isShowing()) {
            return;
        }
        mExitDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.alert_dialog_title)
                .setMessage(R.string.are_you_sure_to_exit)
                .setPositiveButton(R.string.sure, (dialog, which) -> {
                    exit();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void exit() {
        sHomeActivity = null;
        if (mDisposable != null) {
            mDisposable.dispose();
        }
        mHandler.removeCallbacksAndMessages(null);
        unregisterForContextMenu(binding.appbar.btnMainExtra);
        try {
            unregisterReceiver(mScreenReceiver);
        } catch (Exception ignored) {
        }
        unregisterBatteryReceiver();
        getApplication().onTerminate();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private final BroadcastReceiver mScreenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            LinkType linkType = GlobalCfg.get().getLinkType();
            String action = intent.getAction();

            if (Intent.ACTION_SCREEN_ON.equals(action)) {/*亮屏*/
                mIsSleep = false;
                if (linkType == LinkType.LINK_TYPE_BLUETOOTH) {
                    ReaderHelper.getDefaultHelper().wakeupInterfaceBoard();
                    mHandler.removeMessages(MSG_REFRESH_POWER);
                    mHandler.sendEmptyMessage(MSG_REFRESH_POWER);
                }
            } else if (Intent.ACTION_SCREEN_OFF.equals(action)) {/*息屏*/
                mIsSleep = true;
                if (linkType == LinkType.LINK_TYPE_BLUETOOTH) {
                    mHandler.removeMessages(MSG_REFRESH_POWER);
                }
            }
        }
    };
}