package com.naz.label.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.graphics.Point;
import android.media.MediaScannerConnection;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.R;
import com.naz.label.base.BaseDialogFragment;
import com.naz.label.bean.type.Key;
import com.naz.label.databinding.DialogExportExcelBinding;
import com.naz.label.util.ExcelHelper;
import com.naz.label.widget.AfterTextWatcher;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.reader.util.ThreadPool;
import com.thl.filechooser.FileChooser;
import com.thl.filechooser.FileInfo;

import java.io.File;
import java.util.List;

/**
 * @author naz
 * Date 2020/9/25
 */
public class ExportExcelDialog extends BaseDialogFragment<DialogExportExcelBinding> {
    private String mTitle;
    private List<?> mTags;
    private boolean mIsPhase;
    private boolean mEnableTemperature;
    private String mDirPath;
    private boolean mSuccess;
    @SuppressLint("HandlerLeak")
    private Handler mH = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (binding.exPbWait.isShown()) {
                Toast.makeText(XLog.sContext, mSuccess ? R.string.export_success : R.string.export_fail, Toast.LENGTH_SHORT).show();
            }
            binding.exPbWait.setVisibility(View.GONE);
            Dialog dialog = getDialog();
            if (dialog != null) {
                dialog.dismiss();
            }
        }
    };

    @Override
    protected DialogExportExcelBinding getViewBinding() {
        return DialogExportExcelBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        binding.tvTitle.setText(getString(R.string.export_excel));
        binding.etFileName.setText(mTitle + getString(R.string.labels));

        mDirPath = Hawk.get(Key.KEY_EXEL_PATH, null);
        if (TextUtils.isEmpty(mDirPath)) {
            try {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
                dir.mkdirs();
                mDirPath = dir.getAbsolutePath();
            } catch (Exception e) {
            }
        } else {
            new File(mDirPath).mkdirs();
        }
        binding.tvFolder.setText(mDirPath);

        binding.etFileName.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s)) {
                    binding.etFileName.setError(getString(R.string.input_file_name));
                    binding.btnConfirm.setEnabled(false);
                } else {
                    binding.btnConfirm.setEnabled(true);
                }
            }
        });
        binding.tvFolder.setOnClickListener(this::onViewClicked);
        binding.btnCancel.setOnClickListener(this::onViewClicked);
        binding.btnConfirm.setOnClickListener(this::onViewClicked);
    }

    public ExportExcelDialog setTitle(String title) {
        mTitle = title;
        return this;
    }

    public ExportExcelDialog setTags(List<?> tags) {
        this.mTags = tags;
        return this;
    }

    public ExportExcelDialog setPhase(boolean enable) {
        this.mIsPhase = enable;
        return this;
    }

    public ExportExcelDialog setTemperature(boolean enable) {
        this.mEnableTemperature = enable;
        return this;
    }

    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_folder:
                FileChooser fileChooser = new FileChooser(this, filePath -> {
                    mDirPath = filePath;
                    binding.tvFolder.setText(mDirPath);

                    Hawk.put(Key.KEY_EXEL_PATH, mDirPath);
                });
                fileChooser.setBackIconRes(R.drawable.ic_baseline_arrow_back_ios_24);
                fileChooser.setTitle(getString(R.string.select_folder));
                fileChooser.setDoneText(getString(R.string.sure));
                fileChooser.setThemeColor(R.color.colorPrimary);
                fileChooser.setChooseType(FileInfo.FILE_TYPE_FOLDER);
                fileChooser.showFile(false);
                fileChooser.open();
                break;
            case R.id.btn_cancel:
                this.dismiss();
                break;
            case R.id.btn_confirm:
                String name = binding.etFileName.getText().toString().trim() + ".xls";
                File file = new File(mDirPath, name);
                if (mTags == null || mTags.isEmpty()) {
                    showToast(R.string.export_excel_error);
                    return;
                }
                binding.exPbWait.setVisibility(View.VISIBLE);
                ThreadPool.get().execute(() -> {
                    mSuccess = ExcelHelper.writeToExcel(file, mTags, mIsPhase, mEnableTemperature);
                    MediaScannerConnection.scanFile(XLog.sContext, new String[]{file.getAbsolutePath()}, null, (path, uri) -> {
                        mH.sendEmptyMessage(0);
                    });
                    mH.sendEmptyMessageDelayed(1, 5000);
                });
                break;
            default:
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog == null) {
            return;
        }
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }
        Point size = getScreenSize();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.width = (int) (size.x * 0.9);
        window.setAttributes(attributes);
    }

    private Point getScreenSize() {
        final Point size = new Point();
        final FragmentActivity activity = requireActivity();
        final WindowManager windowManager = activity.getWindowManager();
        final Display display = windowManager.getDefaultDisplay();
        display.getSize(size);
        return size;
    }

    @Override
    public void onDestroy() {
        if (mH != null) {
            mH.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }
}