package com.naz.label.fragments.set.monza;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.OldBaseFragment;
import com.naz.label.bean.type.Key;
import com.naz.label.util.ReaderHelper;
import com.orhanobut.hawk.Hawk;
import com.payne.reader.bean.config.FastTidType;
import com.payne.reader.bean.receive.ImpinjFastTid;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author naz
 * Date 2020/4/7
 */
public class ReaderMonzaFragment extends OldBaseFragment {
    @BindView(R.id.radio_group_open)
    RadioGroup radioGroupOpen;
    @BindView(R.id.radio_group_save)
    RadioGroup radioGroupSave;
    @BindView(R.id.cl_parent)
    ConstraintLayout clParent;

    @Override
    public int getLayoutResId() {
        return R.layout.fragment_reader_monza;
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
    }

    @OnClick({R.id.btn_get, R.id.btn_set})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_get:
                ReaderHelper.getReader().getImpinjFastTid(this::updateUi,
                        failure -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_set:
//                boolean blnOpen = (radioGroupOpen.getCheckedRadioButtonId() == R.id.rb_open);
//                boolean blnSave = (radioGroupSave.getCheckedRadioButtonId() == R.id.rb_save);
//                Hawk.put(Key.TID_SAVE, blnSave);
//                mReaderHelper.getReader().setImpinjFastTid(blnOpen, blnSave,
//                        successBean -> promptUi(getString(R.string.set_success)),
//                        errorBean -> promptUi(getString(R.string.set_error)));
                break;
            default:
        }
    }

    private void updateUi(ImpinjFastTid bean) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity != null) {
            activity.runOnUiThread(() -> {
                if (bean.getTidType() == FastTidType.DISABLE) {
                    radioGroupOpen.check(R.id.rb_close);
                } else {
                    radioGroupOpen.check(R.id.rb_open);
                }
                boolean save = Hawk.get(Key.TID_SAVE, false);
                if (save) {
                    radioGroupSave.check(R.id.rb_save);
                } else {
                    radioGroupSave.check(R.id.rb_un_save);
                }
            });
        }
    }

    /**
     * 提示
     *
     * @param msg msg
     */
    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> ToastUtils.makeText(clParent, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
