package com.naz.label.fragments.home.access;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.R;
import com.naz.label.bean.OperationTagBean;

import java.util.List;

/**
 * @author naz
 * Date 2020/4/3
 */
public class AccessTagAdapter extends BaseQuickAdapter<OperationTagBean, BaseViewHolder> {
    public AccessTagAdapter(@Nullable List<OperationTagBean> data) {
        super(R.layout.item_access_tag, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, OperationTagBean item) {
        int count = getData().size();
        helper.setText(R.id.tv_filter_id, String.valueOf(count - helper.getAdapterPosition()));
        helper.setText(R.id.tv_filter_length, item.getPc());
        helper.setText(R.id.tv_crc, item.getCrc());
        helper.setText(R.id.tv_filter_session, item.getEpc());
        helper.setText(R.id.tv_data, item.getData());
        helper.setText(R.id.tv_data_len, String.valueOf(item.getDataLen() & 0xFF));
        helper.setText(R.id.tv_ant_id, String.valueOf(item.getAntId() & 0xFF));
        helper.setText(R.id.tv_filter_action, item.getTimes());
        helper.setText(R.id.other, item.getFreq() + ", rssi = " + item.getRssi() + " dBm");
//        helper.addOnLongClickListener(R.id.cl_parent);
    }

    public void clear() {
        getData().clear();
        notifyDataSetChanged();
    }
}
