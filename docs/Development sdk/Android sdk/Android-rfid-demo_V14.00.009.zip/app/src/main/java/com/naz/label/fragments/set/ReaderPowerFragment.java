package com.naz.label.fragments.set;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.google.android.material.snackbar.Snackbar;
import com.naz.label.R;
import com.naz.label.base.BaseDialogFragment;
import com.naz.label.base.BaseFragment;
import com.naz.label.bean.SetPowerBean;
import com.naz.label.databinding.FragmentReaderPowerBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.XLog;
import com.payne.reader.Reader;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.AntennaCount;
import com.payne.reader.bean.config.Cmd;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.OutputPower;
import com.payne.reader.bean.send.OutputPowerConfig;
import com.payne.reader.bean.send.PowerEightAntenna;
import com.payne.reader.bean.send.PowerFourAntenna;
import com.payne.reader.bean.send.PowerSingleAntenna;
import com.payne.reader.bean.send.PowerSixteenAntenna;

import java.util.ArrayList;
import java.util.List;

public class ReaderPowerFragment extends BaseDialogFragment<FragmentReaderPowerBinding> {
    private ReaderPowerAdapter mAdapter;
    private AntennaCount mAntennaCount;

    private Consumer<Failure> failureConsumer = failure -> promptUi(getString(R.string.read_error));

    @Override
    protected FragmentReaderPowerBinding getViewBinding() {
        return FragmentReaderPowerBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        Context context = getContext();
        mAdapter = new ReaderPowerAdapter(new ArrayList<>());
        binding.rvPower.setLayoutManager(new GridLayoutManager(context, 2));
        binding.rvPower.setAdapter(mAdapter);
        mAntennaCount = ReaderHelper.getReader().getAntennaCount();

        int value = mAntennaCount.getValue();
        for (int i = 0; i < value; i++) {
            mAdapter.addData(new SetPowerBean());
        }
        if (value == 1) {
            binding.tvDesc.setVisibility(View.GONE);
        } else {
            binding.tvDesc.setVisibility(View.VISIBLE);
            BaseQuickAdapter.OnItemLongClickListener onItemLongClickListener = (adapter, view, position) -> {
                if (position == 0) {
                    List<SetPowerBean> list = mAdapter.getData();
                    int power = list.get(0).getPower();
                    for (SetPowerBean spb : list) {
                        spb.setPower(power);
                    }
                    mAdapter.notifyDataSetChanged();
                    return true;
                } else if (position == 8) {
                    List<SetPowerBean> list = mAdapter.getData();
                    int power = list.get(8).getPower();
                    for (int i = 8; i < list.size(); i++) {
                        SetPowerBean spb = list.get(i);
                        spb.setPower(power);
                    }
                    mAdapter.notifyDataSetChanged();
                    return true;
                }
                return false;
            };
            mAdapter.setOnItemLongClickListener(onItemLongClickListener);
        }

        binding.btnGet.setOnClickListener(this::onViewClicked);
        binding.btnSet.setOnClickListener(this::onViewClicked);
    }

    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_get:
                ReaderHelper.getReader().getOutputPower(this::updateUi, failureConsumer);
                break;
            case R.id.btn_set:
                List<SetPowerBean> data = mAdapter.getData();
                if (XLog.isShowLog()) {
                    XLog.i("=======start======= data :" + data);
                }
                int size = data.size();
                byte[] powers = new byte[size];
                for (int i = 0; i < size; i++) {
                    SetPowerBean bean = data.get(i);
                    int power = bean.getPower();
                    if (!SetPowerBean.isValid(power)) {
                        showToast(R.string.input_power);
                        return;
                    }
                    powers[i] = (byte) power;
                }
                OutputPowerConfig config;
                if (mAntennaCount == AntennaCount.FOUR_CHANNELS) {
                    config = OutputPowerConfig.outputPower(new PowerFourAntenna.Builder().powers(powers).build());
                } else if (mAntennaCount == AntennaCount.EIGHT_CHANNELS) {
                    config = OutputPowerConfig.outputPower(new PowerEightAntenna.Builder().powers(powers).build());
                } else if (mAntennaCount == AntennaCount.SIXTEEN_CHANNELS) {
                    config = OutputPowerConfig.outputPower(new PowerSixteenAntenna.Builder().powers(powers).build());
                } else {
                    config = OutputPowerConfig.outputPower(new PowerSingleAntenna.Builder().power(powers[0]).build());
                }
                ReaderHelper.getReader().setOutputPower(config, success -> promptUi(getString(R.string.set_success)), failure -> promptUi(getString(R.string.set_error)));
                break;
            default:
        }
    }

    private void updateUi(OutputPower outputPower) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity != null) {
            Runnable runnable = () -> {
                byte[] powers = outputPower.getOutputPower();
                List<SetPowerBean> data = mAdapter.getData();
                byte power = 33;
                int size = data.size();
                for (int i = 0; i < size; i++) {
                    power = i < powers.length ? powers[i] : power;
                    data.get(i).setPower(power);
                }
                mAdapter.notifyDataSetChanged();
            };
            activity.runOnUiThread(runnable);
        }
    }

    /**
     * 提示
     *
     * @param msg msg
     */
    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null && !isRemoving()) {
            activity.runOnUiThread(() -> Snackbar.make(binding.clParent, msg, Snackbar.LENGTH_SHORT).show());
        }
    }

    @Override
    public void onDestroy() {
        Reader reader = ReaderHelper.getReader();
        reader.removeCallback(Cmd.GET_OUTPUT_POWER);
        reader.removeCallback(Cmd.GET_OUTPUT_POWER_EIGHT);
        super.onDestroy();
    }
}