package com.naz.label.acts;

import android.Manifest;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.bean.type.Key;
import com.naz.label.databinding.ActivitySettingBinding;
import com.naz.label.util.BeeperHelper;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.XLog;
import com.naz.label.widget.AfterTextWatcher;
import com.naz.label.util.StartActivityUtils;
import com.orhanobut.hawk.Hawk;
import com.payne.connect.net.NetworkHandle;
import com.payne.connect.port.SerialPortHandle;
import com.payne.reader.communication.ConnectHandle;
import com.payne.reader.process.ReaderImpl;
import com.tbruyelle.rxpermissions2.Permission;
import com.tbruyelle.rxpermissions2.RxPermissions;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * @author naz
 */
public class SettingActivity extends BaseActivity<ActivitySettingBinding> {
    private RxPermissions rxPermissions;
    private Disposable mDisposable;
    public static volatile boolean sTempTestMode;
    public static volatile boolean sRefreshMode1;
    public static volatile boolean sAntiInterference;

    private AfterTextWatcher mBeepWatcher = new AfterTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            String str = s.toString();
            if (TextUtils.isEmpty(str)) {
                return;
            }
            int value = Integer.parseInt(str);
            Hawk.put(Key.MINI_NUM_BEEP_TIME, value);
        }
    };
    private AfterTextWatcher mCmdWatcher = new AfterTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            String str = s.toString();
            if (TextUtils.isEmpty(str)) {
                return;
            }
            Long timeout = Long.valueOf(str);
            Hawk.put(Key.CMD_TIMEOUT, timeout);

            ReaderHelper.getReader().setCmdTimeout(timeout);
        }
    };
    private AfterTextWatcher mBatteryWatcher = new AfterTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            String str = s.toString();
            if (TextUtils.isEmpty(str)) {
                return;
            }
            int value = Integer.parseInt(str);
            Hawk.put(Key.KEY_POWER, value);
        }
    };
    private TextWatcher mTSWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            String str = s.toString();
            validAndSetTempThreshold(str);
        }
    };

    //<editor-fold desc="validAndSetTempThreshold">
    private void validAndSetTempThreshold(String str) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        str = str.replace("，", ",");
        String[] split = str.split(",");
        if (split.length != 3) {
            binding.etTempThreshold.setError("!");
            return;
        }
        int t;
        int p;
        int ms;
        try {
            t = Integer.parseInt(split[0]);
            p = Integer.parseInt(split[1]);
            ms = Integer.parseInt(split[2]);
        } catch (Exception ignored) {
            return;
        }
        if (p < 0 || p > GlobalCfg.get().getMaxOutPower()) {
            binding.etTempThreshold.setError("!");
            return;
        }
        Hawk.put(Key.KEY_TEMP_THRESHOLD, str);

        binding.tvTempThreshold.setText(String.format("若温度达到%d,则：功率减%d，延时加%dms", t, p, ms));
    }
    //</editor-fold>

    @Override
    protected ActivitySettingBinding getViewBinding() {
        return ActivitySettingBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void initView() {
//        setTitle(R.string.app_name);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        rxPermissions = new RxPermissions(this);

        binding.llBattery.setVisibility(View.GONE);
        binding.llTemp.setVisibility(View.GONE);
        binding.sbTestTemp.setVisibility(View.GONE);
        binding.scAntiInterference.setVisibility(View.GONE);
        binding.scRefreshMode1.setVisibility(View.GONE);
//        binding.etDelayMs.setVisibility(View.GONE);

        boolean longPress = Hawk.get(Key.KEY_F4_LONG_PRESS, true);
        binding.sbEnableLoogPress.setChecked(longPress);
        binding.sbEnableLoogPress.setOnCheckedChangeListener((view, isChecked) -> {
            Hawk.put(Key.KEY_F4_LONG_PRESS, isChecked);
        });

        binding.sbEnableLog.setOnLongClickListener((view) -> {
            binding.llBattery.setVisibility(View.VISIBLE);
            binding.llTemp.setVisibility(View.VISIBLE);

            binding.sbTestTemp.setVisibility(View.VISIBLE);
            binding.sbTestTemp.setChecked(sTempTestMode);

            binding.scAntiInterference.setVisibility(View.VISIBLE);
//            binding.scRefreshMode1.setVisibility(View.VISIBLE);
//            binding.etDelayMs.setVisibility(View.VISIBLE);
            return true;
        });

        boolean enableOpLog = Hawk.get(Key.ENABLE_OPERATE_LOG, false);
        binding.sbEnableLog.setChecked(enableOpLog);
        binding.sbEnableLog.setOnCheckedChangeListener((view, isChecked) -> {
            Hawk.put(Key.ENABLE_OPERATE_LOG, isChecked);
        });

        boolean saveInventoryLog = Hawk.get(Key.SAVE_INVENTORY_LOG, false);
        binding.sbSaveInventoryLog.setChecked(saveInventoryLog);
        binding.sbSaveInventoryLog.setOnCheckedChangeListener((v, isChecked) -> {
            if (isChecked) {
                Consumer<Permission> onNext = permission -> {
                    if (permission.granted) {
                        Hawk.put(Key.SAVE_INVENTORY_LOG, true);
                    } else if (permission.shouldShowRequestPermissionRationale) {
                        v.setChecked(false);
                        showToast(R.string.get_location_permission_fail);
                    } else {
                        v.setChecked(false);
                        new AlertDialog.Builder(this)
                                .setMessage(R.string.get_storage_permission)
                                .setNegativeButton(R.string.cancel, null)
                                .setPositiveButton(R.string.to_open, (dialog, which) -> StartActivityUtils.startPermissionActivity(this))
                                .create()
                                .show();
                    }
                };
                String storage = Manifest.permission.WRITE_EXTERNAL_STORAGE;
                mDisposable = rxPermissions.requestEachCombined(storage).subscribe(onNext);
            } else {
                Hawk.put(Key.SAVE_INVENTORY_LOG, false);
            }
        });
        boolean useSys = Hawk.get(Key.BEEPER_USE_SYS, false);
        binding.sbUseSysRing.setChecked(useSys);
        binding.sbUseSysRing.setOnCheckedChangeListener((v, isChecked) -> {
            Hawk.put(Key.BEEPER_USE_SYS, isChecked);
            BeeperHelper.sUseSysRing = isChecked;
        });

        int beepInterval = Hawk.get(Key.MINI_NUM_BEEP_TIME, 0);
        binding.etBeepInterval.setText(String.valueOf(beepInterval));
        binding.etBeepInterval.addTextChangedListener(mBeepWatcher);

        long cmdTimeout = Hawk.get(Key.CMD_TIMEOUT, 6000L);
        binding.etCmdTimeout.setText(String.valueOf(cmdTimeout));
        binding.etCmdTimeout.addTextChangedListener(mCmdWatcher);

        boolean changeLength = Hawk.get(Key.CMD_CHANGE_EPC_LENGTH, false);
        binding.sbEpcLengthChange.setChecked(changeLength);
        binding.sbEpcLengthChange.setOnCheckedChangeListener((v, isChecked) -> {
            Hawk.put(Key.CMD_CHANGE_EPC_LENGTH, isChecked);
        });

        int bl = Hawk.get(Key.KEY_POWER, 28);
        binding.etBatteryLevel.setText(String.valueOf(bl));
        binding.etBatteryLevel.addTextChangedListener(mBatteryWatcher);

        String ts = Hawk.get(Key.KEY_TEMP_THRESHOLD, "45,3,2000");
        binding.etTempThreshold.addTextChangedListener(mTSWatcher);
        binding.etTempThreshold.setText(ts);

        if (sTempTestMode) {
            binding.sbTestTemp.setVisibility(View.VISIBLE);
            binding.sbTestTemp.setChecked(sTempTestMode);
        }
        binding.sbTestTemp.setOnCheckedChangeListener((v, isChecked) -> {
            sTempTestMode = isChecked;
        });
        binding.scAntiInterference.setChecked(sAntiInterference);
        binding.scAntiInterference.setOnCheckedChangeListener((v, isChecked) -> {
            sAntiInterference = isChecked;
        });
        binding.scRefreshMode1.setChecked(sRefreshMode1);
        binding.scRefreshMode1.setOnCheckedChangeListener((v, isChecked) -> sRefreshMode1 = isChecked);

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        if (mDisposable != null) {
            mDisposable.dispose();
        }
        binding.etBeepInterval.removeTextChangedListener(mBeepWatcher);
        binding.etCmdTimeout.removeTextChangedListener(mCmdWatcher);
        binding.etBatteryLevel.removeTextChangedListener(mBatteryWatcher);
        super.onDestroy();
    }
}