package com.naz.label.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class RightNavView extends View {

    private int mWidth;
    private int mHeight;
    private float mTextWidth;
    private Paint mPaint;
    private int mIndex = 0;
    private OnItemSelectedListener mOnItemSelectedListener;
    private static final String[] INDEX = {
            "定", "热", "A", "B", "C", "D", "E", "F", "G",
            "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q",
            "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
    private float mEventX;
    private float mEventY;
    private boolean isOnTouching;

    public void setOnItemSelectedListener(OnItemSelectedListener l) {
        this.mOnItemSelectedListener = l;
    }

    public interface OnItemSelectedListener {

        void onItemSelecting(int index, String indexStr);

        void onItemSelected(int index, String indexStr);
    }

    public RightNavView(Context context) {

        this(context, null);
    }

    public RightNavView(Context context, AttributeSet attrs) {

        this(context, attrs, 0);
    }

    public RightNavView(Context context, AttributeSet attrs, int defStyle) {

        super(context, attrs, defStyle);

        mPaint = new Paint();
        mPaint.setColor(Color.GRAY);
        mPaint.setAntiAlias(true);
        mPaint.setTextAlign(Paint.Align.CENTER);

        mTextWidth = mPaint.measureText("M");
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        mWidth = MeasureSpec.getSize(widthMeasureSpec);
        mHeight = MeasureSpec.getSize(heightMeasureSpec);
        float textHeight = mHeight / (float) (INDEX.length + 12);
        mPaint.setTextSize(textHeight);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int length = INDEX.length;
        for (int i = 0; i < length; i++) {
            // if (isOnTouching) {
            // 	mPaint.setColor(Color.GRAY);
            // 	canvas.drawLine(mWidth - 4 * mTextWidth, 0, mWidth - 4 * mTextWidth, mHeight, mPaint);
            // }
            if (mIndex == i) {
                // canvas.drawCircle((float) ((mWidth - mTextWidth - 20 + mWidth - mTextWidth) / 2.0), (float) ((mHeight
                // 	/ length * (i + 1) - 40 + mHeight / length * (i + 1) + 10) / 2.0), mTextWidth * 2, mPaint);

                mPaint.setColor(Color.RED);
                if (isOnTouching) {
                    canvas.drawText(INDEX[i], mWidth - mTextWidth - 10 - 120, mHeight / length * (i + 1), mPaint);
                } else {
                    canvas.drawText(INDEX[i], mWidth - mTextWidth - 10, mHeight / length * (i + 1), mPaint);
                }
            } else if (isOnTouching) {
                mPaint.setColor(Color.GRAY);
                if (mIndex == i + 1 || mIndex == i - 1) {
                    canvas.drawText("" + INDEX[i], mWidth - 130, mHeight / length * (i + 1), mPaint);
                } else if (mIndex == i + 2 || mIndex == i - 2) {
                    canvas.drawText("" + INDEX[i], mWidth - 110, mHeight / length * (i + 1), mPaint);
                } else if (mIndex == i + 3 || mIndex == i - 3) {
                    canvas.drawText("" + INDEX[i], mWidth - 90, mHeight / length * (i + 1), mPaint);
                } else if (mIndex == i + 4 || mIndex == i - 4) {
                    canvas.drawText("" + INDEX[i], mWidth - 60, mHeight / length * (i + 1), mPaint);
                } else if (mIndex == i + 5 || mIndex == i - 5) {
                    canvas.drawText("" + INDEX[i], mWidth - 30, mHeight / length * (i + 1), mPaint);
                } else {
                    canvas.drawText(INDEX[i], mWidth - mTextWidth - 10, mHeight / length * (i + 1), mPaint);
                }
            } else {
                mPaint.setColor(Color.GRAY);
                canvas.drawText(INDEX[i], mWidth - mTextWidth - 10, mHeight / length * (i + 1), mPaint);
            }
        }
    }

    public int getIndex() {
        return mIndex;
    }

    public void setIndex(int index) {
        mIndex = index;
        invalidate();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        super.dispatchTouchEvent(event);
        int length = INDEX.length;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                mEventX = event.getX();
                mEventY = event.getY();
                if (mEventX <= mWidth - 4 * mTextWidth) {
                    return false;
                }
                if (mEventX > mWidth - 4 * mTextWidth) {
                    isOnTouching = true;
                    mIndex = (int) (mEventY / (mHeight / length));
                    if (mOnItemSelectedListener != null && mIndex >= 0 && mIndex < length) {
                        mOnItemSelectedListener.onItemSelecting(mIndex, INDEX[mIndex]);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                isOnTouching = false;
                if (mOnItemSelectedListener != null && mIndex >= 0 && mIndex < length) {
                    mOnItemSelectedListener.onItemSelected(mIndex, INDEX[mIndex]);
                }
                // mIndex = -1;
        }
        invalidate();
        return true;
    }
}