package com.naz.label.fragments.set.q;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.naz.label.base.BaseDialogFragment;
import com.naz.label.util.ToastUtils;
import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.databinding.FragmentQBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.InputUtils;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.QMode;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.QInfo;
import com.payne.reader.bean.receive.Success;
import com.payne.reader.bean.receive.Version;

/**
 * @author naz
 * Date 2020/4/8
 */
public class QFragment extends BaseDialogFragment<FragmentQBinding> {
    private Version.ChipType mChipType;

    private Consumer<Success> successConsumer = new Consumer<Success>() {
        @Override
        public void accept(Success success) throws Exception {
            promptUi(getString(R.string.set_success));
        }
    };
    private Consumer<Failure> failureConsumer = new Consumer<Failure>() {
        @Override
        public void accept(Failure failure) throws Exception {
            promptUi(getString(R.string.set_error));
        }
    };

    @Override
    protected FragmentQBinding getViewBinding() {
        return FragmentQBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        mChipType = GlobalCfg.get().getVersion().getChipType();
        if (mChipType != Version.ChipType.E710) {
            return;
        }

        binding.btnGet.setOnClickListener(this::onViewClicked);
        binding.btnSet.setOnClickListener(this::onViewClicked);

        binding.rgQ.setOnCheckedChangeListener((buttonView, checkedId) -> {
            binding.llDynamic.setVisibility(checkedId == R.id.rb_dynamic ? View.VISIBLE : View.GONE);
        });
        binding.rbDynamic.setChecked(false);
    }

    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_get:
                ReaderHelper.getReader().getE710_Q(this::updateUI, failure -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_set:
                QInfo qInfo = new QInfo();
                if (binding.rbFixed.isChecked()) {
                    qInfo.qMode = QMode.FIXED;
                } else {
                    qInfo.qMode = QMode.DYNAMIC;
                }
                try {
                    qInfo.qInit = InputUtils.parseByte(binding.etValue, 10);
                    qInfo.qMin = InputUtils.parseByte(binding.etMin, 10);
                    qInfo.qMax = InputUtils.parseByte(binding.etMax, 10);
                    qInfo.numMinQCycles = InputUtils.parseByte(binding.etNumMinQCycles, 10);
                    qInfo.maxQuerySinceEPC = InputUtils.parseByte(binding.etMaxQuerySinceEPC, 10);
                } catch (Exception e) {
                    return;
                }
                ReaderHelper.getReader().setE710_Q(qInfo, successConsumer, failureConsumer);
                break;
        }
    }

    private void updateUI(QInfo qInfo) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity != null) {
            activity.runOnUiThread(() -> {
                if (qInfo.qMode == QMode.FIXED) {
                    binding.rbFixed.setChecked(true);
                } else {
                    binding.rbDynamic.setChecked(true);
                }
                binding.etValue.setText("" + qInfo.qInit);
                binding.etMin.setText("" + qInfo.qMin);
                binding.etMax.setText("" + qInfo.qMax);
                binding.etNumMinQCycles.setText("" + qInfo.numMinQCycles);
                binding.etMaxQuerySinceEPC.setText("" + qInfo.maxQuerySinceEPC);
            });
        }
    }

    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> {
                try {
                    ToastUtils.makeText(binding.clParent, msg, Toast.LENGTH_SHORT).show();
                } catch (Exception ignored) {
                }
            });
        }
    }

    @Override
    public void onDestroy() {
        binding.btnGet.setOnClickListener(null);
        binding.btnSet.setOnClickListener(null);
        super.onDestroy();
    }
}