package com.naz.label.acts;

import android.content.Intent;
import android.view.MenuItem;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.naz.label.R;
import com.naz.label.base.OldBaseActivity;
import com.naz.label.bean.type.Key;
import com.naz.label.acts.HomeActivity;
import com.naz.label.util.LanguageUtils;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author naz
 */
public class LanguageSwitchActivity extends OldBaseActivity {
    @BindView(R.id.radio_group)
    RadioGroup radioGroup;

    @Override
    public int getLayoutResId() {
        return R.layout.activity_language_switch;
    }

    @Override
    public void initView() {
        this.setTitle(R.string.language_switch);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        int languageType = LanguageUtils.getLanguageType();
        if (languageType == Key.LANGUAGE_TYPE_CHINESE) {
            radioGroup.check(R.id.rb_chinese);
        } else if (languageType == Key.LANGUAGE_TYPE_ENGLISH) {
            radioGroup.check(R.id.rb_english);
        } else {
            radioGroup.check(R.id.rb_normal);
        }
    }

    @OnClick(R.id.btn_set)
    public void onViewClicked() {
        switch (radioGroup.getCheckedRadioButtonId()) {
            case R.id.rb_normal:
                LanguageUtils.putLanguageType(Key.LANGUAGE_TYPE_FOLLOW_SYSTEM);
                break;
            case R.id.rb_chinese:
                LanguageUtils.putLanguageType(Key.LANGUAGE_TYPE_CHINESE);
                break;
            case R.id.rb_english:
                LanguageUtils.putLanguageType(Key.LANGUAGE_TYPE_ENGLISH);
                break;
            default:
                break;
        }
        Intent intent = new Intent(this, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
