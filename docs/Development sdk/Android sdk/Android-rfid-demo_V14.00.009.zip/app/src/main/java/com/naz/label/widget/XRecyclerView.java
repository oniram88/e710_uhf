package com.naz.label.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.naz.label.R;

/**
 * @author naz
 * Date 2021/3/11
 */
public class XRecyclerView extends RecyclerView {
    private int mMaxHeight;
    private int mMaxWidth;

    public XRecyclerView(Context context) {
        this(context, null);
    }

    public XRecyclerView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XRecyclerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        inti(context, attrs);
    }

    private void inti(Context context, AttributeSet attrs) {
        TypedArray typedArray = null;
        try {
            typedArray = context.obtainStyledAttributes(attrs, R.styleable.XRecyclerView);
            if (typedArray.hasValue(R.styleable.XRecyclerView_limit_maxHeight)) {
                mMaxHeight = typedArray.getDimensionPixelOffset(R.styleable.XRecyclerView_limit_maxHeight, -1);
            }
            if (typedArray.hasValue(R.styleable.XRecyclerView_limit_maxWidth)) {
                mMaxWidth = typedArray.getDimensionPixelOffset(R.styleable.XRecyclerView_limit_maxWidth, -1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (typedArray != null) {
                typedArray.recycle();
            }
        }
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        super.onMeasure(widthSpec, heightSpec);
        int limitHeight = getMeasuredHeight();
        int limitWith = getMeasuredWidth();
        if (mMaxHeight > 0 && limitHeight > mMaxHeight) {
            limitHeight = mMaxHeight;
        }
        if (mMaxWidth > 0 && limitWith > mMaxWidth) {
            limitWith = mMaxWidth;
        }
        setMeasuredDimension(limitWith, limitHeight);
    }
}
