package com.naz.label.base;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewbinding.ViewBinding;

import com.naz.label.util.XLog;

@SuppressLint("ValidFragment")
public abstract class BaseDialogFragment<T extends ViewBinding> extends DialogFragment {
    private static final String TAG = "dialog";
    protected T binding;

    private boolean mIsNeedFullScreen;
    private int mGravity = -1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = getViewBinding();
    }

    protected abstract T getViewBinding();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (binding != null) {
            View root = binding.getRoot();
            initView(root, inflater, container);
            return root;
        }
        return null;
    }

    public abstract void initView(View parent, LayoutInflater inflater, ViewGroup container);

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog == null) {
            return;
        }
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return;
        }
        Window dialogWindow = dialog.getWindow();
        if (dialogWindow == null) {
            return;
        }
        if (mIsNeedFullScreen) {
            View decorView = dialogWindow.getDecorView();
            dialogWindow.setFlags(
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

            decorView.setPadding(0, 0, 0, 0);
            decorView.setBackgroundColor(Color.WHITE);
            dialogWindow.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        } else {
            dialogWindow.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (mGravity != -1) {
                WindowManager.LayoutParams wlp = dialogWindow.getAttributes();
                wlp.gravity = mGravity;
                dialogWindow.setAttributes(wlp);
            }
        }
    }

    public BaseDialogFragment show(FragmentActivity activity) {
        return show(activity, false, Gravity.CENTER);
    }

    private BaseDialogFragment show(FragmentActivity activity, boolean isNeedFullScreen, int gravity) {
        if (!isNeedFullScreen) {
            mGravity = gravity;
        }
        mIsNeedFullScreen = isNeedFullScreen;
        FragmentManager manager = activity.getSupportFragmentManager();
        // Fragment fragment = manager.findFragmentByTag(TAG);
        // if (fragment != null) {
        // 	manager.beginTransaction().remove(fragment).commitAllowingStateLoss();
        // }

        try {
            show(manager, TAG);
        } catch (Throwable e) {
            XLog.w(Log.getStackTraceString(e));
        }
        return this;
    }

    @Override
    public void dismiss() {
        super.dismissAllowingStateLoss();
    }

    @Override
    public void onDestroy() {
        binding = null;
        super.onDestroy();
    }

    /**
     * @param msg 内容
     */
    protected void showToast(String msg) {
        Activity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * @param strResId 文字资源Id
     */
    protected void showToast(@StringRes int strResId) {
        Activity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> Toast.makeText(activity, getString(strResId), Toast.LENGTH_SHORT).show());
        }
    }
}