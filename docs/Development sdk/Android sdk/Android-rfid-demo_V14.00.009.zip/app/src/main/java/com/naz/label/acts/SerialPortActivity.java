package com.naz.label.acts;

import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.bean.type.Key;
import com.naz.label.bean.type.LinkType;
import com.naz.label.databinding.ActivitySerialPortBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.PowerUtils;
import com.naz.label.util.XLog;
import com.naz.serial.port.SerialPortFinder;
import com.orhanobut.hawk.Hawk;
import com.payne.connect.port.SerialPortHandle;
import com.payne.reader.Reader;
import com.payne.reader.bean.receive.Version;
import com.payne.reader.communication.ConnectHandle;
import com.payne.reader.util.ThreadPool;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;

public class SerialPortActivity extends BaseActivity<ActivitySerialPortBinding> {
    private ConnectHandle mConnectHandle;
    private boolean mPowerOn;
    private String mDevicePath;
    private int mBaudRate;
    private InnerHandler mH = new InnerHandler(this);

    private static class InnerHandler extends Handler {
        private final int MSG_CONNECT = 0;
        private WeakReference<SerialPortActivity> mWr;

        InnerHandler(SerialPortActivity a) {
            mWr = new WeakReference<>(a);
        }

        @Override
        public void handleMessage(Message msg) {
            SerialPortActivity a = mWr.get();
            if (a == null || a.isFinishing()) {
                return;
            }
            switch (msg.what) {
                case MSG_CONNECT:
                    a.toConnect(true);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    protected ActivitySerialPortBinding getViewBinding() {
        return ActivitySerialPortBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView() {
        setTitle(R.string.serial_connection);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(false);
        }

        SerialPortFinder portFinder = new SerialPortFinder();
        String[] devicesPath = portFinder.getAllDevicesPath();

        ArrayList<String> list = new ArrayList<>();
        if (devicesPath == null || devicesPath.length == 0) {
            list.add("/dev/ttyS0");
            list.add("/dev/ttyS1");
            list.add("/dev/ttyS2");
            list.add("/dev/ttyS3");
            list.add("/dev/ttyS4");
        } else {
            list.addAll(Arrays.asList(devicesPath));
        }

        SpinnerAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        binding.spSerialNumber.setAdapter(adapter);

        String lastDevicePath = Hawk.get(Key.KEY_DEVICE_PATH, "ttyS4");
        String normalDevice = "ttyAS3";
        int length = list.size();
        for (int i = 0; i < length; i++) {
            String str = list.get(i);
            if (str.contains(lastDevicePath) || str.contains(normalDevice)) {
                binding.spSerialNumber.setSelection(i);
                break;
            }
        }
        String baudRateStr = Hawk.get(Key.KEY_BAUD_RATE, "115200");
        switch (baudRateStr) {
            case "38400":
                binding.rbBaudRate38400.setChecked(true);
                binding.rbBaudRate38400.setVisibility(View.VISIBLE);
                break;
            case "115200":
                binding.rbBaudRate115200.setChecked(true);
                binding.rbBaudRate115200.setVisibility(View.VISIBLE);
                break;
            case "921600":
                binding.rbBaudRate921600.setChecked(true);
                binding.rbBaudRate921600.setVisibility(View.VISIBLE);
                break;
        }

        binding.tvBaudRate.setOnLongClickListener(v -> {
            binding.rbBaudRate38400.setVisibility(View.VISIBLE);
            binding.rbBaudRate115200.setVisibility(View.VISIBLE);
            binding.rbBaudRate921600.setVisibility(View.VISIBLE);
            return true;
        });
        binding.btnConnect.setOnClickListener(v -> {
            binding.btnConnect.setEnabled(false);
            binding.pb.setVisibility(View.VISIBLE);
            toConnect(true);
        });
        binding.btnConnect.setOnLongClickListener(v -> {
            binding.btnConnect.setEnabled(false);
            binding.pb.setVisibility(View.VISIBLE);
            toConnect(false);
            return true;
        });
        binding.btnOther.setOnClickListener(v -> {
            new SwitchConnectFragment().show(this);
        });
    }

    public void toConnect(boolean needCheck) {
        mPowerOn = PowerUtils.powerOn();
        XLog.i("powerOn:" + mPowerOn);

        mDevicePath = (String) binding.spSerialNumber.getSelectedItem();
        TextView view = findViewById(binding.groupBaudRate.getCheckedRadioButtonId());
        String text = view.getText().toString();
        mBaudRate = Integer.parseInt(text);

        XLog.i("To Connect: " + mDevicePath + ", " + mBaudRate);

        mConnectHandle = new SerialPortHandle(mDevicePath, mBaudRate);
        boolean connectSuccess = ReaderHelper.getReader().connect(mConnectHandle);

        if (needCheck && !connectSuccess) {
            showToast(R.string.serial_connect_failed);
            binding.pb.setVisibility(View.INVISIBLE);
            binding.btnConnect.setEnabled(true);
            return;
        }

        GlobalCfg globalCfg = GlobalCfg.get();
        globalCfg.setLinkType(LinkType.LINK_TYPE_SERIAL_PORT);
        if (!needCheck) {
            Version version = new Version();
            version.setVersion("...");
            version.setChipType(Version.ChipType.E710);
            globalCfg.setVersion(version);
        }

        Hawk.put(Key.KEY_LINK_TYPE, LinkType.LINK_TYPE_SERIAL_PORT);
        Hawk.put(Key.KEY_DEVICE_PATH, mDevicePath);
        Hawk.put(Key.KEY_BAUD_RATE, text);

        HomeActivity.start(this);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!ReaderHelper.getReader().isConnected()) {
            LinkType linkType = Hawk.get(Key.KEY_LINK_TYPE, null);
            if (linkType == LinkType.LINK_TYPE_SERIAL_PORT) {
                binding.btnConnect.setEnabled(false);
                binding.pb.setVisibility(View.VISIBLE);
                mH.sendEmptyMessageDelayed(mH.MSG_CONNECT, 1000);
                return;
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        XLog.i("onBackPressed");
        if (mH != null) {
            mH.removeCallbacksAndMessages(null);
        }
        if (!binding.btnConnect.isEnabled()) {
            return;
        }
        if (mConnectHandle != null) {
            mConnectHandle.onDisconnect();
            mConnectHandle = null;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mH = null;
    }
}