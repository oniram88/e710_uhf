package com.naz.label.fragments.set;

import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.naz.label.bean.type.Key;
import com.naz.label.fragments.set.gpio.ReaderGpioFragment;
import com.naz.label.fragments.set.q.QFragment;
import com.naz.label.fragments.set.region.ReaderRegionFragment;
import com.naz.label.util.FastClickUtils;
import com.naz.label.util.ToastUtils;
import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseFragment;
import com.naz.label.bean.type.LinkType;
import com.naz.label.databinding.FragmentReaderCfgBinding;
import com.naz.label.util.BeeperHelper;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.Utils;
import com.naz.label.widget.ConvenientSeekBar;
import com.naz.label.util.InputUtils;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.reader.Reader;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.AntennaCount;
import com.payne.reader.bean.config.Beeper;
import com.payne.reader.bean.config.ProfileId;
import com.payne.reader.bean.receive.AntConnectionDetector;
import com.payne.reader.bean.receive.E710LinkProfile;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.OutputPower;
import com.payne.reader.bean.receive.ReaderIdentifier;
import com.payne.reader.bean.receive.ReaderStatus;
import com.payne.reader.bean.receive.ReaderTemperature;
import com.payne.reader.bean.receive.RfLinkProfile;
import com.payne.reader.bean.receive.RfPortReturnLoss;
import com.payne.reader.bean.receive.Success;
import com.payne.reader.bean.receive.Version;
import com.payne.reader.bean.receive.WorkAntenna;
import com.payne.reader.bean.send.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author naz
 * Date 2020/4/7
 */
public class ReaderCfgFragment extends BaseFragment<FragmentReaderCfgBinding> {
    private static ReaderCfgFragment sFragment;

    private HashMap<ProfileId, Integer> mCbMap = new HashMap<>();

    private Consumer<Success> setSuccessConsumer = success -> {
        promptUi(getString(R.string.set_success));
    };
    private Consumer<Failure> setFailureConsumer = failure -> {
        promptUi(getString(R.string.set_error));
    };
    private Consumer<Failure> getFailureConsumer = failure -> {
        promptUi(getString(R.string.read_error));
    };

    //<editor-fold desc="versionConsumer">
    private Consumer<Version> versionConsumer = version -> {
        GlobalCfg.get().setVersion(version);

        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> {
                String text = getString(R.string.get_reader_firmware_version);

                Version.ChipType chipType = version.getChipType();
                if (chipType == null) {
                    text = text + " " + version.getVersion();
                    binding.btnGetFwVersion.setText(text);
                } else {
                    text = text + " " + chipType + "," + version.getVersion();
                    binding.btnGetFwVersion.setText(text);
                    showHide(version);
                }
            });
        }
    };
    //</editor-fold>

    //<editor-fold desc="power SeekBar L">
    private ConvenientSeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new ConvenientSeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(ConvenientSeekBar seekBar, int progress, boolean fromUser) {

        }

        @Override
        public void onStartTrackingTouch(ConvenientSeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(ConvenientSeekBar seekBar) {
            int progress = seekBar.getProgress();
            /* 推荐设置为临时功率，掉电后会恢复原值。另一个方法设置功率，会降低Flash使用寿命 */
            ReaderHelper.getReader().setOutputPowerUniformly((byte) progress, setSuccessConsumer, setFailureConsumer);
        }
    };
    //</editor-fold>

    //<editor-fold desc="mL">
    private View.OnClickListener mL = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int id = v.getId();
            switch (id) {
                case R.id.btn_get_fw_version: {
                    getFwVersion();
                }
                break;
                case R.id.btn_get_temp: {
                    ReaderHelper.getReader().getReaderTemperature(ReaderCfgFragment.this::updateTempUi, getFailureConsumer);
                }
                break;
                case R.id.btnGetAnt: {
                    ReaderHelper.getReader().getWorkAntenna(mWorkAntennaConsumer, mAntFailConsumer);
                }
                break;
                case R.id.btnSetAnt: {
                    Reader reader = ReaderHelper.getReader();
                    int antCount = reader.getAntennaCount().getValue();
                    int antId = Utils.parseInt(binding.etAnt, 0);
                    if (antId < 1 || antId > antCount) {
                        binding.etAnt.setError("!");
                    } else {
                        antId = antId - 1;
                        reader.setWorkAntenna(antId, setSuccessConsumer, setFailureConsumer);
                    }
                }
                break;
                case R.id.btnToFlash: {
                    if (FastClickUtils.isFastClick()) {
                        return;
                    }
                    new ReaderPowerFragment().show(getActivity());
                }
                break;

                case R.id.btn_get_power: {
                    getOutputPower();
                }
                break;
                case R.id.btn_set_address: {
                    setAddress();
                }
                break;
                case R.id.btn_set_buzzing: {
                    setBeeper();
                }
                break;
                case R.id.btn_get_return_loss: {
                    byte pos = (byte) binding.spinnerReturnLoss.getSelectedItemPosition();
                    ReaderHelper.getReader().getRfPortReturnLoss(pos, ReaderCfgFragment.this::updateRLUi, getFailureConsumer);
                }
                break;
                case R.id.btn_get_identify: {
                    ReaderHelper.getReader().getReaderIdentifier(ReaderCfgFragment.this::updateIdentifierUi, getFailureConsumer);
                }
                break;
                case R.id.btn_set_identify: {
                    setIdentifier();
                }
                break;
                case R.id.btn_get_link: {
                    getLink();
                }
                break;
                case R.id.btn_set_link: {
                    setLink();
                }
                break;
                case R.id.btn_get_status: {
                    ReaderHelper.getReader().getReaderStatus(readerStatus -> updateStatusUi(readerStatus), getFailureConsumer);
                }
                break;
                case R.id.btn_set_status: {
                    setStatus();
                }
                break;
                case R.id.btn_get_sensitivity: {
                    ReaderHelper.getReader().getAntConnectionDetector(ReaderCfgFragment.this::updateSsUi, getFailureConsumer);
                }
                break;
                case R.id.btn_set_sensitivity: {
                    String str = binding.etSetSensitivity.getText().toString();
                    if (TextUtils.isEmpty(str)) {
                        return;
                    }
                    int value = Integer.parseInt(str);
                    if (value < 0 || value > 255) {
                        binding.etSetSensitivity.setError(getString(R.string.incorrect_value));
                        return;
                    }
                    ReaderHelper.getReader().setAntConnectionDetector((byte) value, setSuccessConsumer, setFailureConsumer);
                    InputUtils.hideInputMethod(XLog.sContext, binding.etSetSensitivity);
                }
                break;
                case R.id.btn_q: {
                    if (FastClickUtils.isFastClick()) {
                        return;
                    }
                    new QFragment().show(getActivity());
                }
                break;
                case R.id.btn_gpio: {
                    if (FastClickUtils.isFastClick()) {
                        return;
                    }
                    new ReaderGpioFragment().show(getActivity());
                }
                break;
                case R.id.btn_rf_param: {
                    if (FastClickUtils.isFastClick()) {
                        return;
                    }
                    new ReaderRegionFragment().show(getActivity());
                }
                break;
            }
        }
    };
    //</editor-fold>

    //<editor-fold desc="Ant">
    private Consumer<WorkAntenna> mWorkAntennaConsumer = new Consumer<WorkAntenna>() {
        @Override
        public void accept(WorkAntenna workAntenna) throws Exception {
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    int antId = workAntenna.getWorkAntenna() + 1;
                    binding.etAnt.setText("" + antId);

                    Reader reader = ReaderHelper.getReader();
                    int antCount = reader.getAntennaCount().getValue();
                    if (antId > antCount) {
                        if (antId > 8) {
                            binding.spAntCount.setSelectedIndex(3);
                            reader.switchAntennaCount(AntennaCount.SIXTEEN_CHANNELS);
                        } else if (antId > 4) {
                            binding.spAntCount.setSelectedIndex(2);
                            reader.switchAntennaCount(AntennaCount.EIGHT_CHANNELS);
                        } else if (antId > 1) {
                            binding.spAntCount.setSelectedIndex(1);
                            reader.switchAntennaCount(AntennaCount.FOUR_CHANNELS);
                        } else {
                            binding.spAntCount.setSelectedIndex(0);
                            reader.switchAntennaCount(AntennaCount.SINGLE_CHANNEL);
                        }
                    }
                }
            };
            getActivity().runOnUiThread(runnable);
        }
    };
    private Consumer<Failure> mAntFailConsumer = new Consumer<Failure>() {
        @Override
        public void accept(Failure failure) throws Exception {
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    binding.etAnt.setText("");
                }
            };
            getActivity().runOnUiThread(runnable);
        }
    };
    //</editor-fold>

    public ReaderCfgFragment() {
        sFragment = this;
    }

    public static ReaderCfgFragment get() {
        return sFragment;
    }

    @Override
    protected FragmentReaderCfgBinding getViewBinding() {
        return FragmentReaderCfgBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        binding.btnGetFwVersion.setOnClickListener(mL);
        binding.btnGetTemp.setOnClickListener(mL);

        binding.spAntCount.setOnSpinnerItemSelectedListener((parent1, view, position, id) -> {
            AntennaCount count = Utils.getAntEnumByIndex(position);
            ReaderHelper.getReader().switchAntennaCount(count);
        });
        binding.btnGetAnt.setOnClickListener(mL);
        binding.btnSetAnt.setOnClickListener(mL);

        binding.btnToFlash.setOnClickListener(mL);
        binding.csb.setOnSeekBarChangeListener(onSeekBarChangeListener);
        binding.btnGetPower.setOnClickListener(mL);

        binding.btnSetBuzzing.setOnClickListener(mL);

        binding.btnGetReturnLoss.setOnClickListener(mL);
        SpannableString ss = new SpannableString("RL: 0 @");
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(Color.BLACK);
        ss.setSpan(colorSpan, 0, 3, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        binding.tvRl.setText(ss);

        binding.btnGetIdentify.setOnClickListener(mL);
        binding.btnSetIdentify.setOnClickListener(mL);
        binding.btnSetAddress.setOnClickListener(mL);

        binding.btnGetLink.setOnClickListener(mL);
        binding.btnSetLink.setOnClickListener(mL);

        binding.btnGetStatus.setOnClickListener(mL);
        binding.btnSetStatus.setOnClickListener(mL);

        binding.btnGetSensitivity.setOnClickListener(mL);
        binding.btnSetSensitivity.setOnClickListener(mL);

        binding.btnQ.setOnClickListener(mL);
        binding.btnGpio.setOnClickListener(mL);
        binding.btnRfParam.setOnClickListener(mL);
    }

    private void showHide(Version version) {
        if (version == null) {
            return;
        }
        Version.ChipType chipType = version.getChipType();
        if (chipType == null) {
            return;
        }
        switch (chipType) {
            case R2000:
                binding.cardLink.setVisibility(View.VISIBLE);
                break;
            case E710:
                binding.cardLink.setVisibility(View.VISIBLE);
                binding.btnQ.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void getFwVersion() {
        ReaderHelper.getReader().getFirmwareVersion(versionConsumer, getFailureConsumer);
    }

    private void getOutputPower() {
        Consumer<OutputPower> getPowerConsumer = new Consumer<OutputPower>() {
            @Override
            public void accept(OutputPower outputPower) throws Exception {
                FragmentActivity activity = getActivity();
                if (activity != null) {
                    promptUi(getString(R.string.read_success));
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            byte[] powers = outputPower.getOutputPower();
                            int antId = Utils.parseInt(binding.etAnt, 1) - 1;
                            if (powers.length > antId) {
                                binding.csb.setProgress(powers[antId]);
                            } else {
                                binding.csb.setProgress(powers[0]);
                            }
                        }
                    });
                }
            }
        };
        ReaderHelper.getReader().getOutputPower(getPowerConsumer, getFailureConsumer);
    }

    private void setAddress() {
        byte b;
        try {
            b = (byte) InputUtils.parseInt(binding.etAddress, 16);
        } catch (Exception e) {
            return;
        }
        byte maxV = (byte) 0xFF;
        if ((b & 0xFF) >= (maxV & 0xFF)) {
            binding.etAddress.setError("!");
            return;
        }
        ReaderHelper.getReader().setReaderAddress(b, setSuccessConsumer, setFailureConsumer);
        InputUtils.hideInputMethod(XLog.sContext, binding.etAddress);
    }

    private void setBeeper() {
        if (binding.rgBeep.getCheckedRadioButtonId() == R.id.rb_after_sound) {
            BeeperHelper.setBeeperType(Beeper.ONCE_END_BEEP);
            Hawk.put(Key.MINI_NUM_BEEP_TIME, 0);

            if (GlobalCfg.get().getLinkType() == LinkType.LINK_TYPE_NET) {
                ReaderHelper.getReader().setBeeperMode(Beeper.ONCE_END_BEEP, setSuccessConsumer, setFailureConsumer);
            } else {
                ReaderHelper.getReader().setBeeperMode(Beeper.QUIET, setSuccessConsumer, setFailureConsumer);/*非网口，禁止蜂鸣*/
            }
        } else if (binding.rgBeep.getCheckedRadioButtonId() == R.id.rb_every_sound) {
            BeeperHelper.setBeeperType(Beeper.PER_TAG_BEEP);
            Hawk.put(Key.MINI_NUM_BEEP_TIME, 100);

            if (GlobalCfg.get().getLinkType() == LinkType.LINK_TYPE_NET) {
                ReaderHelper.getReader().setBeeperMode(Beeper.PER_TAG_BEEP, setSuccessConsumer, setFailureConsumer);
            } else {
                ReaderHelper.getReader().setBeeperMode(Beeper.QUIET, setSuccessConsumer, setFailureConsumer);/*非网口，禁止蜂鸣*/
            }
        } else {
            BeeperHelper.setBeeperType(Beeper.QUIET);
            Hawk.put(Key.MINI_NUM_BEEP_TIME, 0);

            ReaderHelper.getReader().setBeeperMode(Beeper.QUIET, setSuccessConsumer, setFailureConsumer);/*禁止蜂鸣*/
        }
    }

    private void setIdentifier() {
        String str = binding.etSetIdentify.getText().toString().trim();
        XLog.i("str:" + str);
        if (TextUtils.isEmpty(str)) {
            binding.etSetIdentify.setError(getString(R.string.prompt_reader_identify_empty));
            return;
        }
        if (str.length() >= 24) {
            InputUtils.hideInputMethod(XLog.sContext, binding.etSetIdentify);
        } else {
            binding.etSetIdentify.setError(getString(R.string.incorrect_data_length));
            return;
        }

        Identifier identifier = new Identifier.Builder()
                .setIdentifiers(str)
                .build();
        ReaderHelper.getReader().setReaderIdentifier(identifier, setSuccessConsumer, setFailureConsumer);
    }

    private void buildMap() {
        if (mCbMap.size() != 0) {
            return;
        }
        mCbMap.put(ProfileId.PROFILE_0, R.id.rb_option0);
        mCbMap.put(ProfileId.PROFILE_1, R.id.rb_option1);
        mCbMap.put(ProfileId.PROFILE_2, R.id.rb_option2);
        mCbMap.put(ProfileId.PROFILE_3, R.id.rb_option3);

        mCbMap.put(ProfileId.PROFILE_E710_103, R.id.rbE710_103);
        mCbMap.put(ProfileId.PROFILE_E710_241, R.id.rbE710_241);
        mCbMap.put(ProfileId.PROFILE_E710_244, R.id.rbE710_244);
        mCbMap.put(ProfileId.PROFILE_E710_285, R.id.rbE710_285);
    }

    private void getLink() {
        buildMap();

        Version version = GlobalCfg.get().getVersion();
        if (version == null) {
            return;
        }
        Version.ChipType chipType = version.getChipType();
        switch (chipType) {
            case R2000: {
                ReaderHelper.getReader().getRfLinkProfile(this::updateUIR2000, getFailureConsumer);
            }
            break;
            case E710: {
                ReaderHelper.getReader().getE710LinkProfile(this::updateUIE710, getFailureConsumer);
            }
            break;
        }
    }

    private void setLink() {
        int buttonId;
        Version.ChipType chipType = GlobalCfg.get().getVersion().getChipType();
        if (chipType == Version.ChipType.R2000) {
            buttonId = binding.rgR2000.getCheckedRadioButtonId();
        } else {
            buttonId = binding.rgE710.getCheckedRadioButtonId();
        }
        if (!mCbMap.containsValue(buttonId)) {
            return;
        }
        ProfileId profileId = null;
        Set<Map.Entry<ProfileId, Integer>> entrySet = mCbMap.entrySet();
        for (Map.Entry<ProfileId, Integer> entry : entrySet) {
            if (entry.getValue() == buttonId) {
                profileId = entry.getKey();
            }
        }

        if (chipType == Version.ChipType.R2000) {
            ReaderHelper.getReader().setRfLinkProfile(profileId, setSuccessConsumer, setFailureConsumer);
        } else {
            byte drMode = (byte) (binding.cbDRMode.isChecked() ? 0x01 : 0x00);
            ReaderHelper.getReader().setE710LinkProfile(profileId, drMode, setSuccessConsumer, setFailureConsumer);
        }
    }

    private void updateStatusUi(ReaderStatus readerStatus) {
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return;
        }
        promptUi(getString(R.string.read_success));
        byte status = readerStatus.getStatus();
        String strTemp = String.format("%02X", status);
        activity.runOnUiThread(() -> binding.etSetStatus.setText(strTemp));
    }

    private void setStatus() {
        byte b;
        try {
            b = (byte) InputUtils.parseInt(binding.etSetStatus, 16);
        } catch (Exception e) {
            return;
        }
        ReaderHelper.getReader().setReaderStatus(b, setSuccessConsumer, setFailureConsumer);
    }

    private void updateSsUi(AntConnectionDetector detector) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            promptUi(getString(R.string.read_success));
            int antDetector = detector.getAntDetector() & 0xFF;
            activity.runOnUiThread(() -> binding.etSetSensitivity.setText(String.valueOf(antDetector)));
        }
    }

    private void updateUIR2000(RfLinkProfile bean) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            promptUi(getString(R.string.read_success));
            activity.runOnUiThread(() -> {
                binding.cv1.setVisibility(View.VISIBLE);
                binding.cvE710.setVisibility(View.GONE);

                binding.cbDRMode.setVisibility(View.GONE);

                ProfileId linkProfile = bean.getLinkProfile();
                if (linkProfile == ProfileId.PROFILE_0) {
                    binding.rgR2000.check(R.id.rb_option0);
                } else if (linkProfile == ProfileId.PROFILE_1) {
                    binding.rgR2000.check(R.id.rb_option1);
                } else if (linkProfile == ProfileId.PROFILE_2) {
                    binding.rgR2000.check(R.id.rb_option2);
                } else if (linkProfile == ProfileId.PROFILE_3) {
                    binding.rgR2000.check(R.id.rb_option3);
                }
            });
        }
    }

    private void updateUIE710(E710LinkProfile bean) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            promptUi(getString(R.string.read_success));
            activity.runOnUiThread(() -> {
                ProfileId profileId = bean.getLinkProfile();
                Integer id = mCbMap.get(profileId);
                if (id != null) {
                    binding.cv1.setVisibility(View.GONE);
                    binding.cvE710.setVisibility(View.VISIBLE);
                    binding.rgE710.check(id);

                    binding.cbDRMode.setVisibility(View.VISIBLE);
                    boolean checked = bean.getDrMode() == 0x01;
                    binding.cbDRMode.setChecked(checked);
                } else {
                    setE710DefaultLink();
                }
            });
        }
    }

    /*有的旧机型不支持F指令，需要先设置一次*/
    private void setE710DefaultLink() {
        byte drMode = 0x00;
        ReaderHelper.getReader().setE710LinkProfile(ProfileId.PROFILE_E710_244, drMode, success -> {
            promptUi(getString(R.string.read_error) + "...");
        }, null);
    }

    private void updateRLUi(RfPortReturnLoss returnLossBean) {
        int returnLoss = returnLossBean.getReturnLoss();
        FragmentActivity activity = getActivity();
        if (activity != null) {
            promptUi(getString(R.string.read_success));
            activity.runOnUiThread(() -> {
                SpannableString ss = new SpannableString("RL: " + (returnLoss & 0xFF) + "@");
                ForegroundColorSpan colorSpan = new ForegroundColorSpan(Color.BLACK);
                ss.setSpan(colorSpan, 0, 3, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                binding.tvRl.setText(ss);
            });
        }
    }

    private void updateTempUi(ReaderTemperature readerTemperature) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> {
                int temperature = readerTemperature.getTemperature();
                String text = getString(R.string.read_temp_tag) + temperature + "℃";
                binding.btnGetTemp.setText(text);
            });
        }
    }

    private void updateIdentifierUi(ReaderIdentifier readerIdentifier) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            promptUi(getString(R.string.read_success));
            String identifier = readerIdentifier.getIdentifier().trim().replace(" ", "");
            activity.runOnUiThread(() -> binding.etSetIdentify.setText(identifier));
        }
    }

    private void promptUi(String msg) {
        if ("main".equals(Thread.currentThread().getName())) {
            ToastUtils.makeText(binding.clParent, msg, Toast.LENGTH_SHORT).show();
        } else {
            FragmentActivity activity = getActivity();
            if (activity != null) {
                activity.runOnUiThread(() -> ToastUtils.makeText(binding.clParent, msg, Toast.LENGTH_SHORT).show());
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshUI();
    }

    boolean first = true;

    public void refreshUI() {
        if (first) {
            first = false;
            getFwVersion();
            getOutputPower();
        }
        Reader reader = ReaderHelper.getReader();
        AntennaCount antennaCount = reader.getAntennaCount();
        int index = Utils.getIndexByAntEnum(antennaCount);
        binding.spAntCount.setSelectedIndex(index);

        byte address = reader.getReaderAddress();
        String text = String.format("%02X", address);
        if (!text.equals("FF")) {
            binding.etAddress.setText(text);
        }

        int maxOutPower = GlobalCfg.get().getMaxOutPower();
        binding.csb.setMax(maxOutPower);

        Beeper beeperType = BeeperHelper.getBeeperType();
        if (beeperType == Beeper.ONCE_END_BEEP) {
            binding.rgBeep.check(R.id.rb_after_sound);
        } else if (beeperType == Beeper.PER_TAG_BEEP) {
            binding.rgBeep.check(R.id.rb_every_sound);
        } else {
            binding.rgBeep.check(R.id.rb_quiet);
        }
    }
}
