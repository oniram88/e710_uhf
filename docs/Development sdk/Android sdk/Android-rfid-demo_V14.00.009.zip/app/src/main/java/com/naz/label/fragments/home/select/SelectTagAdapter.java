package com.naz.label.fragments.home.select;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.naz.label.R;
import com.naz.label.databinding.ItemSelectTagBinding;
import com.payne.reader.bean.receive.MaskInfo;

import java.util.List;

/**
 * @author naz
 * Date 2020/11/24
 */
public class SelectTagAdapter extends RecyclerView.Adapter<SelectTagAdapter.SelectTagViewHolder> {
    private List<MaskInfo> mData;
    private final String[] mMaskIds;
    private final String[] mMaskSessions;
    private final String[] mMaskActions;
    private final String[] mMaskAreas;

    public SelectTagAdapter(Context context, @NonNull List<MaskInfo> data) {
        this.mData = data;
        mMaskIds = context.getResources().getStringArray(R.array.mask_no);
        mMaskSessions = context.getResources().getStringArray(R.array.mask_target);
        mMaskActions = context.getResources().getStringArray(R.array.mask_action);
        mMaskAreas = context.getResources().getStringArray(R.array.mask_membank);
    }

    public void setData(@NonNull List<MaskInfo> data) {
        this.mData = data;
        notifyDataSetChanged();
    }

    public List<MaskInfo> getData() {
        return mData;
    }

    public void clearData() {
        this.mData.clear();
        notifyDataSetChanged();
    }

    public void addData(@NonNull MaskInfo info) {
        this.mData.add(info);
        notifyItemInserted(mData.size() - 1);
    }

    @NonNull
    @Override
    public SelectTagViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemSelectTagBinding binding = ItemSelectTagBinding.inflate(LayoutInflater.from(parent.getContext()));
        return new SelectTagViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectTagViewHolder holder, int position) {
        MaskInfo info = mData.get(position);
        holder.binding.tvFilterId.setText(mMaskIds[info.getMaskId().getValue() - 1]);
        holder.binding.tvFilterSession.setText(mMaskSessions[info.getMaskTarget().getValue()]);
        holder.binding.tvFilterAction.setText(mMaskActions[info.getMaskAction().getValue()]);
        holder.binding.tvFilterArea.setText(mMaskAreas[info.getMemBank().getValue()]);
        holder.binding.tvFilterStartAddress.setText(String.valueOf(info.getMaskBitStartAddress()));
        holder.binding.tvFilterLength.setText(String.valueOf(info.getMaskBitLength()));
        holder.binding.tvFilterValue.setText(info.getMaskValue());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    static class SelectTagViewHolder extends RecyclerView.ViewHolder {
        private final ItemSelectTagBinding binding;

        public SelectTagViewHolder(@NonNull ItemSelectTagBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
