package com.naz.label.acts.log;


import android.content.Context;
import android.view.View;

import com.naz.label.adapter.BaseMultiItemRecyclerAdapter;
import com.naz.label.adapter.BaseViewHolder;
import com.naz.label.databinding.ItemActLogBinding;

/**
 * @author gpenghui
 * date 2018/5/11
 */

public class LogAdapter extends BaseMultiItemRecyclerAdapter<String> {
    private boolean mEditMode;

    public LogAdapter(Context context, int baseLayoutResId) {
        super(context, baseLayoutResId);
    }

    @Override
    protected Class<? extends BaseViewHolder<String>> onBindViewTypeToViewHolder(int viewType) {
        return LogViewHolder.class;
    }

    public void toggleMode() {
        mEditMode = !mEditMode;
        notifyDataSetChanged();
    }

    private static class LogViewHolder extends BaseViewHolder<String> {
        private ItemActLogBinding mBinding;

        public LogViewHolder(View view) {
            super(view);
            mBinding = ItemActLogBinding.bind(view);
        }

        @Override
        public void onCreate(Context context, BaseMultiItemRecyclerAdapter<String> adapter) {
            super.onCreate(context, adapter);

            View.OnClickListener l = mAdapter.getOnClickListener();
            mBinding.tvTitle.setOnClickListener(l);
            mBinding.btnItemDelLog.setOnClickListener(l);

            View.OnLongClickListener ll = mAdapter.getOnItemLongClickListener();
            mBinding.tvTitle.setOnLongClickListener(ll);
        }

        @Override
        public void onBindData(int adapterPosition) {
            String data = getData(adapterPosition);
            if (data == null) {
                return;
            }
            LogAdapter adapter = (LogAdapter) mAdapter;

            mBinding.tvTitle.setTag(adapterPosition);
            mBinding.tvTitle.setText(data);

            if (adapter.mEditMode) {
                mBinding.btnItemDelLog.setTag(adapterPosition);
                mBinding.btnItemDelLog.setVisibility(View.VISIBLE);
            } else {
                mBinding.btnItemDelLog.setVisibility(View.GONE);
            }
        }
    }
}
