package com.naz.label.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.naz.label.R;

/**
 * 描述：
 * <p>
 * <p>
 * Create on 2022-04-27 by FengLing
 */
public class ConvenientSeekBar extends LinearLayout implements View.OnClickListener {

    private SeekBar mSb;
    private TextView mTvTips;
    private OnSeekBarChangeListener mOnSeekBarChangeListener;

    private int mMin;
    private boolean mShowBtn = true;
    private View mBtnAdd;
    private View mBtnReduction;

    public ConvenientSeekBar(Context context) {
        super(context);
        init(context, null, 0);
    }

    public ConvenientSeekBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0);
    }

    public ConvenientSeekBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr);
    }

    private void init(Context context, AttributeSet attrs, int defStyleAttr) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.ConvenientSeekBar, defStyleAttr, 0);
        int min = ta.getInt(R.styleable.ConvenientSeekBar_msb_min, 0);
        int max = ta.getInt(R.styleable.ConvenientSeekBar_msb_max, 100);

        int progress;
        if (isInEditMode()) {
            progress = ta.getInt(R.styleable.ConvenientSeekBar_msb_progress, 50);
        } else {
            progress = ta.getInt(R.styleable.ConvenientSeekBar_msb_progress, 0);
        }
        ta.recycle();
// ---------------------------------------------------------------------------------------------------------------------
        setOrientation(VERTICAL);
        inflate(context, R.layout.my_seekbar, this);

        mTvTips = findViewById(R.id.tvTips);
        mSb = findViewById(R.id.sb);

        if (mShowBtn) {
            View llBtn = findViewById(R.id.llBtn);
            llBtn.setVisibility(VISIBLE);

            mBtnAdd = findViewById(R.id.btnAdd);
            mBtnReduction = findViewById(R.id.btnReduction);

            mBtnAdd.setOnClickListener(this);
            mBtnReduction.setOnClickListener(this);
        }

        mSb.setId(getId());

        /*mSb.setMin()是区分API的，自己处理最小值*/
        mMin = min;
        setMax(max);
        setProgress(progress);

        String text = String.valueOf(getProgress());
        mTvTips.setText(text);

        mSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progress = getProgress();
                if (mOnSeekBarChangeListener != null) {
                    mOnSeekBarChangeListener.onProgressChanged(ConvenientSeekBar.this, progress, fromUser);
                }
                String text = String.valueOf(progress);
                mTvTips.setText(text);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (mOnSeekBarChangeListener != null) {
                    mOnSeekBarChangeListener.onStartTrackingTouch(ConvenientSeekBar.this);
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mOnSeekBarChangeListener != null) {
                    mOnSeekBarChangeListener.onStopTrackingTouch(ConvenientSeekBar.this);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnAdd) {
            int progress = mSb.getProgress();
            int max = mSb.getMax();

            if (progress < max) {
                ++progress;
                mSb.setProgress(progress);
            }
        } else if (id == R.id.btnReduction) {
            int progress = mSb.getProgress();

            if (progress > mMin) {
                --progress;
                mSb.setProgress(progress);
            }
        }

        if (mOnSeekBarChangeListener != null) {
            mOnSeekBarChangeListener.onStopTrackingTouch(this);
        }
    }

    public void setOnSeekBarChangeListener(ConvenientSeekBar.OnSeekBarChangeListener l) {
        this.mOnSeekBarChangeListener = l;
    }

    public void setProgress(int progress) {
        progress = progress - mMin;
        mSb.setProgress(progress);
    }

    public int getProgress() {
        int progress = mSb.getProgress();
        int v = progress + mMin;
        return v;
    }

    public void setMax(int max) {
        max = max - mMin;
        mSb.setMax(max);
    }

    public int getMax() {
        int max = mSb.getMax();
        int v = max + mMin;
        return v;
    }

    public int getSecondaryProgress() {
        return mSb.getSecondaryProgress();
    }

    public void setSecondaryProgress(int secondaryProgress) {
        mSb.setSecondaryProgress(secondaryProgress);
    }

    public void setMin(int min) {
        mMin = min;
    }

    public int getMin() {
        return mMin;
    }

    @Override
    protected void onDetachedFromWindow() {
        if (mBtnAdd != null) {
            mBtnAdd.setOnClickListener(null);
        }
        if (mBtnReduction != null) {
            mBtnReduction.setOnClickListener(null);
        }
        super.onDetachedFromWindow();
    }

    public interface OnSeekBarChangeListener {
        void onProgressChanged(ConvenientSeekBar seekBar, int progress, boolean fromUser);

        void onStartTrackingTouch(ConvenientSeekBar seekBar);

        void onStopTrackingTouch(ConvenientSeekBar seekBar);
    }
}