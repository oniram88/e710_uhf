package com.naz.label.fragments.home.access;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ListPopupWindow;

import androidx.constraintlayout.widget.ConstraintSet;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseFragment;
import com.naz.label.bean.OperationTagBean;
import com.naz.label.bean.type.Key;
import com.naz.label.databinding.FragmentAccessTagBinding;
import com.naz.label.fragments.home.inventory.InventoryTagFragment;
import com.naz.label.util.BeeperHelper;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.StringFormat;
import com.naz.label.util.ScreenUtils;
import com.naz.label.util.Utils;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.reader.Reader;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.Beeper;
import com.payne.reader.bean.config.LockMemBank;
import com.payne.reader.bean.config.LockType;
import com.payne.reader.bean.config.MemBank;
import com.payne.reader.bean.config.MemBankTm670;
import com.payne.reader.bean.config.ReadMode;
import com.payne.reader.bean.config.ResultCode;
import com.payne.reader.bean.config.Session;
import com.payne.reader.bean.config.Target;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.OperationTag;
import com.payne.reader.bean.receive.Version;
import com.payne.reader.bean.send.CustomSessionReadConfig;
import com.payne.reader.bean.send.KillConfig;
import com.payne.reader.bean.send.LockConfig;
import com.payne.reader.bean.send.MatchConfig;
import com.payne.reader.bean.send.ReadConfig;
import com.payne.reader.bean.send.WriteConfig;
import com.payne.reader.util.ArrayUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author naz
 * Date 2020/9/24
 */
public class AccessTagFragment extends BaseFragment<FragmentAccessTagBinding> {
    private static AccessTagFragment sFragment;

    private Reader mReader;
    private AccessTagAdapter mAdapter;
    private ArrayList<String> mSelectData;

    private volatile boolean mNeedAdd = true;
    private volatile int mTotalCount;

    private boolean mCircleRead;
    private String mLabelList;

    private ConcurrentHashMap<String, OperationTagBean> mMap = new ConcurrentHashMap<>(999);

    private Consumer<OperationTag> opTagConsumer = operationTag -> {
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(() -> {
            String key = operationTag.getStrEpc() + operationTag.getStrData();
            OperationTagBean tagBean = mMap.get(key);
            if (tagBean == null) {
                tagBean = new OperationTagBean(operationTag);
                mMap.put(key, tagBean);
                mAdapter.addData(0, tagBean);
                mSelectData.add(tagBean.getEpc());
                if (mNeedAdd) {
                    mTotalCount += operationTag.getTagCount();
                }
            } else {
                tagBean.setTagBean(operationTag);
                tagBean.addTimes();
                mAdapter.notifyDataSetChanged();
            }

            if (operationTag.isEndTag()) {
                mNeedAdd = true;
                String str;
                if (mCircleRead) {
                    str = mLabelList + " (" + mAdapter.getData().size() + ")";
                } else {
                    str = mLabelList + " (" + operationTag.getTagCount() + ")";
                }
                binding.tvLogTip.setText(str);

                if (BeeperHelper.getBeeperType() == Beeper.ONCE_END_BEEP) {
                    BeeperHelper.beep(BeeperHelper.SOUND_FILE_TYPE_NORMAL);
                }
                if (binding.btnReadTag.getText().equals(getString(R.string.stop))) {
                    realReadTags();
                }
            }
        });
    };
    private Consumer<Failure> failureConsumer = failure -> {
        byte cmd = failure.getCmd();
        byte errorCode = failure.getErrorCode();
        XLog.e("异常." + ResultCode.getNameForResultCode(errorCode));

        if (errorCode == ResultCode.REQUEST_TIMEOUT) {
            if (mAdapter.getData().size() != mTotalCount) {
                XLog.e("超时且缺数据");
//                    ReaderHelper.getReader().stopReadTag();/*异常.下一轮读取*/
                //return;
            }
            // return;/* 如果想看超时后的日志可以return掉，只跑盘存可以注释掉这个if */
        }
        if (binding.btnReadTag.getText().equals(getString(R.string.stop))) {
            realReadTags();
        }
    };

    public AccessTagFragment() {
        sFragment = this;
        mReader = ReaderHelper.getReader();
    }

    public static AccessTagFragment get() {
        return sFragment;
    }

    @Override
    protected FragmentAccessTagBinding getViewBinding() {
        return FragmentAccessTagBinding.inflate(getLayoutInflater());
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            if (binding.cbCustomRead.isChecked()) {
                binding.cbCustomRead.setChecked(false);
            }

            binding.spAccessArea.setSelectedIndex(0);
            binding.etStartAddress.setText("4");
            binding.etDataLength.setText("1");

            binding.btnReadTag.setTextColor(Color.BLUE);
        } else {
            binding.etStartAddress.setText("2");
            binding.etDataLength.setText("6");
            binding.btnReadTag.setTextColor(Color.DKGRAY);
        }
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        mSelectData = GlobalCfg.get().getNewEpcList();
        mLabelList = getResources().getString(R.string.label_list);

        Context context = getContext();
        int horizontalPadding = ScreenUtils.dp2px(context, 25);
        int verticalPadding = ScreenUtils.dp2px(context, 3);
        binding.spAccessArea.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spLockArea.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spLimitArea.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spReadSessionArea.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spReadTargetArea.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spReadModeArea.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        mAdapter = new AccessTagAdapter(new CopyOnWriteArrayList<>());
        LinearLayoutManager recyclerLayoutManager = new LinearLayoutManager(context);
        binding.recycler.setItemAnimator(null);
        binding.recycler.setLayoutManager(recyclerLayoutManager);
        binding.recycler.setAdapter(mAdapter);

        binding.cbLedMode.setOnCheckedChangeListener(this::onCheckedChanged);
        binding.ivArrow.setOnClickListener(v -> showListPopWindow());
        binding.btnRead.setOnClickListener(v -> read());
        binding.btnSelect.setOnClickListener(v -> select());
        binding.btnClear.setOnClickListener(v -> clearEpcMatch());
        binding.btnReadTag.setOnClickListener(v -> readTags());
        binding.btnWriteTag.setOnClickListener(v -> writeTags());
        binding.btnLockTag.setOnClickListener(v -> lockTag());
        binding.btnDestroyTag.setOnClickListener(v -> destroyTag());
        binding.ivListArrow.setOnClickListener(v -> showListLog());
        binding.cbCustomRead.setOnCheckedChangeListener(this::customReadChange);

        binding.spAccessArea.setSelectedIndex(1);
        binding.spWriteAccessArea.setSelectedIndex(1);

        binding.tvTopReadTag.setOnClickListener(this::show);
        binding.tvTopWriteTag.setOnClickListener(this::show);
        binding.tvTopLockTag.setOnClickListener(this::show);
        binding.tvTopDestroyTag.setOnClickListener(this::show);

        binding.llMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (binding.clAccessSet.isShown()) {
                    binding.ivMenu.setRotation(0);
                    binding.clAccessSet.setVisibility(View.GONE);
//                    binding.llTopNav.setVisibility(View.VISIBLE);
                } else {
                    binding.ivMenu.setRotation(180);
                    binding.clAccessSet.setVisibility(View.VISIBLE);
//                    binding.llTopNav.setVisibility(View.GONE);
                }
            }
        });

        binding.tvTopReadTag.setSelected(true);
        customReadChange(null, false);
    }

    private void show(View view) {
        binding.tvTopReadTag.setSelected(false);
        binding.tvTopWriteTag.setSelected(false);
        binding.tvTopLockTag.setSelected(false);
        binding.tvTopDestroyTag.setSelected(false);

        binding.clRead.setVisibility(View.GONE);
        binding.clWrite.setVisibility(View.GONE);
        binding.clLock.setVisibility(View.GONE);
        binding.clDestroy.setVisibility(View.GONE);
        switch (view.getId()) {
            case R.id.tvTopReadTag: {
                binding.tvTopReadTag.setSelected(true);
                binding.clRead.setVisibility(View.VISIBLE);
            }
            break;
            case R.id.tvTopWriteTag: {
                binding.tvTopWriteTag.setSelected(true);
                binding.clWrite.setVisibility(View.VISIBLE);
            }
            break;
            case R.id.tvTopLockTag: {
                binding.tvTopLockTag.setSelected(true);
                binding.clLock.setVisibility(View.VISIBLE);
            }
            break;
            case R.id.tvTopDestroyTag: {
                binding.tvTopDestroyTag.setSelected(true);
                binding.clDestroy.setVisibility(View.VISIBLE);
            }
            break;
        }
    }

    private void customReadChange(CompoundButton buttonView, boolean isCustomRead) {
        if (isCustomRead) {
            if (binding.cbLedMode.isChecked()) {
                binding.cbLedMode.setChecked(false);
            }
        }
        ConstraintSet set = new ConstraintSet();
        set.clone(binding.clRead);
        //普通读
        int showHide = isCustomRead ? View.GONE : View.VISIBLE;
        set.setVisibility(binding.tvAccessAreaTip.getId(), showHide);
        set.setVisibility(binding.spAccessArea.getId(), showHide);
        set.setVisibility(binding.tvStartAddressTip.getId(), showHide);
        set.setVisibility(binding.etStartAddress.getId(), showHide);
        set.setVisibility(binding.tvDataLengthTip.getId(), showHide);
        set.setVisibility(binding.etDataLength.getId(), showHide);
        //多区域读
        showHide = isCustomRead ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvReadSessionTip.getId(), showHide);
        set.setVisibility(binding.spReadSessionArea.getId(), showHide);
        set.setVisibility(binding.tvReadTargetTip.getId(), showHide);
        set.setVisibility(binding.spReadTargetArea.getId(), showHide);
        set.setVisibility(binding.tvReadModeTip.getId(), showHide);
        set.setVisibility(binding.spReadModeArea.getId(), showHide);
        set.setVisibility(binding.tvPwdStartAddressTip.getId(), showHide);
        set.setVisibility(binding.etPwdStartAddress.getId(), showHide);
        set.setVisibility(binding.tvPwdLengthTip.getId(), showHide);
        set.setVisibility(binding.etPwdLength.getId(), showHide);
        set.setVisibility(binding.tvTidStartAddressTip.getId(), showHide);
        set.setVisibility(binding.etTidStartAddress.getId(), showHide);
        set.setVisibility(binding.tvTidLengthTip.getId(), showHide);
        set.setVisibility(binding.etTidLength.getId(), showHide);
        set.setVisibility(binding.tvUserStartAddressTip.getId(), showHide);
        set.setVisibility(binding.etUserStartAddress.getId(), showHide);
        set.setVisibility(binding.tvUserLengthTip.getId(), showHide);
        set.setVisibility(binding.etUserLength.getId(), showHide);
        TransitionManager.beginDelayedTransition(binding.clRead);
        set.applyTo(binding.clRead);
    }

    private void showListLog() {
        ConstraintSet set = new ConstraintSet();
        set.clone(binding.clLog);
        if (binding.hsvList.getVisibility() == View.VISIBLE) {
            set.setRotation(binding.ivListArrow.getId(), 0);
            set.setVisibility(binding.hsvList.getId(), View.GONE);
        } else {
            set.setRotation(binding.ivListArrow.getId(), 180);
            set.setVisibility(binding.hsvList.getId(), View.VISIBLE);
        }
        TransitionManager.beginDelayedTransition(binding.clLog);
        set.applyTo(binding.clLog);
    }

    /**
     * 获取存取的数据
     *
     * @return List<OperationTagBean>
     */
    public List<OperationTagBean> getTags() {
        return mAdapter.getData();
    }

    private void read() {
        mReader.getEpcMatch(matchInfo -> {
                    updateEpc(matchInfo.getMatchEpcValue().replace(" ", ""));
                    showToast(getString(R.string.read_success));
                }, failure -> {
                    updateEpc("");
                    showToast(getString(R.string.no_actionable_label));
                }
        );
    }

    private void updateEpc(String maskValue) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> binding.etEpc.setText(maskValue));
        }
    }

    private void select() {
        String epc = binding.etEpc.getText().toString();
        String noSpacesEpc = epc.replace(" ", "");
        if (noSpacesEpc.isEmpty()) {
            showToast(getString(R.string.parameter_error));
        } else {
            MatchConfig config = new MatchConfig.Builder()
                    .setMaskValue(noSpacesEpc)
                    .build();
            mReader.setEpcMatch(config,
                    success -> showToast(getString(R.string.select_label_success)),
                    failure -> showToast(getString(R.string.select_label_error))
            );
        }
    }

    private void clearEpcMatch() {
        mReader.clearEpcMatch(success -> {
                    updateEpc("");
                    showToast(getString(R.string.clear_match_success));
                }, failure -> showToast(getString(R.string.clear_match_error))
        );
    }

    private void normalReadTags(String hexPasswords) {
        Version version = GlobalCfg.get().getVersion();
        if (version == null) {
            return;
        }
        int area = binding.spAccessArea.getSelectedIndex();

        byte memBank;
        if (version.getChipType() == Version.ChipType.TM670 && binding.cbGb.isChecked()) {/*国标*/
            memBank = MemBankTm670.valueOf((byte) area).getValue();
            if (area == 3) {
                memBank = (byte) (memBank + binding.spUserSubArea.getSelectedIndex());
            }
        } else {
            memBank = MemBank.valueOf((byte) area).getValue();
        }

        int startAddress = Utils.parseInt(binding.etStartAddress, -1);
        if (startAddress == -1) {
            return;
        }
        int readLen = Utils.parseInt_0_FF(binding.etDataLength, -1);
        if (readLen == -1) {
            return;
        }

        ReadConfig config = new ReadConfig.Builder()
                .setPasswords(hexPasswords)
                .setMemBankByte(memBank)
                .setWordStartAddress((byte) startAddress)
                .setWordLength((byte) readLen)
                .build();

        mReader.readTag(config, opTagConsumer, failureConsumer);
    }

    private void customReadTags(String hexPasswords) {
        int readSession = binding.spReadSessionArea.getSelectedIndex();
        Session session = Session.valueOf((byte) readSession);
        int readTarget = binding.spReadTargetArea.getSelectedIndex();
        Target target = Target.valueOf((byte) readTarget);
        int readModeIndex = binding.spReadModeArea.getSelectedIndex();
        ReadMode readMode;
        if (readModeIndex == 3) {
            readMode = ReadMode.MODE20;
        } else {
            readMode = ReadMode.valueOf((byte) readModeIndex);
        }
        //密码区
        int pwdStartAdd = Utils.parseInt(binding.etPwdStartAddress, -1);
        if (pwdStartAdd == -1) {
            return;
        }
        int pwdLen = Utils.parseInt_0_FF(binding.etPwdLength, -1);
        if (pwdLen == -1) {
            return;
        }
        //tid区
        int tidStartAdd = Utils.parseInt(binding.etTidStartAddress, -1);
        if (tidStartAdd == -1) {
            return;
        }
        int tidLen = Utils.parseInt_0_FF(binding.etTidLength, -1);
        if (tidLen == -1) {
            return;
        }
        //user区
        int userStartAdd = Utils.parseInt(binding.etUserStartAddress, -1);
        if (userStartAdd == -1) {
            return;
        }
        int userLen = Utils.parseInt_0_FF(binding.etUserLength, -1);
        if (userLen == -1) {
            return;
        }

        CustomSessionReadConfig config = new CustomSessionReadConfig.Builder()
                .setPasswords(hexPasswords)
                .setSession(session)
                .setTarget(target)
                .setReadMode(readMode)
                .setResStartAddress((byte) pwdStartAdd)
                .setResLength((byte) pwdLen)
                .setTidStartAddress((byte) tidStartAdd)
                .setTidLength((byte) tidLen)
                .setUserStartAddress((byte) userStartAdd)
                .setUserLength((byte) userLen)
                .build();

        mReader.readTag(config, opTagConsumer, failureConsumer);
    }

    private void readTags() {
        String readTag = getString(R.string.read_tag);
        if (binding.btnReadTag.getText().equals(readTag)) {
            binding.btnReadTag.setKeepScreenOn(true);
            mCircleRead = binding.cbCircleRead.isChecked();
            if (mCircleRead) {
                binding.btnReadTag.setText(getString(R.string.stop));
            }

            mAdapter.clear();
            mSelectData.clear();
            mMap.clear();

            realReadTags();
            return;
        }
        ReaderHelper.getReader().stopReadTag();
        binding.btnReadTag.setText(readTag);
        binding.btnReadTag.setKeepScreenOn(false);
    }

    private void realReadTags() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return;
        }
        if (binding.cbCustomRead.isChecked()) {
            customReadTags(hexPasswords);
        } else {
            normalReadTags(hexPasswords);
        }
    }

    private void writeTags() {
        int area = binding.spWriteAccessArea.getSelectedIndex();
        MemBank memBank = MemBank.valueOf((byte) area);
        int startAddress = Utils.parseInt(binding.etWriteStartAddress, -1);
        if (startAddress == -1) {
            return;
        }

        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return;
        }

        String strData = binding.etDataInput.getText().toString();
        if (strData.isEmpty() || strData.length() % 4 != 0) {
            showToast(getString(R.string.write_data_length_incorrect));
            return;
        }
        boolean blockWrite = binding.cbBlockWrite.isChecked();

        byte[] btData = ArrayUtils.hexStringToBytes(strData);
        byte readLen = (byte) ((btData.length >>> 1) + (btData.length & 0x01));

        String text = String.format("%02X", readLen);
        binding.etWriteDataLength.setText(text);

        boolean allowChange = Hawk.get(Key.CMD_CHANGE_EPC_LENGTH, false) && memBank == MemBank.EPC;
        if (allowChange) {
            startAddress = 1;
            int len;
            try {
                len = Integer.parseInt(text, 10);
            } catch (Exception e) {
                showToast(R.string.write_data_length_incorrect);
                return;
            }
            String pc = ArrayUtils.calcPC(len);

            btData = ArrayUtils.hexStringToBytes(pc + strData);
            readLen = (byte) ((btData.length >>> 1) + (btData.length & 0x01));
        }

        mAdapter.clear();

        WriteConfig config = new WriteConfig.Builder()
                .setPasswords(hexPasswords)
                .setMemBank(memBank)
                .setWordStartAddress((byte) startAddress)
                .setWordLength(readLen)
                .setWriteData(btData)
                .build();
        Consumer<OperationTag> consumer = operationTag -> {
            FragmentActivity activity = getActivity();
            if (activity == null) {
                return;
            }
            activity.runOnUiThread(() -> {
                OperationTagBean bean = new OperationTagBean(operationTag);
                mAdapter.addData(0, bean);
                if (allowChange) {
                    mSelectData.add(strData);
                }
                if (mAdapter.getData().size() == bean.getTagCount()) {
                    showToast(StringFormat.format(operationTag.getCmd(), ResultCode.SUCCESS));
                }//12345678900012345678900012345678 9000
            });
//            }
        };

        mReader.writeTag(config, blockWrite, consumer, failureConsumer);
    }

    private void lockTag() {
        int lockSelect = binding.spLockArea.getSelectedIndex();
        LockMemBank memBank = LockMemBank.valueOf((byte) (lockSelect + 1));
        int limitSelect = binding.spLimitArea.getSelectedIndex();
        LockType lockType = LockType.valueOf((byte) (limitSelect == 4 ? 6 : limitSelect));
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return;
        }
        mAdapter.clear();

        LockConfig config = new LockConfig.Builder()
                .setPasswords(hexPasswords)
                .setMemBank(memBank)
                .setLockType(lockType)
                .build();
        mReader.lockTag(config, operationTag -> {
            FragmentActivity activity = getActivity();
            if (activity == null) {
                return;
            }
            activity.runOnUiThread(() -> {
                OperationTagBean bean = new OperationTagBean(operationTag);
                mAdapter.addData(0, bean);
                if (mAdapter.getData().size() == bean.getTagCount()) {
                    showToast(StringFormat.format(operationTag.getCmd(), ResultCode.SUCCESS));
                }
            });
        }, failure -> showToast(StringFormat.format(failure.getCmd(), failure.getErrorCode())));
    }

    private void destroyTag() {
        String hexPasswords = binding.etDestroy.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return;
        }
        mAdapter.clear();

        KillConfig config = new KillConfig.Builder()
                .setPasswords(hexPasswords)
                .build();
        mReader.killTag(config, operationTag -> {
            FragmentActivity activity = getActivity();
            if (activity == null) {
                return;
            }
            activity.runOnUiThread(() -> {
                OperationTagBean bean = new OperationTagBean(operationTag);
                mAdapter.addData(0, bean);
                if (mAdapter.getData().size() == bean.getTagCount()) {
                    showToast(StringFormat.format(operationTag.getCmd(), ResultCode.SUCCESS));
                }
            });
        }, failure -> showToast(StringFormat.format(failure.getCmd(), failure.getErrorCode())));
    }

    private void showListPopWindow() {
        if (mSelectData == null || mSelectData.size() == 0) {
            mSelectData = GlobalCfg.get().getNewEpcList();
        }
        ObjectAnimator.ofFloat(binding.ivArrow, "rotation", 0, 180).setDuration(200).start();

        ListPopupWindow listPopupWindow = new ListPopupWindow(getContext());
        listPopupWindow.setAdapter(new ArrayAdapter<>(getContext(), R.layout.item_text, mSelectData));
        listPopupWindow.setAnchorView(binding.etEpc);
        listPopupWindow.setModal(true);
        listPopupWindow.setOnItemClickListener((adapterView, view, i, l) -> {
            listPopupWindow.dismiss();
            binding.etEpc.setText(mSelectData.get(i));
        });
        listPopupWindow.setOnDismissListener(() -> ObjectAnimator.ofFloat(binding.ivArrow, "rotation", 180, 0)
                .setDuration(200)
                .start());
        listPopupWindow.show();
    }

    public void refreshUI() {
        if (binding != null) {
            InventoryTagFragment fragment = InventoryTagFragment.get();
            if (fragment != null && fragment.mSelectedEPC != null) {
                binding.etEpc.setText(fragment.mSelectedEPC.split("\n")[0]);
                fragment.mSelectedEPC = null;
            }
        }
    }


    public void startStop(boolean isPress) {
        if (isPress) {
            binding.btnReadTag.performClick();
        }
    }

    @Override
    public void onDestroy() {
        mReader.stopReadTag();
        super.onDestroy();
    }
}
