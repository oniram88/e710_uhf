package com.naz.label.base;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

/**
 * Base fragment
 *
 * @author gpenghui
 * date 2018/8/23
 */

public abstract class BaseFragment<T extends ViewBinding> extends Fragment {
    protected T binding;
    private View mRoot;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = getViewBinding();
        mRoot = binding.getRoot();
        initView(mRoot, getLayoutInflater(), null);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return mRoot;
    }

    /**
     * @param msg 内容
     */
    protected void showToast(String msg) {
        Activity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * @param strResId 文字资源Id
     */
    protected void showToast(@StringRes int strResId) {
        Activity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> Toast.makeText(activity, getString(strResId), Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * 获取viewBinding
     *
     * @return T
     */
    protected abstract T getViewBinding();

    /**
     * 初始化View
     *
     * @param parent    view
     * @param inflater  inflater
     * @param container container
     */
    public abstract void initView(View parent, LayoutInflater inflater, ViewGroup container);
}
