//package com.naz.label.ui.home;
//
//import android.view.View;
//
//import androidx.annotation.NonNull;
//import androidx.navigation.NavController;
//import androidx.navigation.Navigator;
//import androidx.navigation.fragment.FragmentNavigator;
//import androidx.navigation.fragment.NavHostFragment;
//
//import com.naz.label.R;
//
///**
// * @author naz
// * Date 2021/1/28
// */
//public class CustomNavHostFragment extends NavHostFragment {
//
//    @NonNull
//    @Override
//    protected Navigator<? extends FragmentNavigator.Destination> createFragmentNavigator() {
//        return new CustomNavigator(requireContext(), getChildFragmentManager(), getContainerId());
//    }
//
//    private int getContainerId() {
//        int id = getId();
//        if (id != 0 && id != View.NO_ID) {
//            return id;
//        }
//        // Fallback to using our own ID if this Fragment wasn't added via
//        // add(containerViewId, Fragment)
//        return R.id.nav_host_fragment_container;
//    }
//}
