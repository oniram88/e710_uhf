package com.naz.label.fragments.set;

import android.graphics.Color;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.bean.SetPowerBean;
import com.naz.label.util.InputUtils;
import com.naz.label.widget.AfterTextWatcher;

import java.util.List;
import java.util.Locale;

/**
 * @author naz
 * Date 2020/4/3
 */
public class ReaderPowerAdapter extends BaseQuickAdapter<SetPowerBean, BaseViewHolder> {
    private int mEditPosition;

    public ReaderPowerAdapter(@Nullable List<SetPowerBean> data) {
        super(R.layout.item_power_set, data);
    }

    private final AfterTextWatcher mWatcher = new AfterTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            String str = s.toString();
            if (TextUtils.isEmpty(str)) {
                getData().get(mEditPosition).setPower(-1);
            } else {
                int value = Integer.parseInt(str);
                int maxV = GlobalCfg.get().getMaxOutPower();
                if (value > maxV) {
                    value = maxV;
                    s.replace(0, s.length(), "" + value);
                }
                List<SetPowerBean> list = getData();
                list.get(mEditPosition).setPower(value);
            }
        }
    };

    @Override
    protected void convert(BaseViewHolder helper, SetPowerBean item) {
        int ant = helper.getAdapterPosition() + 1;

        if (ant == 1 || ant == 9) {
            helper.setTextColor(R.id.tv_antenna, Color.BLUE);
        }
        String antStr = mContext.getString(R.string.antenna);
        String str = String.format(Locale.getDefault(), "%s%d(%s):", antStr, ant, "dBm");
        helper.setText(R.id.tv_antenna, Html.fromHtml(str));
        EditText etSetPower = helper.getView(R.id.et_set_power);
        int power = item.getPower();
        if (SetPowerBean.isValid(power)) {
            etSetPower.setText(String.valueOf(power));
        } else {
            etSetPower.setText("");
        }
        etSetPower.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                mEditPosition = helper.getAdapterPosition();
            }
        });
    }

    @Override
    public void onViewAttachedToWindow(BaseViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        EditText et = holder.getView(R.id.et_set_power);
        et.setHint("[0 - " + GlobalCfg.get().getMaxOutPower() + "]");
        et.addTextChangedListener(mWatcher);
        if (mEditPosition == holder.getAdapterPosition()) {
            et.requestFocus();
            et.setSelection(et.getText().length());
        }
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull BaseViewHolder holder) {
        super.onViewDetachedFromWindow(holder);
        EditText et = holder.getView(R.id.et_set_power);
        et.removeTextChangedListener(mWatcher);
        et.clearFocus();
        if (mEditPosition == holder.getAdapterPosition()) {
            InputUtils.hideInputMethod(mContext, et);
        }
    }
}