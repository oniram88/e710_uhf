package com.naz.label.acts;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.lib.download.DownloadHelper;
import com.lib.download.bean.DownloadFwFileInfo;
import com.lib.download.bean.DownloadVersionResult;
import com.lib.download.enu.DownloadChipType;
import com.lib.download.enu.DownloadFwType;
import com.lib.download.reader.DownLoadReader;
import com.lib.download.util.ArrayUtils;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.databinding.ActivityUpdateBinding;
import com.naz.label.util.ActivityLifecycleUtils;
import com.naz.label.util.PowerUtils;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.ToastUtils;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.connect.port.SerialPortHandle;
import com.payne.reader.Reader;
import com.payne.reader.util.ThreadPool;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.thl.filechooser.FileChooser;
import com.thl.filechooser.FileInfo;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class UpdateActivity extends BaseActivity<ActivityUpdateBinding> {
    private final String LAST_FIRMWARE_BIN_PATH = "lastFirmwareBinPath";
    private final String LAST_CHIP_BIN_PATH = "lastChipBinPath";

    private final int MSG_PROGRESS = 1;
    private final int MSG_REFRESH_UI = 2;
    private final int MSG_ADD_LOG = 3;

    private Disposable mDisposable;
    private Disposable mPerDisposable;

    private boolean mIsPrinter;

    private int mCurrentIndex;
    private DownloadFwFileInfo[] mFileArr = new DownloadFwFileInfo[2];
    private DownloadFwFileInfo mFwFile;
    private DownloadFwFileInfo mChipFile;

    private DownloadHelper mUpdateHelper;
    private ProgressDialog mProgressDialog;
    private LogAdapter mAdapter = new LogAdapter(this);

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case MSG_PROGRESS: {
                    int progress = msg.arg1;
                    if (progress == mProgressDialog.getMax()) {
                        binding.tvInfo.append("\n" + getString(R.string.update_success));
                        mProgressDialog.setProgress(0);
                        mProgressDialog.setMessage("Loading...");

                        mCurrentIndex++;/*更新完毕 索引增加*/
                        upgrade();/*更新完毕*/
                    } else if (progress > -1) {
                        mProgressDialog.setProgress(progress);
                    } else {
                        String str = (String) msg.obj;
                        mProgressDialog.setMessage("Loading..." + str);
                    }
                }
                break;
                case MSG_REFRESH_UI: {
                    binding.btnGet.setEnabled(true);
                    binding.btnGetRfid.setEnabled(true);
                    boolean enablePassthrough = mUpdateHelper.isEnablePassthrough();
                    if (enablePassthrough || !mIsPrinter) {
                        binding.btnGetChip.setEnabled(true);
                    } else {
                        binding.btnGetChip.setEnabled(false);
                    }
                    binding.cbEnablePT.setChecked(enablePassthrough);
                }
                break;
                case MSG_ADD_LOG: {
                    mAdapter.addData((String) msg.obj);
                }
                break;
            }
        }
    };
    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            boolean ignoreFileCrc = binding.cbIgnoreFileCrc.isChecked();
            boolean ignoreChipType = binding.cbIgnoreChipType.isChecked();
            boolean ignoreVersion = binding.cbIgnoreVersion.isChecked();

            mUpdateHelper.update(mFileArr[mCurrentIndex], ignoreFileCrc, ignoreChipType, ignoreVersion);
        }
    };
    private Disposable mParseDisposable;

    public static void start(Context context) {
        Intent starter = new Intent(context, UpdateActivity.class);
        context.startActivity(starter);
    }

    @Override
    protected ActivityUpdateBinding getViewBinding() {
        return ActivityUpdateBinding.inflate(getLayoutInflater());
    }

    private void initHelper() {
        DownLoadReader dr = DownLoadReader.getInstance();
        Reader reader = ReaderHelper.getReader();

        dr.bindConnectHandle(reader.getConnectHandle());
        reader.setRawRecvInterceptConsumer(dr);

        //<editor-fold desc="OnDownloadListener">
        DownloadHelper.OnDownloadListener listener = new DownloadHelper.OnDownloadListener() {
            @Override
            public void onMax(int max) {/*下载文件的大小*/
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isShowUpdate()) {
                            mProgressDialog.setMax(max);
                        } else {
                            showLoading(max);
                        }
                    }
                });
            }

            @Override
            public void onProgress(int progress, String str) {
                // XLog.i(progress + "/" + mProgressDialog.getMax());
                Message message = Message.obtain();
                message.what = MSG_PROGRESS;
                message.arg1 = progress;
                message.obj = str;
                mHandler.sendMessage(message);
            }

            @Override
            public void onError(String msg) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        binding.tvError.append("\n" + msg);
                        enableUI();
                    }
                });
            }
        };
        //</editor-fold>
        mUpdateHelper = new DownloadHelper(this, listener);

        mUpdateHelper.setSendRawDataListener(bytes -> { /*设置监听后，会影响速度*/
            String hexStr = "Send[" + bytes.length + "]" + (bytes.length < 128 ? ArrayUtils.bytesToHexString(bytes) : "");
            Message m = Message.obtain();
            m.what = MSG_ADD_LOG;
            m.obj = hexStr;
            mHandler.sendMessage(m);
        });
        mUpdateHelper.setReceiveRawDataListener(packet -> { /*设置监听后，会影响速度*/
            byte[] bytes = packet.getMsgBytes();
            String hexStr = "Recv[" + bytes.length + "]" + (bytes.length < 128 ? ArrayUtils.bytesToHexString(bytes) : "");
            Message m = Message.obtain();
            m.what = MSG_ADD_LOG;
            m.obj = hexStr;
            mHandler.sendMessage(m);
        });
        mUpdateHelper.setOnPassthroughStatusListener(enablePassthrough -> mHandler.sendEmptyMessage(MSG_REFRESH_UI));
    }

    @Override
    public void initView() {
        initHelper();

        mIsPrinter = getIntent().getBooleanExtra("isPrinter", false);
        if (mIsPrinter) {
            binding.cbEnablePT.setVisibility(View.VISIBLE);
            binding.tvTipInfo.setVisibility(View.GONE);
        } else {
            binding.cbEnablePT.setVisibility(View.GONE);
            binding.tvTipInfo.setVisibility(View.VISIBLE);
        }

        binding.getRoot().setKeepScreenOn(true);
        //<editor-fold desc="onCCL">
        CompoundButton.OnCheckedChangeListener onCCL = (buttonView, isChecked) -> {
            if (!buttonView.isPressed()) {
                return;
            }
            switch (buttonView.getId()) {
                case R.id.cbEnablePT: {
                    try {
                        mUpdateHelper.enablePassthrough();
                    } catch (Exception e) {
                        buttonView.setChecked(!isChecked);
                    }
                }
                break;
                case R.id.cbFirmware: {
                    if (isChecked) {
                        binding.etFirmware.setVisibility(View.VISIBLE);
                        binding.tvFileInfo1.setVisibility(View.VISIBLE);
                    } else {
                        binding.etFirmware.setVisibility(View.GONE);
                        binding.tvFileInfo1.setVisibility(View.GONE);
                    }
                }
                break;
                case R.id.cbChipFirmware: {
                    if (isChecked) {
                        binding.etChipFirmware.setVisibility(View.VISIBLE);
                        binding.tvFileInfo2.setVisibility(View.VISIBLE);
                    } else {
                        binding.etChipFirmware.setVisibility(View.GONE);
                        binding.tvFileInfo2.setVisibility(View.GONE);
                    }
                }
                break;
                case R.id.cbIgnoreVersion: {
                    binding.cbIgnoreChipType.setChecked(isChecked);
                }
                break;
            }
        };
        //</editor-fold>
        binding.cbEnablePT.setOnCheckedChangeListener(onCCL);
        binding.cbFirmware.setOnCheckedChangeListener(onCCL);
        binding.cbChipFirmware.setOnCheckedChangeListener(onCCL);
        binding.cbIgnoreVersion.setOnCheckedChangeListener(onCCL);
        //<editor-fold desc="onClick">
        View.OnClickListener l = v -> {
            if (v == binding.etFirmware || v == binding.etChipFirmware) {

                v.setEnabled(false);
                getStoragePermission((EditText) v);
            } else if (v == binding.tvTitle) {
                binding.dw.openDrawer(GravityCompat.START);
            } else if (v == binding.icMenu) {
                binding.dw.openDrawer(GravityCompat.END);
            } else if (v == binding.btnClear) {
                mAdapter.clear();
            } else if (v == binding.btnUpgrade) {

                binding.btnUpgrade.setEnabled(false);
                if (binding.cbFirmware.isChecked()) {
                    mFileArr[0] = mFwFile;
                } else {
                    mFileArr[0] = null;
                }
                if (binding.cbChipFirmware.isChecked()) {
                    mFileArr[1] = mChipFile;
                } else {
                    mFileArr[1] = null;
                }
                mCurrentIndex = 0;

                if (!DownLoadReader.getInstance().init()) {
                    binding.tvError.setText(getString(R.string.init_error));
                    return;
                }
                upgrade();/*首次开始*/
            } else if (v == binding.btnGet || v == binding.btnGetChip || v == binding.btnGetRfid) {
                binding.btnGet.setEnabled(false);
                binding.btnGetChip.setEnabled(false);
                binding.btnGetRfid.setEnabled(false);

                int id = v.getId();
                if (id == R.id.btnGet) {
                    binding.tvVersionInfo.setText("...");
                } else if (id == R.id.btnGetChip) {
                    binding.tvChipInfo.setText("...");
                } else if (id == R.id.btnGetRfid) {
                    binding.tvRfidInfo.setText("...");
                } else {
                    return;
                }
                mDisposable = Observable.<DownloadVersionResult>create(emitter -> {
                            DownloadFwFileInfo fileInfo = new DownloadFwFileInfo();

                            int vId = v.getId();
                            if (vId == R.id.btnGetRfid) {

                                if (mIsPrinter) {
                                    fileInfo.setFwType(DownloadFwType.FIRMWARE);
                                    fileInfo.setChipType(DownloadChipType.CHIP_PRINTER);
                                } else {
                                    fileInfo.setFwType(DownloadFwType.CHIP);
                                    fileInfo.setChipType(DownloadChipType.CHIP_R2000);
                                }
                                DownloadVersionResult version = mUpdateHelper.getRFIDVersion(fileInfo);
                                emitter.onNext(version);
                                return;
                            }

                            if (vId == R.id.btnGet) {
                                if (mIsPrinter) {
                                    fileInfo.setFwType(DownloadFwType.FIRMWARE);
                                    fileInfo.setChipType(DownloadChipType.CHIP_PRINTER);
                                } else {
                                    fileInfo.setFwType(DownloadFwType.FIRMWARE);
                                    fileInfo.setChipType(DownloadChipType.CHIP_R2000);
                                }
                            } else if (vId == R.id.btnGetChip) {
                                if (mIsPrinter) {
                                    fileInfo.setFwType(DownloadFwType.CHIP);
                                    fileInfo.setChipType(DownloadChipType.CHIP_PRINTER);
                                } else {
                                    fileInfo.setFwType(DownloadFwType.CHIP);
                                    fileInfo.setChipType(DownloadChipType.CHIP_R2000);
                                }
                            }
                            DownloadVersionResult version = mUpdateHelper.getVersion(fileInfo);
                            emitter.onNext(version);
                        })
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<DownloadVersionResult>() {
                            @Override
                            public void accept(DownloadVersionResult result) {
                                int vId = v.getId();
                                if (vId == R.id.btnGet) {
                                    binding.tvVersionInfo.setText(getString(R.string.info) + result);
                                } else if (vId == R.id.btnGetRfid) {
                                    binding.tvRfidInfo.setText(getString(R.string.rfid_info) + result);
                                } else if (vId == R.id.btnGetChip) {
                                    binding.tvChipInfo.setText(getString(R.string.chip_info) + result);
                                }
                                mHandler.sendEmptyMessage(MSG_REFRESH_UI);
                            }
                        });
            }
        };
        //</editor-fold>
        binding.tvTitle.setOnClickListener(l);
        binding.etFirmware.setOnClickListener(l);
        binding.etChipFirmware.setOnClickListener(l);
        binding.icMenu.setOnClickListener(l);
        binding.btnUpgrade.setOnClickListener(l);

        binding.btnGet.setOnClickListener(l);
        binding.btnGetChip.setOnClickListener(l);
        binding.btnGetRfid.setOnClickListener(l);
        binding.btnClear.setOnClickListener(l);

        binding.rvLog.setAdapter(mAdapter);


        String fileName = Hawk.get(LAST_FIRMWARE_BIN_PATH, "");
        binding.etFirmware.setText(fileName);
        parseFileData(fileName, binding.tvFileInfo1);/*sp0*/
        if (!binding.cbFirmware.isChecked()) {
            binding.tvFileInfo1.setVisibility(View.GONE);
        }
        fileName = Hawk.get(LAST_CHIP_BIN_PATH, "");
        binding.etChipFirmware.setText(fileName);
        parseFileData(fileName, binding.tvFileInfo2);/*sp1*/
        if (!binding.cbChipFirmware.isChecked()) {
            binding.tvFileInfo2.setVisibility(View.GONE);
        }
        mHandler.sendEmptyMessage(MSG_REFRESH_UI);
    }

    //<editor-fold desc="getPermission select parse">
    private void getStoragePermission(EditText et) {
        mPerDisposable = new RxPermissions(this)
                .requestEachCombined(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(permission -> {
                    if (permission.granted) {
                        selectFile(et);
                    } else if (permission.shouldShowRequestPermissionRationale) {
                        showToast(R.string.obtain_per_error);
                    } else {
                        new AlertDialog.Builder(this)
                                .setMessage(getString(R.string.need_sdcard_per))
                                .setNegativeButton(android.R.string.cancel, null)
                                .setPositiveButton(android.R.string.ok, (dialog, which) -> ActivityLifecycleUtils.startPermissionActivity(this))
                                .create()
                                .show();
                    }
                    et.setEnabled(true);
                });
    }

    private void selectFile(EditText et) {
        FileChooser fileChooser = new FileChooser(this, fileName -> {
            int id = et.getId();
            if (id == R.id.etFirmware) {
                parseFileData(fileName, binding.tvFileInfo1);
            } else {
                parseFileData(fileName, binding.tvFileInfo2);
            }
            et.setText(fileName);
        });
        fileChooser.setBackIconRes(R.drawable.ic_baseline_arrow_back_ios_24);
        fileChooser.setTitle(getString(R.string.select_file));
        fileChooser.setDoneText(getString(android.R.string.ok));
        fileChooser.setThemeColor(R.color.gray);
        fileChooser.setChooseType(FileInfo.FILE_TYPE_FILE);
        fileChooser.showFile(true);
        fileChooser.open();
    }

    private void parseFileData(String fileName, TextView v) {
        if (TextUtils.isEmpty(fileName)) {
            return;
        }
        mParseDisposable = Observable.<DownloadFwFileInfo>create(emitter -> {
                    DownloadFwFileInfo fwFileInfo = DownloadFwFileInfo.getFwFileInfo(fileName, v == binding.tvFileInfo2);

                    if (fwFileInfo == null) {
                        emitter.onNext(null);
                        return;
                    }
                    emitter.onNext(fwFileInfo);
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(dffi -> {
                    if (v == binding.tvFileInfo1) {
                        if (dffi == null || dffi.getChipType() == DownloadChipType.UNKNOWN) {
                            v.setText(getString(R.string.parse_file_error));
                            v.setTextColor(Color.RED);
                            mFwFile = null;
                            return;
                        }
                        v.setText(getString(R.string.file_info) + dffi);
                        v.setTextColor(Color.GRAY);
                        mFwFile = dffi;
                        Hawk.put(LAST_FIRMWARE_BIN_PATH, fileName);
                    } else if (v == binding.tvFileInfo2) {
                        if (dffi == null || dffi.getChipType() == DownloadChipType.UNKNOWN) {
                            v.setText(getString(R.string.parse_file_error));
                            v.setTextColor(Color.RED);
                            mChipFile = null;
                            return;
                        }
                        v.setText(getString(R.string.file_info) + dffi);
                        v.setTextColor(Color.GRAY);
                        mChipFile = dffi;
                        Hawk.put(LAST_CHIP_BIN_PATH, fileName);
                    }
                });
    }
    //</editor-fold>

    private void upgrade() {
        if (mCurrentIndex >= mFileArr.length) {
            XLog.i("All done...");
            enableUI();
            return;
        }
        XLog.i("[" + mCurrentIndex + "]->" + mFileArr[mCurrentIndex]);

        if (mFileArr[mCurrentIndex] == null) {
            mCurrentIndex++;/*无值 索引增加*/
            upgrade();/*递归检查*/
            return;
        }

        binding.tvInfo.setText(getString(R.string.start_update) + "\n" + mFileArr[mCurrentIndex]);
        binding.tvError.setText("");

        Reader reader = ReaderHelper.getReader();
        if (!reader.isConnected()) {
            binding.tvError.setText(getString(R.string.connect_error));
            return;
        }

        ThreadPool.get().execute(mRunnable);
    }

    private void enableUI() {
        hideUpdateLoading();
        binding.btnUpgrade.setEnabled(true);
    }

    private boolean isShowUpdate() {
        return mProgressDialog != null && mProgressDialog.isShowing();
    }

    private void showLoading(int max) {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setTitle(R.string.do_not_exit);
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setIcon(R.mipmap.ic_launcher);
            mProgressDialog.setCancelable(false);
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        }
        mProgressDialog.show();
        mProgressDialog.setMax(max);
        mProgressDialog.setProgress(0);
    }

    private void hideUpdateLoading() {
        if (mProgressDialog == null) {
            return;
        }
        mProgressDialog.dismiss();
    }


    long l;

    @Override
    public void onBackPressed() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mUpdateHelper.stopDownload();
            mProgressDialog.dismiss();
            return;
        }
        long ctm = System.currentTimeMillis();
        if (ctm - l < 2000) {
            super.onBackPressed();
            return;
        }
        l = ctm;
        ToastUtils.makeText(null, "快速双击退出", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (mDisposable != null) {
            mDisposable.dispose();
        }
        if (mPerDisposable != null) {
            mPerDisposable.dispose();
        }
        if (mParseDisposable != null) {
            mParseDisposable.dispose();
        }
        ReaderHelper.getReader().setRawRecvInterceptConsumer(null);
        super.onDestroy();
    }

    private static class LogAdapter extends RecyclerView.Adapter<LogAdapter.LogVH> {
        private final WeakReference<UpdateActivity> mWr;
        private List<String> mList = new ArrayList<>();

        public LogAdapter(UpdateActivity act) {
            mWr = new WeakReference<>(act);
        }

        @NonNull
        @Override
        public LogVH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            UpdateActivity act = mWr.get();
            if (act == null) {
                return null;
            }
            View v = act.getLayoutInflater().inflate(R.layout.item_log, viewGroup, false);
            return new LogVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull LogVH logVH, int i) {
            String str = mList.get(i);
            logVH.mTvLog.setText(str);
            if (str.startsWith("Send")) {
                logVH.mTvLog.setTextColor(Color.BLUE);
            } else {
                logVH.mTvLog.setTextColor(Color.GRAY);
            }
            logVH.mTvLog.setBackgroundColor(XLog.sContext.getResources().getColor(R.color.colorPrimary));
        }

        @Override
        public int getItemCount() {
            return mList.size();
        }

        public void addData(String str) {
            mList.add(str);
            notifyDataSetChanged();
        }

        public void clear() {
            mList.clear();
            notifyDataSetChanged();
        }

        private static class LogVH extends RecyclerView.ViewHolder {
            private final TextView mTvTime;
            private final TextView mTvLog;

            public LogVH(@NonNull View itemView) {
                super(itemView);
                mTvTime = itemView.findViewById(R.id.tv_time);
                mTvLog = itemView.findViewById(R.id.tv_data);
            }
        }
    }
}