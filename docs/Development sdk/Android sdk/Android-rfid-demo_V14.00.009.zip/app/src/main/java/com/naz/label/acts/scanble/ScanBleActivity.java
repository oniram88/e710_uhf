package com.naz.label.acts.scanble;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.OldBaseActivity;
import com.naz.label.bean.t30.BleDeviceBean;
import com.naz.label.bean.type.Key;
import com.naz.label.bean.type.LinkType;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.RxBleHelper;
import com.naz.label.acts.HomeActivity;
import com.naz.label.fragments.set.ble.ReaderBleFragment;
import com.naz.label.util.StartActivityUtils;
import com.naz.label.util.ToastUtils;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.reader.base.Consumer;
import com.polidea.rxandroidble2.RxBleConnection;
import com.polidea.rxandroidble2.RxBleDevice;
import com.polidea.rxandroidble2.exceptions.BleScanException;
import com.polidea.rxandroidble2.scan.ScanResult;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import io.reactivex.disposables.Disposable;

/**
 * @author naz
 */
public class ScanBleActivity extends OldBaseActivity {
    private final int REQUEST_ENABLE_BT = 11;
    private final int GPS_REQUEST_CODE = 5;

    private final int MSG_OPEN_MODULE = 0;

    @BindView(R.id.btnDisconnect)
    Button btnDisconnect;
    @BindView(R.id.btn_search)
    AppCompatButton btnSearch;
    @BindView(R.id.cbEnter)
    Button cbEnter;
    @BindView(R.id.rv_scan_results)
    RecyclerView rvResult;
    @BindView(R.id.flRoot)
    FrameLayout flRoot;

    private ReaderBleFragment mRbf;
    private ProgressDialog progressDialog;

    private BleAdapter mBleAdapter;
    private Disposable mDisposable;
    private RxPermissions mRxPermissions;

    private RxBleConnection.RxBleConnectionState mRxBleConnectionState;
    private BleConnectHandle mConnectHandle = new BleConnectHandle();

    private io.reactivex.functions.Consumer<? super Throwable> mThrowableConsumer = (io.reactivex.functions.Consumer<Throwable>) throwable -> {
        if (XLog.sShowLog) {
            progressDialog.dismiss();
            XLog.w("异常: " + throwable.getMessage());
            ToastUtils.makeText(null, R.string.serial_connect_failed, Toast.LENGTH_SHORT).show();
        }
    };
    BaseQuickAdapter.OnItemChildClickListener onItemChildClickListener = (adapter, view, position) -> {
        BleDeviceBean bleDeviceBean = mBleAdapter.getData().get(position);
        String address = bleDeviceBean.getAddress();
        if (RxBleHelper.getInstance().isConnected(address)) {
            XLog.i("已连接");
            openCloseModule();
            return;
        }
        setLoading(true);/*准备连接蓝牙*/
        RxBleHelper.getInstance().connect(address, this::connectState, this::connectSuccess, this::connectFail);
    };

    @Override
    public int getLayoutResId() {
        return R.layout.activity_scan_ble;
    }

    @Override
    public void initView() {
        this.setTitle(R.string.ble_connection);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        mRxPermissions = new RxPermissions(this);
        rvResult.setHasFixedSize(true);
        rvResult.setLayoutManager(new LinearLayoutManager(this));

        mBleAdapter = new BleAdapter(new ArrayList<>());
        mBleAdapter.setOnItemChildClickListener(onItemChildClickListener);
        rvResult.setAdapter(mBleAdapter);

        btnSearch.setOnLongClickListener(v -> {
            boolean isShow = cbEnter.getVisibility() == View.VISIBLE;
            if (isShow) {
                cbEnter.setVisibility(View.GONE);
            } else {
                cbEnter.setVisibility(View.VISIBLE);
            }
            return false;
        });
        cbEnter.setOnClickListener(v -> {
            if (mRxBleConnectionState != RxBleConnection.RxBleConnectionState.CONNECTED) {
                return;
            }
            openCloseModule();
        });
        ReaderHelper.getDefaultHelper().setInterfaceBoardSleep(new Consumer<Boolean>() {
            @Override
            public void accept(Boolean aBoolean) throws Exception {
                XLog.i("休眠了");
                setLoading(false);
            }
        });
//        btnDisconnect.setOnClickListener(v -> {
//
//        });
    }

    /**
     * 蓝牙连接状态监听
     *
     * @param rxBleConnectionState {@link RxBleConnection.RxBleConnectionState}
     */
    private void connectState(RxBleConnection.RxBleConnectionState rxBleConnectionState) {
        mRxBleConnectionState = rxBleConnectionState;
        if (mBleAdapter != null) {
            mBleAdapter.notifyDataSetChanged();
        }
        if (rxBleConnectionState == RxBleConnection.RxBleConnectionState.CONNECTING) {
            XLog.i("蓝牙连接中...");
        } else if (rxBleConnectionState == RxBleConnection.RxBleConnectionState.CONNECTED) {
            XLog.i("蓝牙连接成功");
        } else if (rxBleConnectionState == RxBleConnection.RxBleConnectionState.DISCONNECTING) {
            XLog.i("蓝牙断开中...");
        } else if (rxBleConnectionState == RxBleConnection.RxBleConnectionState.DISCONNECTED) {
            if (flRoot != null && flRoot.isShown()) {
                showToast(R.string.ble_disconnect);
                hideBleFragment();
            } else if (rvResult != null && rvResult.isShown()) {
                showToast(R.string.ble_disconnect);
            } else {
                startActivity(new Intent(this, DialogActivity.class));
            }
        }
    }

    /**
     * 连接蓝牙成功
     *
     * @param rxBleConnection {@link RxBleConnection}
     */
    private void connectSuccess(RxBleConnection rxBleConnection) {
        //连接蓝牙后需要在5秒钟内发送12345678，否则蓝牙会自动断连
        byte[] password = "12345678".getBytes();
        RxBleHelper.getInstance().write(rxBleConnection, password);

        mConnectHandle.setBleConnection(rxBleConnection, mThrowableConsumer);
        ReaderHelper.getReader().connect(mConnectHandle);

        if (cbEnter.isShown()) {
            setLoading(false);/*不用直接进入*/
            showToast(R.string.ble_connect_success);
            mBleAdapter.clear();
            showBleFragment();
        } else {
            SystemClock.sleep(500);
            openCloseModule();
        }
    }

    private void showBleFragment() {
        if (mRbf == null) {
            mRbf = new ReaderBleFragment();
        }
        flRoot.setVisibility(View.VISIBLE);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.flRoot, mRbf);
        ft.commitAllowingStateLoss();
    }

    private void hideBleFragment() {
        if (mRbf != null) {
            getSupportFragmentManager().beginTransaction().remove(mRbf).commitAllowingStateLoss();
        }
        flRoot.setVisibility(View.GONE);
    }

    /**
     * 连接蓝牙失败
     *
     * @param throwable {@link Throwable}
     */
    private void connectFail(Throwable throwable) {
        setLoading(false);/*连接蓝牙失败*/
        if (XLog.sShowLog) {
            String msg = throwable.getMessage();
            showToast(msg);
        }
    }

    public void openCloseModule() {
        XLog.i("准备打开模块");
        ScanBleActivity.this.setLoading(true, R.string.get_reader_firmware_version);/*准备打开模块*/
        ReaderHelper.getDefaultHelper().wakeupInterfaceBoard();
        byte moduleType = (byte) 0x01;/* 01 RFID      02 barcode */
        ReaderHelper.getDefaultHelper().openCloseModule(moduleType, true, true,
                successBean -> {
                    XLog.i("打开模块成功");
                    ScanBleActivity.this.setLoading(false);/*打开模块成功*/

                    GlobalCfg.get().setLinkType(LinkType.LINK_TYPE_BLUETOOTH);
                    Hawk.put(Key.KEY_LINK_TYPE, LinkType.LINK_TYPE_BLUETOOTH);
                    HomeActivity.start(this);
                }, errorBean -> {
                    XLog.w("打开模块失败");
                    ScanBleActivity.this.showToast(getString(R.string.open_module_error));
                    ScanBleActivity.this.setLoading(false);/*打开模块失败*/
                });
    }

    /**
     * 是否显示连接...
     *
     * @param show true or false
     */
    private void setLoading(boolean show) {
        setLoading(show, -1);
    }

    private void setLoading(boolean show, int strRes) {
        if ("main".equalsIgnoreCase(Thread.currentThread().getName())) {
            if (show) {
                if (progressDialog == null) {
                    progressDialog = new ProgressDialog(this);
                    progressDialog.setMessage(getString(R.string.connecting));
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setCanceledOnTouchOutside(false);
                }
                if (strRes == -1) {
                    progressDialog.setTitle(R.string.connect_ble);
                } else {
                    progressDialog.setTitle(strRes);
                }
                progressDialog.show();
            } else {
                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
            }
            return;
        }
        runOnUiThread(() -> setLoading(show, strRes));
    }

    @OnClick(R.id.btn_search)
    public void onViewClicked() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            showToast(R.string.no_bluetooth);
            return;
        }
        // 为了确保设备上蓝牙能使用, 如果当前蓝牙设备没启用,弹出对话框向用户要求授予权限来启用
        if (!bluetoothAdapter.isEnabled()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, REQUEST_ENABLE_BT);
        } else {
            getLocationPermission();
        }
    }

    /**
     * 获取位置权限
     */
    private void getLocationPermission() {
        mDisposable = mRxPermissions
                .requestEachCombined(Manifest.permission.ACCESS_FINE_LOCATION)
                .subscribe(permission -> {
                    if (permission.granted) {
                        startStopScan();
                    } else if (permission.shouldShowRequestPermissionRationale) {
                        showToast(R.string.get_location_permission_fail);
                    } else {
                        new AlertDialog.Builder(ScanBleActivity.this)
                                .setMessage(R.string.get_location_permission)
                                .setNegativeButton(R.string.cancel, null)
                                .setPositiveButton(R.string.to_open, (dialog, which) -> StartActivityUtils.startPermissionActivity(ScanBleActivity.this))
                                .create()
                                .show();
                    }
                });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        XLog.i("onActivityResult: requestCode:" + requestCode + ", resultCode:" + resultCode + ", data:" + (data == null ? "NULL" : data.toString()));
        if (requestCode == REQUEST_ENABLE_BT) {
            getLocationPermission();
        } else if (requestCode == GPS_REQUEST_CODE) {
            //检测GPS是否打开
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager != null && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                startStopScan(); //gps打开了
            } else {
                showToast(R.string.open_location);
            }
        }
    }

    /**
     * 开始或者停止扫描蓝牙设备
     */
    private void startStopScan() {
        RxBleHelper helper = RxBleHelper.getInstance();
        if (helper.isScanning()) {
            helper.stopScan();
        } else {
            mBleAdapter.getData().clear();
            mBleAdapter.notifyDataSetChanged();
            helper.startScan(this::scanSuccess, this::scanError, this::updateScanState);
        }
        updateScanState();
    }

    /**
     * 蓝牙扫描成功
     *
     * @param scanResult 扫描到的蓝牙设备
     */
    private void scanSuccess(ScanResult scanResult) {
        // 对蓝牙设备进行过滤等，并进行显示
        int rssi = scanResult.getRssi();
        RxBleDevice device = scanResult.getBleDevice();
        List<BleDeviceBean> list = mBleAdapter.getData();
        for (int i = 0; i < list.size(); i++) {
            BleDeviceBean item = list.get(i);
            if (item.getAddress().equals(device.getMacAddress())) {
                item.setSignal(rssi + 90);
                mBleAdapter.setData(i, item);
                //相同的只改变rssi值
                return;
            }
        }
        final BleDeviceBean bean = new BleDeviceBean(device.getName(), device.getMacAddress(), rssi + 90);
        mBleAdapter.addData(bean);
    }

    /**
     * 蓝牙扫描失败
     *
     * @param throwable 原因
     */
    private void scanError(Throwable throwable) {
        if (!(throwable instanceof BleScanException)) {
            return;
        }
        BleScanException exception = (BleScanException) throwable;
        String msg = RxBleHelper.getInstance().handleBleScanException(exception);
        if (exception.getReason() == BleScanException.LOCATION_SERVICES_DISABLED) {
            new AlertDialog.Builder(ScanBleActivity.this)
                    .setMessage(msg)
                    .setNegativeButton(R.string.cancel, null)
                    .setPositiveButton(R.string.to_open, (dialog, which) -> {
                        //跳转GPS设置界面
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivityForResult(intent, GPS_REQUEST_CODE);
                    })
                    .create()
                    .show();
        } else {
            showToast(msg);
        }
    }

    /**
     * 更新按钮状态
     */
    private void updateScanState() {
        btnSearch.setText(RxBleHelper.getInstance().isScanning() ? R.string.stop_scan : R.string.start_scan);
    }

    @Override
    public void onPause() {
        super.onPause();
        RxBleHelper.getInstance().stopScan();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (flRoot.isShown()) {
            return;
        }
        RxBleHelper.release();
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (mDisposable != null) {
            mDisposable.dispose();
        }
        mRbf = null;
        super.onDestroy();
    }
}
