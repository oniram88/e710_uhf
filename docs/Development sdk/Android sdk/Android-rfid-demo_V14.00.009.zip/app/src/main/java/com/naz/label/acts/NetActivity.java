package com.naz.label.acts;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.bean.type.Key;
import com.naz.label.bean.type.LinkType;
import com.naz.label.databinding.ActivityNetBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.XLog;
import com.orhanobut.hawk.Hawk;
import com.payne.connect.net.NetworkHandle;
import com.payne.reader.communication.ConnectHandle;
import com.payne.reader.util.ThreadPool;

public class NetActivity extends BaseActivity<ActivityNetBinding> {
    private final String mKeyIp = "key_ip";
    private String mIpStr;
    private String mPortStr;

    private volatile ConnectHandle mConnectHandle;

    private Runnable mRun = new Runnable() {
        @Override
        public void run() {
            if (mConnectHandle == null) {
                return;
            }
            boolean connectSuccess = ReaderHelper.getReader().connect(mConnectHandle);
            mH.sendEmptyMessage(connectSuccess ? 1 : 0);
        }
    };
    @SuppressLint("HandlerLeak")
    private Handler mH = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 0) {
                showToast(R.string.serial_connect_failed);
                binding.btnConnect.setEnabled(true);
                binding.pb.setVisibility(View.INVISIBLE);
                return;
            }
            Hawk.put(mKeyIp, mIpStr);

            GlobalCfg.get().setLinkType(LinkType.LINK_TYPE_NET);
            Hawk.put(Key.KEY_LINK_TYPE, LinkType.LINK_TYPE_NET);

            HomeActivity.start(NetActivity.this);
            finish();
        }
    };

    @Override
    protected ActivityNetBinding getViewBinding() {
        return ActivityNetBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView() {
        this.setTitle(R.string.net_connection);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        String ipStr = Hawk.get(mKeyIp, null);
        if (!TextUtils.isEmpty(ipStr)) {
            binding.etIP.setText(ipStr);
        }
        binding.btnConnect.setOnClickListener(this::onViewClicked);
    }


    public void onViewClicked(View v) {
        mIpStr = binding.etIP.getText().toString().trim();
        mPortStr = binding.etPort.getText().toString().trim();
        if (TextUtils.isEmpty(mIpStr)) {
            mIpStr = binding.etIP.getHint().toString();
        }
        if (TextUtils.isEmpty(mPortStr)) {
            mPortStr = binding.etPort.getHint().toString().trim();
        }

        if (!NetworkHandle.isValidIP(mIpStr)) {
            binding.etIP.setError("!");
            return;
        }
        binding.btnConnect.setEnabled(false);
        binding.pb.setVisibility(View.VISIBLE);

        XLog.i("To Connect->" + mIpStr + ":" + mPortStr);
        mConnectHandle = new NetworkHandle(mIpStr, Integer.parseInt(mPortStr));
        ThreadPool.get().execute(mRun);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (!binding.btnConnect.isEnabled()) {
            binding.btnConnect.setEnabled(true);
            binding.pb.setVisibility(View.INVISIBLE);
            if (mConnectHandle != null) {
                mConnectHandle.onDisconnect();
                mConnectHandle = null;
            }
            return;
        }
        super.onBackPressed();
    }
}