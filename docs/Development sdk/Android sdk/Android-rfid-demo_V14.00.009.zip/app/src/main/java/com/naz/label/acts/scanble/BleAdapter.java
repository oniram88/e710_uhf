package com.naz.label.acts.scanble;


import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.R;
import com.naz.label.bean.t30.BleDeviceBean;
import com.naz.label.util.RxBleHelper;

import java.util.List;

/**
 * @author gpenghui
 * date 2018/5/11
 */

public class BleAdapter extends BaseQuickAdapter<BleDeviceBean, BaseViewHolder> {
    public BleAdapter(@Nullable List<BleDeviceBean> data) {
        super(R.layout.item_bluetooth, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, BleDeviceBean item) {
        String name = item.getName();
        String address = item.getAddress();

        boolean connected = RxBleHelper.getInstance().isConnected(address);
        if (connected) {
            name += " (Connected)";
        }

        helper.setText(R.id.tv_name, name);
        helper.setText(R.id.tv_address, address);
        helper.setImageResource(R.id.iv_signal, getBleResId(item.getSignal()));

        helper.addOnClickListener(R.id.parent);
    }

    /**
     * 根据当前蓝牙信号的值获取要显示的图片
     *
     * @param signal 蓝牙信号
     * @return resId
     */
    private int getBleResId(int signal) {
        if (signal < 6) {
            return R.mipmap.search_ble_signal1_press;
        } else if (signal < 12) {
            return R.mipmap.search_ble_signal2_press;
        } else if (signal < 18) {
            return R.mipmap.search_ble_signal3_press;
        } else {
            return R.mipmap.search_ble_signal4_press;
        }
    }

    public void clear() {
        getData().clear();
        notifyDataSetChanged();
    }
}
