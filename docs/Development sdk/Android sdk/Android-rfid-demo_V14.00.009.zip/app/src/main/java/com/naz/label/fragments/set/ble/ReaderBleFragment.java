package com.naz.label.fragments.set.ble;

import android.app.Activity;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;

import com.naz.label.util.ClipboardUtils;
import com.naz.label.util.XLog;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.OldBaseFragment;
import com.naz.label.bean.t30.BleAddress;
import com.naz.label.bean.StatusBean;
import com.naz.label.util.ReaderHelper;
import com.naz.label.widget.AfterTextWatcher;
import com.naz.label.util.InputUtils;
import com.payne.reader.bean.receive.Version;
import com.suke.widget.SwitchButton;

import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author naz
 * Date 2020/4/8
 */
public class ReaderBleFragment extends OldBaseFragment {
    @BindView(R.id.tv_ble_version)
    TextView tvBleVersion;
    @BindView(R.id.tv_ble_mac)
    TextView tvBleMac;
    @BindView(R.id.et_ble_address)
    EditText etBleAddress;
    @BindView(R.id.btn_set_ble_address)
    Button btnSetBleAddress;
    @BindView(R.id.tv_module_voltage)
    TextView tvModuleVoltage;
    @BindView(R.id.tv_board_version)
    TextView tvBoardVersion;
    @BindView(R.id.tv_get_sn)
    TextView tvGetSn;
    @BindView(R.id.et_sn_psd)
    EditText etSnPsd;
    @BindView(R.id.et_sn_num)
    EditText etSnNum;
    @BindView(R.id.btn_set_sn)
    Button btnSetSn;
    @BindView(R.id.et_beeper_repeat)
    EditText etBeeperRepeat;
    @BindView(R.id.et_beeper_sounding_time)
    EditText etBeeperSoundingTime;
    @BindView(R.id.et_beeper_quiet_time)
    EditText etBeeperQuietTime;
    @BindView(R.id.btn_set_beeper)
    Button btnSetBeeper;
    @BindView(R.id.sb_uhf)
    SwitchButton sbUhf;
    @BindView(R.id.sb_barcode)
    SwitchButton sbBarcode;
    @BindView(R.id.tv_barcode)
    TextView tvBarcode;
    @BindView(R.id.sv_parent)
    ScrollView svParent;

    private StatusBean mStatusBean;
    private boolean mIsGetUhfStatus = true;
    private boolean mIsGetBarcodeStatus = true;

    @Override
    public int getLayoutResId() {
        return R.layout.fragment_reader_ble;
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        mStatusBean = new StatusBean();
        addBleNameTextChangedListener();
        addSnTextChangedListener();
        addBeeperTextChangedListener();
        //监听二维头扫描数据回调
        ReaderHelper.getDefaultHelper().setBarcodeResultCallback(barcodeData -> {
            FragmentActivity activity = getActivity();
            if (activity != null) {
                activity.runOnUiThread(() -> tvBarcode.setText(barcodeData.getBarcodeData()));
            }
        });
        tvBarcode.setOnClickListener(v -> {
            String str = tvBarcode.getText().toString();
            ClipboardUtils.copyText(v.getContext(), str);
            showToast("OK");
        });
        sbUhf.setOnCheckedChangeListener(this::openModule);
        sbBarcode.setOnCheckedChangeListener(this::openModule);
        //获取超高频模块状态（开启or关闭）
        ReaderHelper.getDefaultHelper().getModuleStatus((byte) 0x01, moduleStatus -> {
                    Activity activity = getActivity();
                    if (activity != null) {
                        activity.runOnUiThread(() -> sbUhf.setChecked(moduleStatus.isEnable()));
                    }
                },
                null);
        //延迟200毫秒获取二维头模块状态（开启or关闭）
        new Handler().postDelayed(() -> {
            ReaderHelper.getDefaultHelper().getModuleStatus((byte) 0x02, moduleStatus -> {
                        Activity activity = getActivity();
                        if (activity != null) {
                            activity.runOnUiThread(() -> sbBarcode.setChecked(moduleStatus.isEnable()));
                        }
                    },
                    null);
        }, 200);
    }

    /**
     * 开启或者关闭模块
     *
     * @param view      {@link SwitchButton}
     * @param isChecked 是否开启
     */
    private void openModule(SwitchButton view, boolean isChecked) {
        boolean isUhf = view.getId() == R.id.sb_uhf;
        int moduleType = isUhf ? 0x01 : 0x02;
        ReaderHelper.getDefaultHelper().openCloseModule((byte) moduleType, isChecked, true,
                success -> {
                    int res = isChecked ? R.string.open_module_success : R.string.close_module_success;
                    showOpenModuleToast(res);
                },
                failure -> {
                    int res = isChecked ? R.string.open_module_error : R.string.close_module_error;
                    boolean isShow = showOpenModuleToast(res);
                    if (isShow) {
                        changeSbStatus(isUhf);
                    }
                });
    }

    /**
     * 根据开或者关闭模块状态进行显示Toast
     *
     * @param res String资源文件
     * @return 是否显示
     */
    private boolean showOpenModuleToast(int res) {
        if (mIsGetUhfStatus) {
            mIsGetUhfStatus = false;
            return false;
        }
        if (mIsGetBarcodeStatus) {
            mIsGetBarcodeStatus = false;
            return false;
        }
        showToast(res);
        return true;
    }

    /**
     * 改变SwitchButton状态
     *
     * @param isUhf 是否是UHF模块
     */
    private void changeSbStatus(boolean isUhf) {
        Activity activity = getActivity();
        if (activity != null) {
            //操作失败，所以得把点击的按钮状态还原
            activity.runOnUiThread(() -> {
                if (isUhf) {
                    sbUhf.setChecked(!sbUhf.isChecked());
                } else {
                    sbBarcode.setChecked(!sbBarcode.isChecked());
                }
            });
        }
    }

    /**
     * 设置监听编辑框修改蓝牙名称的回调
     */
    private void addBleNameTextChangedListener() {
        etBleAddress.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString();
                boolean isEmpty = TextUtils.isEmpty(str);
                boolean btnEnable = !isEmpty;
                if (isEmpty) {
                    etBleAddress.setError(getString(R.string.prompt_empty_name));
                } else {
                    if (str.length() == 16) {
                        InputUtils.hideInputMethod(XLog.sContext, etBleAddress);
                    } else if (str.length() > 16) {
                        etBleAddress.setError(getString(R.string.incorrect_data_length));
                        btnEnable = false;
                    }
                }
                btnSetBleAddress.setEnabled(btnEnable);
            }
        });
    }

    /**
     * 设置监听编辑框修改SN的回调
     */
    private void addSnTextChangedListener() {
        etSnPsd.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString();
                boolean isEmpty = TextUtils.isEmpty(str);
                boolean ok = !isEmpty;
                if (isEmpty) {
                    etSnPsd.setError(getString(R.string.prompt_empty_password));
                } else {
                    if (str.length() == 16) {
                        InputUtils.hideInputMethod(XLog.sContext, etSnPsd);
                    } else if (str.length() > 16) {
                        etSnPsd.setError(getString(R.string.incorrect_data_length));
                        ok = false;
                    }
                }
                mStatusBean.setSnPasswordStatus(ok);
                btnSetSn.setEnabled(mStatusBean.getSnStatus());
            }
        });
        etSnNum.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString();
                boolean isEmpty = TextUtils.isEmpty(str);
                boolean ok = !isEmpty;
                if (isEmpty) {
                    etSnNum.setError(getString(R.string.prompt_empty_sn));
                } else {
                    if (str.length() == 16) {
                        InputUtils.hideInputMethod(XLog.sContext, etSnNum);
                    } else if (str.length() > 16) {
                        etSnNum.setError(getString(R.string.incorrect_data_length));
                        ok = false;
                    }
                }
                mStatusBean.setSnNumberStatus(ok);
                btnSetSn.setEnabled(mStatusBean.getSnStatus());
            }
        });
    }

    /**
     * 设置监听编辑框修改Beeper的回调
     */
    private void addBeeperTextChangedListener() {
        etBeeperRepeat.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString();
                boolean isEmpty = TextUtils.isEmpty(str);
                boolean ok = !isEmpty;
                if (!isEmpty) {
                    if (str.length() >= 3) {
                        InputUtils.hideInputMethod(XLog.sContext, etBeeperRepeat);
                    }
                    int value = Integer.parseInt(str);
                    if (value > 255 || value < 0) {
                        etBeeperRepeat.setError(getString(R.string.incorrect_value));
                        ok = false;
                    }
                }
                mStatusBean.setBeeperRepeatStatus(ok);
                btnSetBeeper.setEnabled(mStatusBean.getBeeperStatus());
            }
        });
        etBeeperSoundingTime.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString();
                boolean isEmpty = TextUtils.isEmpty(str);
                boolean ok = !isEmpty;
                if (!isEmpty) {
                    if (str.length() >= 3) {
                        InputUtils.hideInputMethod(XLog.sContext, etBeeperSoundingTime);
                    }
                    int value = Integer.parseInt(str);
                    if (value > 255 || value < 0) {
                        etBeeperSoundingTime.setError(getString(R.string.incorrect_value));
                        ok = false;
                    }
                }
                mStatusBean.setBeeperSoundingTimeStatus(ok);
                btnSetBeeper.setEnabled(mStatusBean.getBeeperStatus());
            }
        });
        etBeeperQuietTime.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString();
                boolean isEmpty = TextUtils.isEmpty(str);
                boolean ok = !isEmpty;
                if (!isEmpty) {
                    if (str.length() >= 3) {
                        InputUtils.hideInputMethod(XLog.sContext, etBeeperQuietTime);
                    }
                    int value = Integer.parseInt(str);
                    if (value > 255 || value < 0) {
                        etBeeperQuietTime.setError(getString(R.string.incorrect_value));
                        ok = false;
                    }
                }
                mStatusBean.setBeeperQuietTimeStatus(ok);
                btnSetBeeper.setEnabled(mStatusBean.getBeeperStatus());
            }
        });
    }

    @OnClick({R.id.btn_read_ble_version, R.id.btn_read_ble_mac, R.id.btn_set_ble_address,
            R.id.btn_get_module_voltage, R.id.btn_get_board_version, R.id.btn_get_sn,
            R.id.btn_set_sn, R.id.btn_set_beeper, R.id.btn_close_device})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_read_ble_version:
                ReaderHelper.getDefaultHelper().getBluetoothVersion(
                        this::setVersion,
                        failure -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_read_ble_mac:
                ReaderHelper.getDefaultHelper().getBluetoothMacAddress(
                        this::setMacAddress,
                        failure -> promptUi(getString(R.string.read_error))
                );
                break;
            case R.id.btn_set_ble_address:
                closeUhf();
                break;
            case R.id.btn_get_module_voltage:
                ReaderHelper.getDefaultHelper().getDevicePower(
                        devicePower -> {
                            String power = String.format(Locale.getDefault(), "%.2fv", devicePower.getDevicePower() / 1000f);
                            FragmentActivity activity = getActivity();
                            promptUi(getString(R.string.read_success));
                            if (activity != null) {
                                activity.runOnUiThread(() -> tvModuleVoltage.setText(power));
                            }
                        },
                        failure -> promptUi(getString(R.string.read_error))
                );
                break;
            case R.id.btn_get_board_version:
                ReaderHelper.getDefaultHelper().getInterfaceBoardVersionNumber(
                        version -> {
                            FragmentActivity activity = getActivity();
                            promptUi(getString(R.string.read_success));
                            if (activity != null) {
                                activity.runOnUiThread(() -> tvBoardVersion.setText(version.getVersion()));
                            }
                        },
                        failure -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_get_sn:
                ReaderHelper.getDefaultHelper().getInterfaceBoardSnNumber(snNumber -> {
                            FragmentActivity activity = getActivity();
                            promptUi(getString(R.string.read_success));
                            if (activity != null) {
                                activity.runOnUiThread(() -> tvGetSn.setText(snNumber.getInterfaceBoardSn()));
                            }
                        },
                        failure -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_set_sn:
                String password = etSnPsd.getText().toString().trim();
                String snNumber = etSnNum.getText().toString().trim();
                ReaderHelper.getDefaultHelper().setInterfaceBoardSnNumber(password, snNumber,
                        success -> promptUi(getString(R.string.set_success)),
                        failure -> promptUi(getString(R.string.set_error)));
                break;
            case R.id.btn_set_beeper:
                String strCycles = etBeeperRepeat.getText().toString().trim();
                String strRingingTime = etBeeperSoundingTime.getText().toString().trim();
                String strQuietTime = etBeeperQuietTime.getText().toString().trim();
                byte cycles = (byte) Integer.parseInt(strCycles);
                byte ringingTime = (byte) Integer.parseInt(strRingingTime);
                byte quietTime = (byte) Integer.parseInt(strQuietTime);
                ReaderHelper.getDefaultHelper().settingBuzzer(cycles, ringingTime, quietTime,
                        success -> promptUi(getString(R.string.set_success)),
                        failure -> promptUi(getString(R.string.set_error)));
                break;
            case R.id.btn_close_device:
                ReaderHelper.getDefaultHelper().shutdown();
                ToastUtils.makeText(svParent, R.string.shut_down_success, Toast.LENGTH_SHORT).show();
                break;
            default:
        }
    }

    private void closeUhf() {
        boolean uhfChecked = sbUhf.isChecked();
        if (uhfChecked) {
            ReaderHelper.getDefaultHelper().openCloseModule((byte) 0x01, false, true, success -> {
                        showOpenModuleToast(R.string.close_module_success);
                        setBleAddress();
                    },
                    failure -> {
                        boolean isShow = showOpenModuleToast(R.string.close_module_error);
                        if (isShow) {
                            changeSbStatus(uhfChecked);
                        }
                    });
        } else {
            setBleAddress();
        }
    }

    private void setBleAddress() {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> {
                String address = etBleAddress.getText().toString().trim();
                ReaderHelper.getDefaultHelper().setBluetoothBroadcastAddress(address);
                promptUi(getString(R.string.set_success));
            });
        }
    }

    /**
     * 更新设置mac地址
     *
     * @param bean {@link BleAddress}
     */
    private void setMacAddress(BleAddress bean) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(() -> tvBleMac.setText(bean.getMacAddress()));
    }

    /**
     * 更新设置蓝牙版本号
     *
     * @param bean {@link Version}
     */
    private void setVersion(Version bean) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(() -> tvBleVersion.setText(bean.getVersion()));
    }

    /**
     * 提示
     *
     * @param msg msg
     */
    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> ToastUtils.makeText(svParent, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
