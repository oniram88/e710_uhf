package com.naz.label.acts;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.FragmentActivity;

import com.naz.label.R;
import com.naz.label.acts.log.LogActivity;
import com.naz.label.acts.scanble.ScanBleActivity;
import com.naz.label.acts.printer.PrinterSerialActivity;
import com.naz.label.base.BaseDialogFragment;
import com.naz.label.databinding.ActivitySplashBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.StartActivityUtils;

public class SwitchConnectFragment extends BaseDialogFragment<ActivitySplashBinding> {
    @Override
    protected ActivitySplashBinding getViewBinding() {
        return ActivitySplashBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        View.OnClickListener l = this::onViewClicked;
        binding.btnSerialPort.setOnClickListener(l);
        binding.btnNet.setOnClickListener(l);
        binding.btnBle.setOnClickListener(l);
        binding.btnUsb.setOnClickListener(l);
        binding.btnPrinter.setOnClickListener(l);
        binding.btnLog.setOnClickListener(l);

        binding.btnSerialPort.setOnLongClickListener(v -> {
            binding.btnPrinter.setVisibility(View.VISIBLE);
            binding.btnLog.setVisibility(View.VISIBLE);
            return true;
        });
//        binding.btnLog.setOnLongClickListener(v -> {
//
//            return true;
//        });

    }

    public void onViewClicked(View view) {
        FragmentActivity activity = getActivity();
        switch (view.getId()) {
            case R.id.btn_serial_port:
                dismiss();
                StartActivityUtils.startActivity(activity, SerialPortActivity.class);
                break;
            case R.id.btnNet:
                dismiss();
                StartActivityUtils.startActivity(activity, NetActivity.class);
                break;
            case R.id.btn_ble:
                dismiss();
                StartActivityUtils.startActivity(activity, ScanBleActivity.class);
                break;
            case R.id.btn_usb:
                dismiss();
                StartActivityUtils.startActivity(activity, UsbActivity.class);
                break;
            case R.id.btn_printer:
                dismiss();
                StartActivityUtils.startActivity(activity, PrinterSerialActivity.class);
                break;
            case R.id.btnLog:
                LogActivity.start(activity);
                break;
        }
    }
}