package com.naz.label.acts.printer;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.bean.type.LinkType;
import com.naz.label.databinding.ActivityPrinterRfidConnectionBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.acts.HomeActivity;
import com.naz.label.util.PowerUtils;
import com.naz.label.util.XLog;
import com.payne.reader.Reader;
import com.payne.reader.bean.receive.Version;

/**
 * 本类用于连接打印机的RFID
 *
 * @author gpenghui
 */
public class PrinterSerialActivity extends BaseActivity<ActivityPrinterRfidConnectionBinding> {
    private PrinterConnectHandle mHandle;

    public static void start(FragmentActivity activity) {
        Intent intent = new Intent(activity, PrinterSerialActivity.class);
        activity.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        XLog.init(this, true, false);

        mHandle = new PrinterConnectHandle();

//        ReaderHelper.getReader().addOriginalDataReceivedCallback(consumer);
    }

    @Override
    protected ActivityPrinterRfidConnectionBinding getViewBinding() {
        return ActivityPrinterRfidConnectionBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView() {
        this.setTitle(R.string.printer_connection);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        binding.scUp.setOnClickListener(this::onClick);
        binding.scDown.setOnClickListener(this::onClick);
        binding.btnConnect.setOnClickListener(this::onViewClicked);
    }

    private void onClick(View cb) {
        int id = cb.getId();
        if (id == R.id.scUp) {
            boolean status = PowerUtils.powerOn();
            binding.tvShowResult.setText("powerUp = " + status);
        } else if (id == R.id.scDown) {
            boolean status = PowerUtils.powerOff();
            binding.tvShowResult.setText("powerDown = " + status);
        }
    }

    public void onViewClicked(View v) {
        Reader reader = ReaderHelper.getReader();
        boolean connectSuccess = reader.connect(mHandle);
        if (!connectSuccess) {
            showToast(R.string.serial_connect_failed);
            return;
        }
        boolean ok = true;
        if (binding.cbPassthrough.isChecked()) {
            ok = enablePassthrough();
        }
        if (ok && mHandle.isConnected()) {
            gotoHome();
        }
    }

    private boolean enablePassthrough() {
        byte[] b = new byte[]{(byte) 0xB0, 0x00, 0x06, (byte) 0xFF, 0x03, (byte) 0xF0, 0x02, 0x1E, (byte) 0x81};
        try {
            mHandle.onSend(b);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private void gotoHome() {
        Version version = new Version();
        version.setVersion("...");
        version.setChipType(Version.ChipType.E710);
        GlobalCfg.get().setVersion(version);
        GlobalCfg.get().setLinkType(LinkType.LINK_TYPE_SERIAL_PORT);

        Intent intent = new Intent(this, HomeActivity.class);
        intent.putExtra("timeout", 8000L);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}