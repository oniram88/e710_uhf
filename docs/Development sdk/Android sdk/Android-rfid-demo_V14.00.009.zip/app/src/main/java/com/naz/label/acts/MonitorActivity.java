package com.naz.label.acts;

import android.graphics.Color;
import android.text.Editable;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.OldBaseActivity;
import com.naz.label.bean.MonitorDataBean;
import com.naz.label.util.ReaderHelper;
import com.naz.label.widget.AfterTextWatcher;
import com.payne.reader.communication.DataPacket;
import com.payne.reader.util.ArrayUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author naz
 */
public class MonitorActivity extends OldBaseActivity {
    @BindView(R.id.cb_open)
    CheckBox cbOpen;
    @BindView(R.id.tv_fixed_data)
    TextView tvFixedData;
    @BindView(R.id.et_send_data)
    EditText etSendData;
    @BindView(R.id.tv_check)
    TextView tvCheck;
    @BindView(R.id.btn_send)
    Button btnSend;
    @BindView(R.id.rv_monitor)
    RecyclerView rvMonitor;

    private MonitorAdapter mAdapter;
    private DataPacket mPacket;

    @Override
    public int getLayoutResId() {
        return R.layout.activity_monitor;
    }

    @Override
    public void initView() {
        this.setTitle(R.string.data_monitor);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        initRecycler();
        addTextChanger();

        GlobalCfg cfg = GlobalCfg.get();
        cbOpen.setChecked(cfg.isEnableMonitor());
        cbOpen.setOnCheckedChangeListener((buttonView, isChecked) -> cfg.saveMonitorStatus(isChecked));
    }

    private void initRecycler() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rvMonitor.setLayoutManager(linearLayoutManager);

        mAdapter = new MonitorAdapter();
        mAdapter.getData().addAll(GlobalCfg.get().getMonitorData());
        rvMonitor.setAdapter(mAdapter);
        rvMonitor.setAnimation(null);
    }

    private void addTextChanger() {
        etSendData.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String str = s.toString().trim();
                boolean isEmpty = TextUtils.isEmpty(str);
                btnSend.setEnabled(!isEmpty);
                byte[] data = ArrayUtils.hexStringToBytes(str);
                if (data.length > 0) {
                    mPacket = new DataPacket(
                            ReaderHelper.getReader().getReaderAddress(),
                            data[0],
                            data,
                            1,
                            data.length);
                    tvFixedData.setText(String.format("%02x%02x%02x", mPacket.getHead(), mPacket.getLen(), mPacket.getAddress()));
                    tvCheck.setText(String.format("%s%02X", getString(R.string.check_digit), mPacket.getCheckSum()));
                } else {
                    tvFixedData.setText(R.string.normal_fixed_data);
                    tvCheck.setText("");
                    etSendData.setError(getString(R.string.incorrect_data_length));
                }
            }
        });
    }

    private Runnable runnable = () -> {
        List<MonitorDataBean> monitorData = GlobalCfg.get().getMonitorData();
        List<MonitorDataBean> data = mAdapter.getData();
        data.clear();
        data.addAll(monitorData);
        mAdapter.notifyDataSetChanged();
    };

    /**
     * 刷新数据
     */
    public void refreshData() {
        runOnUiThread(runnable);
    }

    @OnClick({R.id.btn_clear, R.id.btn_send})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_clear:
                GlobalCfg.get().clearMonitorData();
                mAdapter.clear();
                break;
            case R.id.btn_send:
                if (mPacket != null) {
                    ReaderHelper.getReader().sendCustomRequest(mPacket);
                }
                break;
            default:
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * @author gpenghui
     * date 2018/5/11
     */

    public static class MonitorAdapter extends BaseQuickAdapter<MonitorDataBean, BaseViewHolder> {
        private SimpleDateFormat mDateFormat;

        public MonitorAdapter() {
            super(R.layout.item_monitor);
            mDateFormat = new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());
        }

        @Override
        protected void convert(BaseViewHolder helper, MonitorDataBean item) {
            if (item == null) {
                return;
            }
            helper.setText(R.id.tv_time, mContext.getString(R.string.time) + mDateFormat.format(new Date(item.getCurrentTime())));
            helper.setTextColor(R.id.tv_data, item.isSend() ? Color.RED : Color.BLACK);
            helper.setText(R.id.tv_data, item.getData());
        }

        @Override
        public MonitorDataBean getItem(@IntRange(from = 0) int position) {
            try {
                return super.getItem(position);
            } catch (Exception e) {
                return null;
            }
        }

        public void clear() {
            getData().clear();
            notifyDataSetChanged();
        }
    }
}
