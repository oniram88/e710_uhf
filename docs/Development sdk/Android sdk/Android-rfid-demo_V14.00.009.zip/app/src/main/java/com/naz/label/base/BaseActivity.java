package com.naz.label.base;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewbinding.ViewBinding;

import com.naz.label.util.LanguageUtils;

/**
 * base activity
 *
 * @author naz
 * Date 2020/3/30
 */
public abstract class BaseActivity<T extends ViewBinding> extends AppCompatActivity {
    protected T binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        String language = LanguageUtils.getLanguage();
//        LanguageUtils.updateLanguage(this, language);
        binding = getViewBinding();
        if (binding != null) {
            setContentView(binding.getRoot());
        }
        initView();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        String language = LanguageUtils.getLanguage();
        Context context = LanguageUtils.updateLanguage(newBase, language);
        super.attachBaseContext(context);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    /**
     * @param msg 内容
     */
    protected void showToast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    /**
     * @param strResId 文字资源Id
     */
    protected void showToast(@StringRes int strResId) {
        runOnUiThread(() -> Toast.makeText(this, getString(strResId), Toast.LENGTH_SHORT).show());
    }

    /**
     * 获取viewBinding
     *
     * @return T
     */
    protected abstract T getViewBinding();

    /**
     * 初始化View
     */
    protected abstract void initView();
}
