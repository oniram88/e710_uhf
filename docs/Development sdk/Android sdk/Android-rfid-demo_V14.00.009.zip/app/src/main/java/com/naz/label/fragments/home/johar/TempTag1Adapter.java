package com.naz.label.fragments.home.johar;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.R;
import com.naz.label.bean.TemperatureBeanWrapper;

import java.util.List;

/**
 * @author naz
 * Date 2020/4/3
 */
public class TempTag1Adapter extends BaseQuickAdapter<TemperatureBeanWrapper, BaseViewHolder> {
    public TempTag1Adapter(@Nullable List<TemperatureBeanWrapper> data) {
        super(R.layout.item_temp_tag1, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, TemperatureBeanWrapper item) {
        int count = getData().size();
        helper.setText(R.id.tv_filter_id, String.valueOf(count - helper.getAdapterPosition()));
        helper.setText(R.id.tv_filter_length, item.getPc());
        helper.setText(R.id.tv_crc, item.getCrc());
        helper.setText(R.id.tv_filter_session, item.getEpc());
        helper.setText(R.id.tv_temperature, item.getTemperature());
        helper.setText(R.id.tv_ant_id, String.valueOf(item.getAntId() & 0xFF));
        helper.setText(R.id.tv_filter_action, item.getTimes());
        helper.addOnLongClickListener(R.id.cl_parent);
    }
}
