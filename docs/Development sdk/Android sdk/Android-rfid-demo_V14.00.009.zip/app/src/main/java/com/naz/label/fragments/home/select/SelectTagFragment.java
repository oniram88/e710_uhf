package com.naz.label.fragments.home.select;

import android.text.Editable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.BaseFragment;
import com.naz.label.databinding.FragmentSelectTagBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.widget.AfterTextWatcher;
import com.naz.label.util.ScreenUtils;
import com.payne.reader.bean.config.ClearMaskId;
import com.payne.reader.bean.config.MaskAction;
import com.payne.reader.bean.config.MaskId;
import com.payne.reader.bean.config.MaskTarget;
import com.payne.reader.bean.config.MemBank;
import com.payne.reader.bean.send.MaskConfig;

import java.util.ArrayList;

/**
 * @author naz
 */
public class SelectTagFragment extends BaseFragment<FragmentSelectTagBinding> {
    private static SelectTagFragment sFragment;
    private SelectTagAdapter mAdapter;

    public SelectTagFragment() {
        sFragment = this;
    }

    public static SelectTagFragment get() {
        return sFragment;
    }

    @Override
    protected FragmentSelectTagBinding getViewBinding() {
        return FragmentSelectTagBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        int horizontalPadding = ScreenUtils.dp2px(getContext(), 10);
        int verticalPadding = ScreenUtils.dp2px(getContext(), 5);
        binding.spMaskId.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spAction.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spClearMaskId.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spRegion.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spSession.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.etStartAddress.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                updateSetFilterBtn();
                if (TextUtils.isEmpty(s)) {
                    return;
                }
                int value = Integer.parseInt(s.toString());
                if (value > 255) {
                    s.delete(0, s.length());
                    s.append("255");
                }
            }
        });
        binding.etSelectLength.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                updateSetFilterBtn();
                if (TextUtils.isEmpty(s)) {
                    return;
                }
                int value = Integer.parseInt(s.toString());
                if (value > 255) {
                    s.delete(0, s.length());
                    s.append("255");
                }
            }
        });
        binding.etValue.addTextChangedListener(new AfterTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                updateSetFilterBtn();
            }
        });
        binding.btnSet.setOnClickListener(v -> setSelect());
        binding.btnClear.setOnClickListener(v -> clearSelect());
        binding.btnQuery.setOnClickListener(v -> querySelect());
        mAdapter = new SelectTagAdapter(getContext(), new ArrayList<>());
        binding.recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recycler.setAdapter(mAdapter);
    }

    private void updateSetFilterBtn() {
        if (TextUtils.isEmpty(binding.etStartAddress.getText()) ||
                TextUtils.isEmpty(binding.etSelectLength.getText()) ||
                TextUtils.isEmpty(binding.etValue.getText())) {
            if (binding.btnSet.isEnabled()) {
                binding.btnSet.setEnabled(false);
            }
        } else if (!TextUtils.isEmpty(binding.etStartAddress.getText()) &&
                !TextUtils.isEmpty(binding.etSelectLength.getText()) &&
                !TextUtils.isEmpty(binding.etValue.getText())) {
            if (!binding.btnSet.isEnabled()) {
                binding.btnSet.setEnabled(true);
            }
        }
    }

    /**
     * 设置过滤 ABCDEF1234567891FFFFFF1F00000000
     */
    private void setSelect() {
        int maskId = binding.spMaskId.getSelectedIndex() + 1;
        int session = binding.spSession.getSelectedIndex();
        int action = binding.spAction.getSelectedIndex();
        int region = binding.spRegion.getSelectedIndex();
        int startAddress = Integer.parseInt(binding.etStartAddress.getText().toString().trim());
        int selectLength = Integer.parseInt(binding.etSelectLength.getText().toString().trim());
        String hexValue = binding.etValue.getText().toString().trim();
        MaskConfig config = new MaskConfig.Builder()
                .setFunction(MaskId.valueOf((byte) maskId))
                .setTarget(MaskTarget.valueOf((byte) session))
                .setAction(MaskAction.valueOf((byte) action))
                .setMemBank(MemBank.valueOf((byte) region))
                .setMaskBitStartAddress((byte) startAddress)
                .setMaskBitLength((byte) selectLength)
                .setMaskValue(hexValue)
                .build();
        ReaderHelper.getReader().setTagMask(
                config,
                success -> promptUi(getString(R.string.filter_tag_success)),
                failure -> promptUi(getString(R.string.filter_tag_error))
        );
    }

    /**
     * 清除过滤
     */
    private void clearSelect() {
        int clearMaskId = binding.spClearMaskId.getSelectedIndex();
        ReaderHelper.getReader().clearTagMask(
                ClearMaskId.valueOf((byte) clearMaskId),
                success -> promptUi(getString(R.string.cancel_filter_tag_success)),
                failure -> promptUi(getString(R.string.cancel_filter_tag_error))
        );
    }

    /**
     * 查询过滤
     */
    private void querySelect() {
        mAdapter.clearData();
        ReaderHelper.getReader().getTagMask(
                maskInfo -> {
                    FragmentActivity activity = getActivity();
                    if (activity != null) {
                        activity.runOnUiThread(() -> mAdapter.addData(maskInfo));
                    }
                },
                failure -> promptUi(getString(R.string.no_filter_info))
        );
    }

    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(() -> ToastUtils.makeText(binding.llParent, msg, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}