package com.naz.label.acts;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.base.OldBaseActivity;
import com.naz.label.bean.type.LinkType;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.PowerUtils;
import com.naz.label.util.StartActivityUtils;
import com.naz.label.util.XLog;
import com.payne.connect.otg.UsbHandle;
import com.payne.reader.Reader;
import com.payne.reader.bean.config.Cmd;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import butterknife.OnClick;
import butterknife.OnLongClick;

/**
 * @author naz
 */
public class UsbActivity extends OldBaseActivity {
    private UsbHandle mUsbHandle;
    private int count;

    @Override
    public int getLayoutResId() {
        return R.layout.activity_usb;
    }

    @Override
    public void initView() {
        mUsbHandle = new UsbHandle(this);
    }

    private void manualCheck() {
        UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

        HashMap<String, UsbDevice> deviceList = usbManager.getDeviceList();
        Iterator<Map.Entry<String, UsbDevice>> it = deviceList.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, UsbDevice> entry = it.next();
            UsbDevice usbDevice = entry.getValue();
            if (it.hasNext()) {
                XLog.i("--ignore: " + entry.getKey() + "-->" + usbDevice);
                continue;
            }
            XLog.i(entry.getKey() + "-->" + usbDevice);

            PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent("com.payne.connect.USB_PERMISSION"), 0);
            usbManager.requestPermission(usbDevice, permissionIntent);
        }
    }

    @OnLongClick(R.id.btn_usb)
    public boolean onViewLongClicked() {
        manualCheck();
        return true;
    }

    @OnClick(R.id.btn_usb)
    public void onViewClicked() {
        if (!PowerUtils.powerOn()) {
            Toast.makeText(this, R.string.power_on_failed, Toast.LENGTH_SHORT).show();
            // binding.btnConnect.setEnabled(true);
            return;
        }
        boolean connectSuccess = ReaderHelper.getReader().connect(mUsbHandle);
        if (!connectSuccess) {
            Toast.makeText(this, R.string.otg_connection_failed, Toast.LENGTH_SHORT).show();
            return;
        }

        getFirmwareVersion();
    }

    private void getFirmwareVersion() {
        Reader reader = ReaderHelper.getReader();
        reader.getFirmwareVersion(version -> {
            runOnUiThread(() -> {
                ReaderHelper.getReader().removeCallback(Cmd.GET_FIRMWARE_VERSION);

                GlobalCfg.get().setLinkType(LinkType.LINK_TYPE_SERIAL_PORT);
                GlobalCfg.get().setVersion(version);

                HomeActivity.start(this);
                finish();
            });
        }, failure -> {
            if (count++ < 3) {
                getFirmwareVersion();
            } else {
                showToast("getFirmwareVersion Error!");
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (mUsbHandle != null) {
            mUsbHandle.onDisconnect();
            mUsbHandle = null;
        }
        super.onBackPressed();
    }
}