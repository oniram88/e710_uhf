package com.naz.label;

import android.app.Application;

import com.naz.label.util.BeeperHelper;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.RxBleHelper;
import com.naz.label.util.ActivityLifecycleUtils;
import com.naz.label.util.PowerUtils;
import com.naz.label.util.XLog;
import com.naz.serial.port.ModuleManager;
import com.orhanobut.hawk.Hawk;

/**
 * @author naz
 * Date 2019/11/20
 */
public class App extends Application {

    @Override
    public void onCreate() {
        long l = System.currentTimeMillis();
        super.onCreate();
        Hawk.init(this).build();
        XLog.init(this, BuildConfig.DEBUG, false);
        ErrorReport.init();
        ActivityLifecycleUtils.init(this);
        GlobalCfg.get().init();
        BeeperHelper.init(this);

        XLog.i("hs." + (System.currentTimeMillis() - l));
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        PowerUtils.powerOff();
        ReaderHelper.getReader().disconnect();
        RxBleHelper.release();
        BeeperHelper.release();
        ModuleManager.newInstance().release();

        ActivityLifecycleUtils.finishAll();
        System.exit(0);
//        android.os.Process.killProcess(android.os.Process.myPid());
    }
}