package com.naz.label.fragments.home.temp;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListPopupWindow;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.acts.ShowTempResultChartActivity;
import com.naz.label.base.BaseDialogFragment;
import com.naz.label.databinding.FragmentTempTag2Binding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.StringFormat;
import com.naz.label.util.ScreenUtils;
import com.naz.label.util.Utils;
import com.naz.label.util.XLog;
import com.payne.reader.base.Consumer;
import com.payne.reader.base.TempLabel2Info;
import com.payne.reader.bean.config.TagMeasOpt;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.TempLabel2;
import com.payne.reader.bean.send.MatchConfig;
import com.payne.reader.bean.send.MtAuth;
import com.payne.reader.bean.send.MtDisableRtcMeasTemp;
import com.payne.reader.bean.send.MtEnableRtcMeasTemp;
import com.payne.reader.bean.send.MtLedControl;
import com.payne.reader.bean.send.MtLoadConfig;
import com.payne.reader.bean.send.MtReadMemory;
import com.payne.reader.bean.send.MtReadRegister;
import com.payne.reader.bean.send.MtSingleMeasTemp;
import com.payne.reader.bean.send.MtStateCheck;
import com.payne.reader.bean.send.MtWriteMemory;
import com.payne.reader.bean.send.TempLabel2Config;
import com.payne.reader.util.ArrayUtils;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author naz
 * Date 2020/7/9
 */
public class TempTag2Fragment extends BaseDialogFragment<FragmentTempTag2Binding> {
    public static ArrayList<Float> mList = new ArrayList<>();
    public static int delayTime;
    public static int measInterval;
    public static int tempUpperLimit;
    public static int tempLowerLimit;
    public static int measCount;
    public static long timeStamp;
    private boolean mShow;

    private String mHexPasswords;
    private String mAuthPwd;

    private String[] mOptTypes;
    private TempTag2Adapter mAdapter;

    private int mRecvCount;

    private ArrayList<String> mSelectData;

    private ListPopupWindow mPopupWindow;
    private ArrayAdapter<String> mArrayAdapter;

    @SuppressLint("HandlerLeak")
    private Handler mH = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            TempLabel2Info info = new MtReadRegister.Builder()
                    .setPasswords(mHexPasswords)
                    .setPtr("0000C091")
                    .build();
            TempLabel2Config config = new TempLabel2Config(info);

            Consumer<TempLabel2> consumer = new Consumer<TempLabel2>() {
                @Override
                public void accept(TempLabel2 tempLabel2) throws Exception {
                    mShow = true;
                    MtReadMemory info = new MtReadMemory.Builder()
                            .setPasswords(mHexPasswords)
                            .setAuthPwd(mAuthPwd)
                            .setStartAddress(4096)
                            .setLength(measCount * 4)
                            .build();
                    toMeasureTempLabel(info);
                }
            };
            ReaderHelper.getReader().measTempLabel2(config, consumer, TempTag2Fragment.this::measFailure);
        }
    };

    @Override
    protected FragmentTempTag2Binding getViewBinding() {
        return FragmentTempTag2Binding.inflate(getLayoutInflater());
    }

    public void startStop(boolean startRead) {
        if (startRead) {
            startMeasure();
        }
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        Context context = getContext();
        int horizontalPadding = ScreenUtils.dp2px(context, 30);
        int verticalPadding = ScreenUtils.dp2px(context, 0);
        binding.spOptType.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spMeasType.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        binding.spLedControl.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);

        mOptTypes = context.getResources().getStringArray(R.array.temp_tag2_opt_type);

        mSelectData = GlobalCfg.get().getNewEpcList();
        if (mSelectData.size() <= 0) {
            binding.ivArrow.setVisibility(View.GONE);
        }
        mArrayAdapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, mSelectData);

        mAdapter = new TempTag2Adapter(new CopyOnWriteArrayList<>());
        binding.recycler.setAdapter(mAdapter);

        binding.ivArrow.setOnClickListener(v -> showListPopWindow());
        binding.btnRead.setOnClickListener(v -> read());
        binding.btnSelect.setOnClickListener(v -> select());
        binding.btnClear.setOnClickListener(v -> clear());
        binding.ivListArrow.setOnClickListener(v -> showListLog());
        binding.spOptType.setOnSpinnerItemSelectedListener((parent1, view, position, id) -> optTypeChange(position));
        binding.btnMeasTag.setOnClickListener(v -> startMeasure());
    }

    private void optTypeChange(int position) {
        ConstraintSet set = new ConstraintSet();
        set.clone(binding.clScrollParent);
        int showHide = position == 0 ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvMeasTypeTip.getId(), showHide);
        set.setVisibility(binding.spMeasType.getId(), showHide);

        showHide = position == 1 ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvDelayMeasTip.getId(), showHide);
        set.setVisibility(binding.etDelayMeas.getId(), showHide);
        set.setVisibility(binding.tvMeasIntervalTip.getId(), showHide);
        set.setVisibility(binding.etMeasInterval.getId(), showHide);
        set.setVisibility(binding.tvTempUpperLimitTip.getId(), showHide);
        set.setVisibility(binding.etTempUpperLimit.getId(), showHide);
        set.setVisibility(binding.tvTempLowerLimitTip.getId(), showHide);
        set.setVisibility(binding.etTempLowerLimit.getId(), showHide);
        set.setVisibility(binding.tvMeasTimesTip.getId(), showHide);
        set.setVisibility(binding.etMeasTimes.getId(), showHide);
        set.setVisibility(binding.cbRtc.getId(), showHide);

        showHide = position == 7 || position == 8 ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvDataStartAddTip.getId(), showHide);
        set.setVisibility(binding.etDataStartAdd.getId(), showHide);
        set.setVisibility(binding.tvDataLenTip.getId(), showHide);
        set.setVisibility(binding.etDataLen.getId(), showHide);

        showHide = position == 1 || position == 2 || position == 6 || position == 7 || position == 8 ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvAuthPasswordTip.getId(), showHide);
        set.setVisibility(binding.etAuthPassword.getId(), showHide);

        showHide = position == 4 || position == 8 ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvDataTip.getId(), showHide);
        set.setVisibility(binding.etData.getId(), showHide);

        showHide = position == 9 ? View.VISIBLE : View.GONE;
        set.setVisibility(binding.tvLedControlTip.getId(), showHide);
        set.setVisibility(binding.spLedControl.getId(), showHide);
        binding.btnMeasTag.setText(mOptTypes[position]);
        binding.tvDataTip.setText(position == 4 ? R.string.register_address : R.string.data_input);
        TransitionManager.beginDelayedTransition(binding.clScrollParent);
        set.applyTo(binding.clScrollParent);
    }

    private void showListLog() {
        ConstraintSet set = new ConstraintSet();
        set.clone(binding.clLog);
        if (binding.hsvList.getVisibility() == View.VISIBLE) {
            set.setRotation(binding.ivListArrow.getId(), 0);
            set.setVisibility(binding.hsvList.getId(), View.GONE);
        } else {
            set.setRotation(binding.ivListArrow.getId(), 180);
            set.setVisibility(binding.hsvList.getId(), View.VISIBLE);
        }
        TransitionManager.beginDelayedTransition(binding.clLog);
        set.applyTo(binding.clLog);
    }

    private void read() {
        ReaderHelper.getReader().getEpcMatch(matchInfo -> {
                    updateEpc(matchInfo.getMatchEpcValue().replace(" ", ""));
                    showToast(getString(R.string.read_success));
                }, failure -> {
                    updateEpc("");
                    showToast(getString(R.string.no_actionable_label));
                }
        );
    }

    private void select() {
        String epc = binding.etEpc.getText().toString();
        String noSpacesEpc = epc.replace(" ", "");
        if (noSpacesEpc.isEmpty()) {
            showToast(getString(R.string.parameter_error));
        } else {
            MatchConfig config = new MatchConfig.Builder()
                    .setMaskValue(noSpacesEpc)
                    .build();
            ReaderHelper.getReader().setEpcMatch(config,
                    success -> showToast(getString(R.string.select_label_success)),
                    failure -> showToast(getString(R.string.select_label_error))
            );
        }
    }

    private void clear() {
        ReaderHelper.getReader().clearEpcMatch(success -> {
                    updateEpc("");
                    showToast(getString(R.string.clear_match_success));
                },
                failure -> showToast(getString(R.string.clear_match_error))
        );
    }

    private void startMeasure() {
        mRecvCount = 0;
        mSelectData.clear();
        mAdapter.getData().clear();
        mAdapter.notifyDataSetChanged();

        int index = binding.spOptType.getSelectedIndex();
        if (index == 1 && binding.cbRtc.isChecked()) {
            if (binding.btnMeasTag.getText().equals(mOptTypes[2])) {
                binding.btnMeasTag.setText(mOptTypes[1]);
                mH.removeCallbacksAndMessages(null);
            } else {
                toRTCMeasureAndShowResult();
            }
            return;
        } else if (index == 2) {
            mH.removeCallbacksAndMessages(null);
        }
        TempLabel2Info info = getInfo(index);
        boolean ret = toMeasureTempLabel(info);
    }

    private TempLabel2Info getInfo(int index) {
        TempLabel2Info info;
        switch (index) {
            case 0:
                info = getSingleMeas();
                break;
            case 1:
                info = getEnableRtc();
                break;
            case 2:
                info = getDisableRtc();
                break;
            case 3:
                info = getLoadConfig();
                break;
            case 4:
                info = getReadRegister();
                break;
            case 5:
                info = getStateCheck();
                break;
            case 6:
                info = getAuth();
                break;
            case 7:
                info = getReadMemory();
                break;
            case 8:
                info = getWriteMemory();
                break;
            case 9:
                info = getLedControl();
                break;
            default:
                XLog.w("Not Impl...");
                return null;
        }

        return info;
    }

    private void toRTCMeasureAndShowResult() {
        mHexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (mHexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return;
        }
        mAuthPwd = binding.etAuthPassword.getText().toString().toUpperCase();
        if (mAuthPwd.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return;
        }
        binding.btnMeasTag.setText(mOptTypes[2]);
        timeStamp = System.currentTimeMillis();
        int time = (int) (timeStamp / 1000);
        byte[] bytes = ArrayUtils.intToByteArray(time);
        TempLabel2Info wm = new MtWriteMemory.Builder()
                .setPasswords(mHexPasswords)
                .setAuthPwd(mAuthPwd)
                .setStartAddress(32)
                .setCount(4)
                .setData(bytes)
                .build();
        TempLabel2Config config = new TempLabel2Config(wm);
        ReaderHelper.getReader().measTempLabel2(config, new Consumer<TempLabel2>() {
            @Override
            public void accept(TempLabel2 tempLabel2) throws Exception {
                TempLabel2Info info = getInfo(1);
                boolean ret = toMeasureTempLabel(info);
                if (ret) {
                    int delay = measCount * (delayTime * 60 + measInterval) + 2;
                    mH.sendEmptyMessageDelayed(0, delay * 1000);
                }
            }
        }, this::measFailure);
    }

    private boolean toMeasureTempLabel(TempLabel2Info info) {
        if (info == null) {
            return false;
        }
        TempLabel2Config config = new TempLabel2Config(info);
        ReaderHelper.getReader().measTempLabel2(config, this::measSuccess, this::measFailure);
        return true;
    }

    private void measSuccess(TempLabel2 tempLabel2) {
        String strData = tempLabel2.getStrData();
        XLog.i("strData = " + strData);
        Activity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> {
                mAdapter.addData(0, tempLabel2);
                mSelectData.add(tempLabel2.getStrEpc());

                int size = mAdapter.getData().size();
                if (size == tempLabel2.getTagCount()) {
                    binding.ivArrow.setVisibility(View.VISIBLE);
                    mArrayAdapter.notifyDataSetChanged();

                    String s2 = StringFormat.formatTempLabel2ResultCode(tempLabel2.getResultCode());
                    showToast(s2);
                }
                if (mShow) {
                    mShow = false;
                    try {
                        convertToTemp(strData);
                        if (mList.size() > 0) {
                            ShowTempResultChartActivity.start(getContext());
                        }
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }

    private void convertToTemp(String strData) {
        mList.clear();

        byte[] bytes = ArrayUtils.hexStrToByteArr(strData, " ");
        int len = bytes.length / 4;
        for (int i = 0; i < len; i++) {
            byte h = bytes[i * 4 + 1];
            byte l = bytes[i * 4];
            byte[] point = new byte[]{h, l};
            float temp = (float) (bitToInt(point, 10) / 4.0) + 0;
            mList.add(temp);
        }
    }

    public int bitToInt(@NonNull byte[] bytes, int bit) {
        return (int) ((byte2ToUnsignedShort(bytes, 0) << (32 - bit)) / Math.pow(2, 32 - bit));
    }

    public int byte2ToUnsignedShort(byte[] bytes, int off) {
        int high = bytes[off];
        int low = bytes[off + 1];
        return (high << 8 & 0xFF00) | (low & 0xFF);
    }

    private void measFailure(Failure failure) {
        Activity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> {
                int index = binding.spOptType.getSelectedIndex();
                binding.btnMeasTag.setText(mOptTypes[index]);
                String msg = binding.btnMeasTag.getText().toString() + StringFormat.formatTempLabel2ResultCode(failure.getErrorCode());
                showToast(msg);
            });
        }
    }

    /**
     * 1.单次测量
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getSingleMeas() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        TagMeasOpt opt;
        switch (binding.spMeasType.getSelectedIndex()) {
            case 1:
                opt = TagMeasOpt.MeasVolt;
                break;
            case 2:
                opt = TagMeasOpt.MeasExTempVolt;
                break;
            case 3:
                opt = TagMeasOpt.MeasExPressVolt;
                break;
            default:
                opt = TagMeasOpt.MeasTemp;
        }
        return new MtSingleMeasTemp.Builder()
                .setPasswords(hexPasswords)
                .setTagMeasOpt(opt)
                .build();
    }

    /**
     * 2.开启RTC测温
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getEnableRtc() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        delayTime = Utils.parseInt(binding.etDelayMeas, -1, getString(R.string.input_delay_meas));
        if (delayTime == -1) {
            return null;
        }

        measInterval = Utils.parseInt(binding.etMeasInterval, -1, getString(R.string.input_meas_intervel));
        if (measInterval == -1) {
            return null;
        }

        tempUpperLimit = Utils.parseInt(binding.etTempUpperLimit, -1, getString(R.string.input_temp_upper_limit));
        if (tempUpperLimit == -1) {
            return null;
        }

        tempLowerLimit = Utils.parseInt(binding.etTempLowerLimit, -1, getString(R.string.input_temp_lower_limit));
        if (tempLowerLimit == -1) {
            return null;
        }

        measCount = Utils.parseInt(binding.etMeasTimes, -1, getString(R.string.input_meas_times));
        if (measCount == -1) {
            return null;
        }
        return new MtEnableRtcMeasTemp.Builder()
                .setPasswords(hexPasswords)
                .setDelayMeasTime(delayTime)
                .setMeasInterval(measInterval)
                .setTempMax(tempUpperLimit)
                .setTempMin(tempLowerLimit)
                .setMeasCount(measCount)
                .build();
    }

    /**
     * 3.停止RTC测温
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getDisableRtc() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        String hexAuthPwd = binding.etAuthPassword.getText().toString().toUpperCase();
        if (hexAuthPwd.isEmpty()) {
            showToast(getString(R.string.auth_password_error));
            return null;
        }
        return new MtDisableRtcMeasTemp.Builder()
                .setPasswords(hexPasswords)
                .setAuthPwd(hexAuthPwd)
                .build();
    }

    /**
     * 4.加载配置
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getLoadConfig() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        return new MtLoadConfig.Builder()
                .setPasswords(hexPasswords)
                .build();
    }

    /**
     * 5.读寄存器
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getReadRegister() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        String hexPtr = binding.etData.getText().toString().toUpperCase();
        if (hexPtr.isEmpty()) {
            showToast(getString(R.string.register_address_error));
            return null;
        }
        return new MtReadRegister.Builder()
                .setPasswords(hexPasswords)
                .setPtr(hexPtr)
                .build();
    }

    /**
     * 6.状态查询
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getStateCheck() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        return new MtStateCheck.Builder()
                .setPasswords(hexPasswords)
                .build();
    }

    /**
     * 7.认证
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getAuth() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        String hexAuthPwd = binding.etAuthPassword.getText().toString().toUpperCase();
        if (hexAuthPwd.isEmpty()) {
            showToast(getString(R.string.auth_password_error));
            return null;
        }
        return new MtAuth.Builder()
                .setPasswords(hexPasswords)
                .setAuthPwd(hexAuthPwd)
                .build();
    }

    /**
     * 8.读内存
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getReadMemory() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        String hexAuthPwd = binding.etAuthPassword.getText().toString().toUpperCase();
        if (hexAuthPwd.isEmpty()) {
            showToast(getString(R.string.auth_password_error));
            return null;
        }
        int startAddress = Utils.parseInt(binding.etDataStartAdd, -1, getString(R.string.parameter_error));
        if (startAddress == -1) {
            return null;
        }
        int count = Utils.parseInt(binding.etDataLen, -1, getString(R.string.parameter_error));
        if (count == -1) {
            return null;
        }
        return new MtReadMemory.Builder()
                .setPasswords(hexPasswords)
                .setAuthPwd(hexAuthPwd)
                .setStartAddress(startAddress)
                .setLength(count)
                .build();
    }

    /**
     * 9.写内存
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getWriteMemory() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        String hexAuthPwd = binding.etAuthPassword.getText().toString().toUpperCase();
        if (hexAuthPwd.isEmpty()) {
            showToast(getString(R.string.auth_password_error));
            return null;
        }
        int startAddress = Utils.parseInt(binding.etDataStartAdd, -1, getString(R.string.parameter_error));
        if (startAddress == -1) {
            return null;
        }
        int count = Utils.parseInt(binding.etDataLen, -1, getString(R.string.parameter_error));
        if (count == -1) {
            return null;
        }
        String hexData = binding.etData.getText().toString().toUpperCase();

        if (hexData.isEmpty()) {
            showToast(getString(R.string.incorrect_data_length));
            return null;
        }
        byte[] bytes = ArrayUtils.hexStringToBytes(hexData);

        return new MtWriteMemory.Builder()
                .setPasswords(hexPasswords)
                .setAuthPwd(hexAuthPwd)
                .setStartAddress(startAddress)
                .setCount(count)
                .setData(bytes)
                .build();
    }

    /**
     * 10.LED控制亮灭
     *
     * @return {@link TempLabel2Info}
     */
    private TempLabel2Info getLedControl() {
        String hexPasswords = binding.etAccessCode.getText().toString().toUpperCase();
        if (hexPasswords.isEmpty()) {
            showToast(getString(R.string.wrong_password));
            return null;
        }
        int selectId = binding.spLedControl.getSelectedIndex();
        return new MtLedControl.Builder()
                .setPasswords(hexPasswords)
                .setBright(selectId == 0)
                .build();
    }

    @Override
    public void onResume() {
        super.onResume();
        int index = binding.spOptType.getSelectedIndex();
        binding.btnMeasTag.setText(mOptTypes[index]);
    }

    private void updateEpc(String maskValue) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> binding.etEpc.setText(maskValue));
        }
    }

    private void showListPopWindow() {
        Context context = getContext();
        if (context == null) {
            return;
        }
        if (mPopupWindow == null) {
            ObjectAnimator.ofFloat(binding.ivArrow, "rotation", 0, 180)
                    .setDuration(200)
                    .start();
            mPopupWindow = new ListPopupWindow(context);
            mPopupWindow.setAdapter(mArrayAdapter);
            mPopupWindow.setAnchorView(binding.etEpc);
            mPopupWindow.setModal(true);
            mPopupWindow.setOnItemClickListener((adapterView, view, i, l) -> {
                mPopupWindow.dismiss();
                binding.etEpc.setText(mSelectData.get(i));
            });
            mPopupWindow.setOnDismissListener(() -> ObjectAnimator.ofFloat(binding.ivArrow, "rotation", 180, 0)
                    .setDuration(200)
                    .start());
        }
        mPopupWindow.show();
    }

    @Override
    public void onDestroy() {
        mH.removeCallbacksAndMessages(null);
        super.onDestroy();
        mAdapter = null;
        mSelectData = null;
        mPopupWindow = null;
        mArrayAdapter = null;
    }
}
