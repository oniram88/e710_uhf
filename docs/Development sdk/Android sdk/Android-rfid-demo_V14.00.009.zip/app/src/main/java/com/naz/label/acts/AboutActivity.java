package com.naz.label.acts;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.naz.label.BuildConfig;
import com.naz.label.R;
import com.naz.label.base.BaseActivity;
import com.naz.label.databinding.ActivityAboutBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.XLog;
import com.payne.reader.communication.DataPacket;
import com.payne.reader.util.ArrayUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author naz
 */
public class AboutActivity extends BaseActivity<ActivityAboutBinding> {
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            DataPacket p = (DataPacket) msg.obj;
            ReaderHelper.getReader().sendCustomRequest(p);
            byte[] data = p.getData();
            XLog.i(ArrayUtils.bytesToHexString(data, 0, data.length));

            if (binding.btnTransmit.isSelected()) {
                msg = Message.obtain(msg);
                sendMessageDelayed(msg, msg.what);
            }
        }
    };

    @Override
    protected ActivityAboutBinding getViewBinding() {
        return ActivityAboutBinding.inflate(getLayoutInflater());
    }

    @Override
    public void initView() {
        setTitle(R.string.about);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        binding.tvVersion.setText(getString(R.string.software_version, BuildConfig.VERSION_NAME));

        int[] c1 = {0};
        binding.tvVersion.setOnClickListener(v -> {
            if (++c1[0] > 5) {
                c1[0] = 0;
                binding.clTransmit.setVisibility(View.VISIBLE);
            }
        });
        binding.btnTransmit.setOnClickListener(v -> {
            if (binding.btnTransmit.isSelected()) {
                binding.btnTransmit.setSelected(false);
                mHandler.removeCallbacksAndMessages(null);
                return;
            }
            try {
                int time = Integer.parseInt(binding.etTime.getText().toString(), 10);
                int freq = Integer.parseInt(binding.etFreq.getText().toString(), 10);
                int power = Integer.parseInt(binding.etPower.getText().toString(), 10);
                int interval = Integer.parseInt(binding.etInterval.getText().toString(), 10);

                byte[] coreBs = new byte[5];
                coreBs[0] = ArrayUtils.intToByteArray(time, 1)[0];
                byte[] bytes = ArrayUtils.intToByteArray(freq, 3);
                coreBs[1] = bytes[0];
                coreBs[2] = bytes[1];
                coreBs[3] = bytes[2];
                coreBs[4] = ArrayUtils.intToByteArray(power, 1)[0];

                DataPacket p = new DataPacket((byte) 0xff, (byte) 0xAC, coreBs);

                binding.btnTransmit.setSelected(true);

                Message msg = Message.obtain();
                msg.what = interval;
                msg.obj = p;
                mHandler.sendMessage(msg);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String date = format.format(new Date(BuildConfig.BUILD_TIMESTAMP));
        binding.tvTime.setText(getString(R.string.release_date, date));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        mHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}