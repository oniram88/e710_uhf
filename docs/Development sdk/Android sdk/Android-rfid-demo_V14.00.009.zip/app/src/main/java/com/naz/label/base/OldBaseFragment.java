package com.naz.label.base;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Base fragment
 *
 * @author gpenghui
 * date 2018/8/23
 */

public abstract class OldBaseFragment extends BaseDialogFragment {
    private Unbinder unbinder;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View parent = inflater.inflate(getLayoutResId(), container, false);
        unbinder = ButterKnife.bind(this, parent);
        initView(parent, inflater, container);
        return parent;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    /**
     * @param msg 内容
     */
    protected void showToast(String msg) {
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }
        if ("main".equalsIgnoreCase(Thread.currentThread().getName())) {
            Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
        } else {
            activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * @param strResId 文字资源Id
     */
    protected void showToast(@StringRes int strResId) {
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if ("main".equalsIgnoreCase(Thread.currentThread().getName())) {
            Toast.makeText(activity, strResId, Toast.LENGTH_SHORT).show();
        } else {
            activity.runOnUiThread(() -> Toast.makeText(activity, strResId, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    protected ViewBinding getViewBinding() {
        return null;
    }

    /**
     * 设置布局id
     *
     * @return 布局id
     */
    @LayoutRes
    public abstract int getLayoutResId();

    /**
     * 初始化View
     *
     * @param parent    view
     * @param inflater  inflater
     * @param container container
     */
    public abstract void initView(View parent, LayoutInflater inflater, ViewGroup container);
}
