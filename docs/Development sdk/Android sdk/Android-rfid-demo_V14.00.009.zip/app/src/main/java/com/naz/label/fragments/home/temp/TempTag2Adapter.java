package com.naz.label.fragments.home.temp;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.R;
import com.naz.label.util.StringFormat;
import com.payne.reader.bean.receive.TempLabel2;

import java.util.List;

/**
 * @author naz
 * Date 2020/4/3
 */
public class TempTag2Adapter extends BaseQuickAdapter<TempLabel2, BaseViewHolder> {
    public TempTag2Adapter(@Nullable List<TempLabel2> data) {
        super(R.layout.item_temp_tag2, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, TempLabel2 item) {
        int count = getData().size();
        helper.setText(R.id.tv_id, String.valueOf(count - helper.getAdapterPosition()));
        helper.setText(R.id.tv_pc, item.getStrPc());
        helper.setText(R.id.tv_crc, item.getStrCrc());
        helper.setText(R.id.tv_epc, item.getStrEpc());
        helper.setText(R.id.tv_data, item.getStrData());
        helper.setText(R.id.tv_status, StringFormat.formatTempLabel2ResultCode(item.getResultCode()));
        helper.setText(R.id.tv_ant_id, String.valueOf(item.getAntId()));
        helper.setText(R.id.tv_count, String.valueOf(item.getReadCount()));
    }
}
