package com.naz.label.widget;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Looper;
import android.text.Editable;
import android.transition.TransitionManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintSet;

import com.naz.label.GlobalCfg;
import com.naz.label.R;
import com.naz.label.util.Utils;
import com.payne.reader.Reader;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.Success;
import com.payne.reader.bean.send.InventoryParam;
import com.naz.label.databinding.ViewInventoryConfigBinding;
import com.naz.label.util.ReaderHelper;
import com.naz.label.util.ScreenUtils;
import com.naz.label.util.XLog;
import com.payne.reader.base.BaseInventory;
import com.payne.reader.bean.config.AntennaCount;
import com.payne.reader.bean.config.EightAntenna;
import com.payne.reader.bean.config.FastTidType;
import com.payne.reader.bean.config.FourAntenna;
import com.payne.reader.bean.config.HighEightAntenna;
import com.payne.reader.bean.config.Session;
import com.payne.reader.bean.config.Target;
import com.payne.reader.bean.receive.Version;
import com.payne.reader.bean.send.CustomSessionTargetInventory;
import com.payne.reader.bean.send.FastSwitchEightAntennaInventory;
import com.payne.reader.bean.send.FastSwitchFourAntennaInventory;
import com.payne.reader.bean.send.FastSwitchSingleAntennaInventory;
import com.payne.reader.bean.send.FastSwitchSixteenAntennaInventory;

import org.angmarch.views.NiceSpinner;
import org.angmarch.views.OnSpinnerItemSelectedListener;

import java.util.zip.Inflater;

/**
 * @author naz
 * Date 2020/4/10
 */
public class InventoryConfigView extends CardView {
    public ViewInventoryConfigBinding mBinding;
    private Context mContext;
    private FastTidType mFastTidTidType;

    private CompoundButton.OnCheckedChangeListener fastL = (buttonView, isChecked) -> {
        String str = buttonView.getText().toString();
        str = str.replace("天线", "et_fast_ant").replace("Ant ", "et_fast_ant");
        str += "_time";
        int id = getResources().getIdentifier(str, "id", buttonView.getContext().getPackageName());
        EditText et = mBinding.getRoot().findViewById(id);
        et.setText(isChecked ? "1" : "0");
    };

    public InventoryConfigView(@NonNull Context context) {
        this(context, null);
    }

    public InventoryConfigView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public InventoryConfigView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        mContext = context;
        LayoutInflater inflater = LayoutInflater.from(context);
        mBinding = ViewInventoryConfigBinding.inflate(inflater, this);

        mBinding.spFastAnt1.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt2.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt3.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt4.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt5.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt6.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt7.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt8.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt9.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt10.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt11.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt12.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt13.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt14.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt15.setOnCheckedChangeListener(fastL);
        mBinding.spFastAnt16.setOnCheckedChangeListener(fastL);

        mBinding.tvFastAnt1TimesTip.setOnLongClickListener(v -> {
            Editable text = mBinding.etFastAnt1Time.getText();
            mBinding.etFastAnt2Time.setText(text);
            mBinding.etFastAnt3Time.setText(text);
            mBinding.etFastAnt4Time.setText(text);
            mBinding.etFastAnt5Time.setText(text);
            mBinding.etFastAnt6Time.setText(text);
            mBinding.etFastAnt7Time.setText(text);
            mBinding.etFastAnt8Time.setText(text);
            return true;
        });
        mBinding.tvFastAnt9TimesTip.setOnLongClickListener(v -> {
            Editable text = mBinding.etFastAnt9Time.getText();
            mBinding.etFastAnt10Time.setText(text);
            mBinding.etFastAnt11Time.setText(text);
            mBinding.etFastAnt12Time.setText(text);
            mBinding.etFastAnt13Time.setText(text);
            mBinding.etFastAnt14Time.setText(text);
            mBinding.etFastAnt15Time.setText(text);
            mBinding.etFastAnt16Time.setText(text);
            return true;
        });

        //Fast Tid选中监听
        mBinding.cbFastTid.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && mBinding.cbTagFocus.isChecked()) {
                mBinding.cbTagFocus.setChecked(false);
            }
            onFastTid(buttonView);
        });
        //Tag Focus选中监听
        mBinding.cbTagFocus.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && mBinding.cbFastTid.isChecked()) {
                mBinding.cbFastTid.setChecked(false);
            }
            onFastTid(buttonView);
        });
        mBinding.cbReadTID.setOnCheckedChangeListener((buttonView, isChecked) -> {
            boolean fastTidChecked = mBinding.cbFastTid.isChecked();
            boolean tagFocusChecked = mBinding.cbTagFocus.isChecked();

            mBinding.cbFastTid.setChecked(false);
            mBinding.cbTagFocus.setChecked(false);
            mBinding.cbFastTid.setEnabled(!isChecked);
            mBinding.cbTagFocus.setEnabled(!isChecked);

            mBinding.cbFastSwitchAnt.setEnabled(!isChecked);
            mBinding.spSession.setEnabled(!isChecked);
            mBinding.spTarget.setEnabled(!isChecked);
            mBinding.etRepeatCount.setEnabled(!isChecked);

            mBinding.cbFreezer.setChecked(false);
            mBinding.cbFreezer.setEnabled(!isChecked);
            mBinding.cbPhase.setChecked(false);
            mBinding.cbPhase.setEnabled(!isChecked);
            mBinding.cbFastMode.setChecked(false);
            mBinding.cbFastMode.setEnabled(!isChecked);
            mBinding.etLoopCount.setEnabled(!isChecked);

            if (isChecked && (fastTidChecked || tagFocusChecked)) {
                onFastTid(mBinding.cbFastTid);
            }
        });

        OnSpinnerItemSelectedListener listener = (NiceSpinner parent, View view, int position, long id) -> {
            AntennaCount count = Utils.getAntEnumByIndex(position);
            ReaderHelper.getReader().switchAntennaCount(count);

            antCountChange(position);
        };
        mBinding.spAntennaCount.setOnSpinnerItemSelectedListener(listener);
        mBinding.cbFastSwitchAnt.setOnCheckedChangeListener((v, isChecked) -> {
            antCountChange(mBinding.spAntennaCount.getSelectedIndex());
            if (isChecked) {
                mBinding.cbFastMode.setChecked(false);
                mBinding.cbFastMode.setEnabled(false);
                mBinding.cbFreezer.setEnabled(true);
            } else {
                mBinding.cbFastMode.setEnabled(true);
                mBinding.cbFreezer.setChecked(false);
                mBinding.cbFreezer.setEnabled(false);
            }
        });
    }

    public void onFastTid(View v) {
        FastTidType type;
        if (v.getId() == mBinding.cbFastTid.getId()) {
            type = mBinding.cbFastTid.isChecked() ? FastTidType.FAST_TAG : FastTidType.DISABLE;
        } else {
            type = mBinding.cbTagFocus.isChecked() ? FastTidType.FOCUS_TAG : FastTidType.DISABLE;
        }
        Consumer<Success> successConsumer = success -> {
            mFastTidTidType = type;
            setResult(v, true);
        };
        Consumer<Failure> failureConsumer = failure -> setResult(v, false);
        ReaderHelper.getReader().setImpinjFastTid(type, true, successConsumer, failureConsumer);
    }

    private void antCountChange(int position) {
        ConstraintSet set = new ConstraintSet();
        set.clone(mBinding.clContent);

        boolean isFastSwitch = mBinding.cbFastSwitchAnt.isChecked();
        boolean isShow = (position == 1 || position == 2 || position == 3) && !isFastSwitch;
        int showHide = isShow ? View.VISIBLE : View.GONE;
        set.setVisibility(mBinding.cbAnt1.getId(), showHide);
        set.setVisibility(mBinding.cbAnt2.getId(), showHide);
        set.setVisibility(mBinding.cbAnt3.getId(), showHide);
        set.setVisibility(mBinding.cbAnt4.getId(), showHide);

        isShow = (position == 2 || position == 3) && !isFastSwitch;
        showHide = isShow ? View.VISIBLE : View.GONE;
        set.setVisibility(mBinding.cbAnt5.getId(), showHide);
        set.setVisibility(mBinding.cbAnt6.getId(), showHide);
        set.setVisibility(mBinding.cbAnt7.getId(), showHide);
        set.setVisibility(mBinding.cbAnt8.getId(), showHide);

        showHide = (position == 3 && !isFastSwitch) ? View.VISIBLE : View.GONE;
        set.setVisibility(mBinding.cbAnt9.getId(), showHide);
        set.setVisibility(mBinding.cbAnt10.getId(), showHide);
        set.setVisibility(mBinding.cbAnt11.getId(), showHide);
        set.setVisibility(mBinding.cbAnt12.getId(), showHide);
        set.setVisibility(mBinding.cbAnt13.getId(), showHide);
        set.setVisibility(mBinding.cbAnt14.getId(), showHide);
        set.setVisibility(mBinding.cbAnt15.getId(), showHide);
        set.setVisibility(mBinding.cbAnt16.getId(), showHide);

        isShow = (position == 1 || position == 2 || position == 3) && isFastSwitch;
        showHide = isShow ? View.VISIBLE : View.GONE;
        set.setVisibility(mBinding.tvFastAnt1Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt1.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt1TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt1Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt2Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt2.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt2TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt2Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt3Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt3.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt3TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt3Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt4Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt4.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt4TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt4Time.getId(), showHide);

        isShow = (position == 2 || position == 3) && isFastSwitch;
        showHide = isShow ? View.VISIBLE : View.GONE;
        set.setVisibility(mBinding.tvFastAnt5Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt5.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt5TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt5Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt6Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt6.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt6TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt6Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt7Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt7.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt7TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt7Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt8Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt8.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt8TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt8Time.getId(), showHide);

        showHide = (position == 3 && isFastSwitch) ? View.VISIBLE : View.GONE;
        set.setVisibility(mBinding.tvFastAnt9Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt9.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt9TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt9Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt10Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt10.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt10TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt10Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt11Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt11.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt11TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt11Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt12Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt12.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt12TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt12Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt13Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt13.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt13TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt13Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt14Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt14.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt14TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt14Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt15Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt15.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt15TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt15Time.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt16Tip.getId(), showHide);
        set.setVisibility(mBinding.spFastAnt16.getId(), showHide);
        set.setVisibility(mBinding.tvFastAnt16TimesTip.getId(), showHide);
        set.setVisibility(mBinding.etFastAnt16Time.getId(), showHide);

        TransitionManager.beginDelayedTransition(mBinding.clContent);
        set.applyTo(mBinding.clContent);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {//消费点击事件
        return true;
    }

    public void onOpened() {
        AntennaCount antennaCount = ReaderHelper.getReader().getAntennaCount();
        int index = Utils.getIndexByAntEnum(antennaCount);
        int selectedIndex = mBinding.spAntennaCount.getSelectedIndex();
        if (index != selectedIndex) {
            mBinding.spAntennaCount.setSelectedIndex(index);
            antCountChange(index);
        }

        if (mFastTidTidType != null) {
            return;
        }
        Version version = GlobalCfg.get().getVersion();
        if (version != null) {
            Version.ChipType chipType = version.getChipType();
            if (chipType != null) {
                switch (chipType) {
                    case E710:
                    case FDW:
                        mBinding.cbFastMode.setVisibility(VISIBLE);
                        break;
                    case TM670:
                        mBinding.cbFastTid.setVisibility(GONE);
                        mBinding.tvFastTidTip.setVisibility(GONE);
                        mBinding.cbTagFocus.setVisibility(GONE);
                        mBinding.tvTagFocusTip.setVisibility(GONE);
                        return;
                }
            }
        }
        mBinding.cbFastTid.setVisibility(VISIBLE);
        mBinding.tvFastTidTip.setVisibility(VISIBLE);
        mBinding.cbTagFocus.setVisibility(VISIBLE);
        mBinding.tvTagFocusTip.setVisibility(VISIBLE);

        ReaderHelper.getReader().getImpinjFastTid(impinjFastTid -> {
            Activity activity = (Activity) mContext;
            if (activity == null) {
                return;
            }
            activity.runOnUiThread(() -> {
                mFastTidTidType = impinjFastTid.getTidType();
                mBinding.cbTagFocus.setChecked(mFastTidTidType == FastTidType.FOCUS_TAG);
                mBinding.cbFastTid.setChecked(mFastTidTidType == FastTidType.FAST_TAG);
            });
        }, failure -> {
            Activity activity = (Activity) mContext;
            if (activity == null) {
                return;
            }
            String errStr = activity.getResources().getString(R.string.get_fast_tid_error);
            XLog.w(errStr);
            Looper.prepare();
            Toast.makeText(activity, errStr, Toast.LENGTH_SHORT).show();
            Looper.loop();
        });
    }

    private void setResult(View v, boolean success) {
        Activity activity = (Activity) mContext;
        if (activity != null) {
            activity.runOnUiThread(() -> {
                if (success) {
                    String str = activity.getString(R.string.set_success);
                    if (mFastTidTidType == FastTidType.DISABLE) {
                        str += ":" + activity.getResources().getString(R.string.close);
                    }
                    Toast.makeText(activity, str, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, R.string.set_error, Toast.LENGTH_SHORT).show();
                    if (v.getId() == mBinding.cbFastTid.getId()) {
                        mBinding.cbFastTid.setChecked(!mBinding.cbFastTid.isChecked());
                    } else {
                        mBinding.cbTagFocus.setChecked(!mBinding.cbTagFocus.isChecked());
                    }
                }
            });
        }
    }

    public void getInventoryParam(InventoryParam param) {
        if (param == null) {
            param = new InventoryParam();
        }
        int position = mBinding.spAntennaCount.getSelectedIndex();
        AntennaCount count = Utils.getAntEnumByIndex(position);
        param.setAntennaCount(count);

        boolean isFastSwitch = mBinding.cbFastSwitchAnt.isChecked();

        int loopCount = 0;
        try {
            String str = mBinding.etLoopCount.getText().toString().trim();
            loopCount = Integer.parseInt(str);
        } catch (Exception ignored) {
        }
        if (loopCount <= 0) {
            loopCount = -1;
            mBinding.etLoopCount.setText("-1");
        }
        param.setLoopCount(loopCount);

        Session session = Session.valueOf((byte) mBinding.spSession.getSelectedIndex());
        Target target = Target.valueOf((byte) mBinding.spTarget.getSelectedIndex());
        byte repeat = parseByte(mBinding.etRepeatCount, (byte) 1);
        byte interval = parseByte(mBinding.etInterval, (byte) 0);
        boolean enablePhase = mBinding.cbPhase.isChecked();

        boolean isFreezer = mBinding.cbFreezer.isChecked();
        if (isFreezer && repeat < 2) {
            repeat = (byte) 2;
        }
        param.setSession(session);
        param.setTarget(target);
        param.setRepeat(repeat);
        param.clearCustomSessionIds();

        if (isFastSwitch) {
            BaseInventory inventory = null;
            if (position == 0) {/* 快速单天线盘存 */
                try {
                    FastSwitchSingleAntennaInventory.Builder builder = new FastSwitchSingleAntennaInventory.Builder()
                            .session(session)
                            .target(target)
                            .repeat(repeat)
                            .interval(interval)
                            .enablePhase(enablePhase);
                    if (isFreezer) {
                        builder.reserve1((byte) 0x5A);
                        builder.reserve2((byte) 0xA5);
                    } else {
                        builder.reserve1((byte) 0x00);
                        builder.reserve2((byte) 0x00);
                    }
                    inventory = builder.build();
                } catch (Exception e) {
                    XLog.w(Log.getStackTraceString(e));
                }
            } else if (position == 1) {/* 快速4天线盘存 */
                try {
                    FastSwitchFourAntennaInventory.Builder builder = new FastSwitchFourAntennaInventory.Builder()
                            .antennaA(FourAntenna.ANT_A).stayA(parseByte(mBinding.etFastAnt1Time))
                            .antennaB(FourAntenna.ANT_B).stayB(parseByte(mBinding.etFastAnt2Time))
                            .antennaC(FourAntenna.ANT_C).stayC(parseByte(mBinding.etFastAnt3Time))
                            .antennaD(FourAntenna.ANT_D).stayD(parseByte(mBinding.etFastAnt4Time))
                            .session(session)
                            .target(target)
                            .repeat(repeat)
                            .interval(interval)
                            .enablePhase(enablePhase);
                    if (isFreezer) {
                        builder.reserve1((byte) 0x5A);
                        builder.reserve2((byte) 0xA5);
                    } else {
                        builder.reserve1((byte) 0x00);
                        builder.reserve2((byte) 0x00);
                    }
                    inventory = builder.build();
                } catch (Exception e) {
                    XLog.w(Log.getStackTraceString(e));
                }
            } else if (position == 2) {/* 快速8天线盘存 */
                try {
                    FastSwitchEightAntennaInventory.Builder builder = new FastSwitchEightAntennaInventory.Builder()
                            .antennaA(EightAntenna.ANT_A).stayA(parseByte(mBinding.etFastAnt1Time))
                            .antennaB(EightAntenna.ANT_B).stayB(parseByte(mBinding.etFastAnt2Time))
                            .antennaC(EightAntenna.ANT_C).stayC(parseByte(mBinding.etFastAnt3Time))
                            .antennaD(EightAntenna.ANT_D).stayD(parseByte(mBinding.etFastAnt4Time))
                            .antennaE(EightAntenna.ANT_E).stayE(parseByte(mBinding.etFastAnt5Time))
                            .antennaF(EightAntenna.ANT_F).stayF(parseByte(mBinding.etFastAnt6Time))
                            .antennaG(EightAntenna.ANT_G).stayG(parseByte(mBinding.etFastAnt7Time))
                            .antennaH(EightAntenna.ANT_H).stayH(parseByte(mBinding.etFastAnt8Time))
                            .session(session)
                            .target(target)
                            .repeat(repeat)
                            .interval(interval)
                            .enablePhase(enablePhase);
                    if (isFreezer) {
                        builder.reserve1((byte) 0x5A);
                        builder.reserve2((byte) 0xA5);
                    } else {
                        builder.reserve1((byte) 0x00);
                        builder.reserve2((byte) 0x00);
                    }
                    inventory = builder.build();
                } catch (Exception e) {
                    XLog.w(Log.getStackTraceString(e));
                }
            } else if (position == 3) {/* 快速16天线盘存 */
                try {
                    FastSwitchSixteenAntennaInventory.Builder builder = new FastSwitchSixteenAntennaInventory.Builder()
                            .antennaA(EightAntenna.ANT_A).stayA(parseByte(mBinding.etFastAnt1Time))
                            .antennaB(EightAntenna.ANT_B).stayB(parseByte(mBinding.etFastAnt2Time))
                            .antennaC(EightAntenna.ANT_C).stayC(parseByte(mBinding.etFastAnt3Time))
                            .antennaD(EightAntenna.ANT_D).stayD(parseByte(mBinding.etFastAnt4Time))
                            .antennaE(EightAntenna.ANT_E).stayE(parseByte(mBinding.etFastAnt5Time))
                            .antennaF(EightAntenna.ANT_F).stayF(parseByte(mBinding.etFastAnt6Time))
                            .antennaG(EightAntenna.ANT_G).stayG(parseByte(mBinding.etFastAnt7Time))
                            .antennaH(EightAntenna.ANT_H).stayH(parseByte(mBinding.etFastAnt8Time))
                            .antennaI(HighEightAntenna.ANT_I).stayI(parseByte(mBinding.etFastAnt9Time))
                            .antennaJ(HighEightAntenna.ANT_J).stayJ(parseByte(mBinding.etFastAnt10Time))
                            .antennaK(HighEightAntenna.ANT_K).stayK(parseByte(mBinding.etFastAnt11Time))
                            .antennaL(HighEightAntenna.ANT_L).stayL(parseByte(mBinding.etFastAnt12Time))
                            .antennaM(HighEightAntenna.ANT_M).stayM(parseByte(mBinding.etFastAnt13Time))
                            .antennaN(HighEightAntenna.ANT_N).stayN(parseByte(mBinding.etFastAnt14Time))
                            .antennaO(HighEightAntenna.ANT_O).stayO(parseByte(mBinding.etFastAnt15Time))
                            .antennaP(HighEightAntenna.ANT_P).stayP(parseByte(mBinding.etFastAnt16Time))
                            .session(session)
                            .target(target)
                            .repeat(repeat)
                            .interval(interval)
                            .enablePhase(enablePhase);
                    if (isFreezer) {
                        builder.reserve1((byte) 0x5A);
                        builder.reserve2((byte) 0xA5);
                    } else {
                        builder.reserve1((byte) 0x00);
                        builder.reserve2((byte) 0x00);
                    }
                    inventory = builder.build();
                } catch (Exception e) {
                    XLog.w(Log.getStackTraceString(e));
                }
            }
            param.setInventory(inventory);
            if (position > 0) {
                Resources resources = getResources();
                String packageName = XLog.sContext.getPackageName();
                for (int i = 0; i < 16; i++) {
                    int id = resources.getIdentifier("et_fast_ant" + (i + 1) + "_time", "id", packageName);
                    EditText et = findViewById(id);
                    boolean sel = et.isShown() && (Utils.parseInt(et, 0) > 0);
                    if (sel) {
                        param.addCustomSessionId(i);
                        return;
                    }
                }
            } else {
                param.addCustomSessionId(0);
            }
        } else {

            if (position > 0) {
                Resources resources = getResources();
                String packageName = XLog.sContext.getPackageName();
                for (int i = 0; i < 16; i++) {
                    int id = resources.getIdentifier("cb_ant_" + (i + 1), "id", packageName);
                    CheckBox cb = findViewById(id);
                    boolean sel = cb.isShown() && cb.isChecked();
                    if (sel) {
                        param.addCustomSessionId(i);
                    }
                }
            } else {
                param.addCustomSessionId(0);
            }
            BaseInventory inventory = new CustomSessionTargetInventory.Builder()
                    .session(session)
                    .target(target)
                    .repeat(repeat)
                    .enablePhase(enablePhase)
                    .build();
            param.setInventory(inventory);
        }
    }

    public static byte parseByte(EditText et) {
        return parseByte(et, (byte) 0);
    }

    public static byte parseByte(EditText et, byte miniNum) {
        byte value;
        try {
            String str = et.getText().toString();
            value = (byte) Integer.parseInt(str, 10);
        } catch (Exception ignored) {
            value = miniNum;
        }
        if (value <= miniNum) {
            value = miniNum;
            et.setText("" + miniNum);
        }
        return value;
    }
}