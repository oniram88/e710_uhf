package com.naz.label.widget;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.naz.label.R;
import com.naz.label.bean.LogBean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @author naz
 * Date 2020/7/1
 */
public class LogView extends FrameLayout {
    @BindView(R.id.tv_log_content)
    TextView tvLogContent;
    @BindView(R.id.iv_arrow)
    ImageView ivArrow;
    @BindView(R.id.v_line)
    View vLine;
    @BindView(R.id.rv_log)
    RecyclerView rvLog;

    private LogAdapter mAdapter;

    public LogView(@NonNull Context context) {
        this(context, null);
    }

    public LogView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LogView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.view_log, this, true);
        ButterKnife.bind(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        rvLog.setLayoutManager(linearLayoutManager);
        mAdapter = new LogAdapter(new ArrayList<>());
        rvLog.setAdapter(mAdapter);
    }

    @OnClick({R.id.iv_clear, R.id.v_header})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_clear:
                tvLogContent.setText("");
                mAdapter.getData().clear();
                mAdapter.notifyDataSetChanged();
                break;
            case R.id.v_header:
                if (rvLog.getVisibility() == View.VISIBLE) {
                    rvLog.setVisibility(View.GONE);
                    vLine.setVisibility(View.GONE);
                    ivArrow.setRotation(0);
                } else {
                    rvLog.setVisibility(View.VISIBLE);
                    vLine.setVisibility(View.VISIBLE);
                    ivArrow.setRotation(180);
                    mAdapter.notifyDataSetChanged();
                }
                break;
            default:
        }
    }

    /**
     * 添加log
     *
     * @param bean {@link LogBean 数据}
     */
    public void addData(LogBean bean) {
        if (getVisibility() != View.VISIBLE) {
            return;
        }
        tvLogContent.setTextColor(bean.isSuccess() ? Color.BLUE : Color.RED);
        tvLogContent.setText(bean.getMsg());
        List<LogBean> logBeans = mAdapter.getData();
        int size = logBeans.size();
        if (size > 50) {
            logBeans.remove(size - 1);
        }
        logBeans.add(0, bean);
        if (rvLog.getVisibility() == View.VISIBLE) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    public static class LogAdapter extends BaseQuickAdapter<LogBean, BaseViewHolder> {
        private SimpleDateFormat mDateFormat;

        public LogAdapter(@Nullable List<LogBean> data) {
            super(R.layout.item_log, data);
            mDateFormat = new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());
        }

        @Override
        protected void convert(BaseViewHolder helper, LogBean item) {
            helper.setText(R.id.tv_time, mContext.getString(R.string.time) + mDateFormat.format(new Date(item.getTime())));
            TextView tv = helper.getView(R.id.tv_data);
            tv.setTextColor(item.isSuccess() ? Color.BLUE : Color.RED);
            String msg = item.getMsg();
            tv.setText(msg);
        }
    }
}