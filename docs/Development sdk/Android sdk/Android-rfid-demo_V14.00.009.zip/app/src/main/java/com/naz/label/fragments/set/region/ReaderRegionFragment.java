package com.naz.label.fragments.set.region;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;

import com.naz.label.util.ToastUtils;
import com.naz.label.R;
import com.naz.label.base.OldBaseFragment;
import com.naz.label.util.ReaderHelper;
import com.payne.reader.base.Consumer;
import com.payne.reader.bean.config.Freq;
import com.payne.reader.bean.config.Region;
import com.payne.reader.bean.receive.Failure;
import com.payne.reader.bean.receive.FreqRegionResult;
import com.payne.reader.bean.receive.Success;
import com.payne.reader.bean.send.FreqNormal;
import com.payne.reader.bean.send.FreqUserDefine;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author naz
 * Date 2020/4/8
 */
public class ReaderRegionFragment extends OldBaseFragment {
    @BindView(R.id.radio_group_category)
    RadioGroup radioGroupCategory;
    @BindView(R.id.radio_group_normal)
    RadioGroup radioGroupNormal;
    @BindView(R.id.sp_start_freq)
    Spinner spStartFreq;
    @BindView(R.id.sp_end_freq)
    Spinner spEndFreq;
    @BindView(R.id.cv_normal)
    CardView cvNormal;
    @BindView(R.id.et_start_freq)
    EditText etStartFreq;
    @BindView(R.id.et_freq_interval)
    EditText etFreqInterval;
    @BindView(R.id.et_freq_count)
    EditText etFreqCount;
    @BindView(R.id.cv_custom)
    CardView cvCustom;
    @BindView(R.id.cl_parent)
    ConstraintLayout clParent;

    private Consumer<Success> successConsumer = success -> promptUi(getString(R.string.set_success));
    private Consumer<Failure> failureConsumer = failure -> promptUi(getString(R.string.set_error));

    @Override
    public int getLayoutResId() {
        return R.layout.fragment_reader_region;
    }

    @Override
    public void initView(View parent, LayoutInflater inflater, ViewGroup container) {
        radioGroupCategory.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rb_custom) {
                cvCustom.setVisibility(View.VISIBLE);
                cvNormal.setVisibility(View.GONE);
            } else {
                cvNormal.setVisibility(View.VISIBLE);
                cvCustom.setVisibility(View.GONE);
            }
        });
        changeData(radioGroupNormal.getCheckedRadioButtonId());
        radioGroupNormal.setOnCheckedChangeListener((group, checkedId) -> changeData(checkedId));
    }

    @OnClick({R.id.btn_get, R.id.btn_set})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_get:
                ReaderHelper.getReader().getFrequencyRegion(
                        this::updateUi,
                        errorBean -> promptUi(getString(R.string.read_error)));
                break;
            case R.id.btn_set:
                FreqNormal freqNormal;
                if (radioGroupCategory.getCheckedRadioButtonId() == R.id.rb_normal) {
                    if (radioGroupNormal.getCheckedRadioButtonId() == R.id.rb_ets) {
                        freqNormal = new FreqNormal.Builder()
                                .setRegion(Region.ETSI)
                                .setFreqStart(Freq.valueOf((byte) spStartFreq.getSelectedItemPosition()))
                                .setFreqEnd(Freq.valueOf((byte) spEndFreq.getSelectedItemPosition()))
                                .build();
                    } else if (radioGroupNormal.getCheckedRadioButtonId() == R.id.rb_chn) {
                        freqNormal = new FreqNormal.Builder()
                                .setRegion(Region.CHN)
                                .setFreqStart(Freq.valueOf((byte) (spStartFreq.getSelectedItemPosition() + 43)))
                                .setFreqEnd(Freq.valueOf((byte) (spEndFreq.getSelectedItemPosition() + 43)))
                                .build();
                    } else {
                        freqNormal = new FreqNormal.Builder()
                                .setRegion(Region.FCC)
                                .setFreqStart(Freq.valueOf((byte) (spStartFreq.getSelectedItemPosition() + 7)))
                                .setFreqEnd(Freq.valueOf((byte) (spEndFreq.getSelectedItemPosition() + 7)))
                                .build();
                    }
//                    Hawk.put(Key.REGION_TYPE, false);
                    ReaderHelper.getReader().setFrequencyRegion(
                            freqNormal,
                            successConsumer,
                            failureConsumer);

                } else if (radioGroupCategory.getCheckedRadioButtonId() == R.id.rb_custom) {
                    FreqUserDefine freqUserDefine;
                    try {
                        freqUserDefine = new FreqUserDefine.Builder()
                                .setFreqStart(Integer.parseInt(etStartFreq.getText().toString()))
                                .setFreqInterval(Integer.parseInt(etFreqInterval.getText().toString()))
                                .setFreqQuantity((byte) Integer.parseInt(etFreqCount.getText().toString()))
                                .build();
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
//                    Hawk.put(Key.REGION_TYPE, true);
//                    Hawk.put(Key.START_FREQUENCY, freqUserDefine.getFreqStart());
//                    Hawk.put(Key.FREQUENCY_INTERVAL, freqUserDefine.getFreqInterval());

                    ReaderHelper.getReader().setUserDefineFrequency(
                            freqUserDefine,
                            successConsumer,
                            failureConsumer);
                }
                break;
            default:
        }
    }

    /**
     * 更新spinner数据
     *
     * @param checkedId 选中的id
     */
    private void changeData(int checkedId) {
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return;
        }
        float start;
        int i;
        String[] arr;
        if (checkedId == R.id.rb_ets) {
            start = 865.00f;
            arr = new String[7];
            for (i = 0; i < arr.length; i++) {
                String strTemp = String.format(getString(R.string.format_region), start);
                arr[i] = strTemp;
                start += 0.5f;
            }
        } else if (checkedId == R.id.rb_chn) {
            start = 920.00f;
            arr = new String[11];
            for (i = 0; i < arr.length; i++) {
                String strTemp = String.format(getString(R.string.format_region), start);
                arr[i] = strTemp;
                start += 0.5f;
            }
        } else {
            start = 902.00f;
            arr = new String[53];
            for (i = 0; i < arr.length; i++) {
                String strTemp = String.format(getString(R.string.format_region), start);
                arr[i] = strTemp;
                start += 0.5f;
            }
        }
        SpinnerAdapter adapter = new ArrayAdapter<>(activity, android.R.layout.simple_list_item_1, arr);
        spStartFreq.setAdapter(adapter);
        spEndFreq.setAdapter(adapter);
        spEndFreq.setSelection(adapter.getCount() - 1);
    }

    private void updateUi(FreqRegionResult bean) {
        FragmentActivity activity = getActivity();
        promptUi(getString(R.string.read_success));
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(() -> {
            if (bean.isUserDefine()) {
                FreqUserDefine freqUserDefine = bean.getFreqUserDefine();
                radioGroupCategory.check(R.id.rb_custom);
                etStartFreq.setText(String.valueOf(freqUserDefine.getFreqStart()));
                etFreqInterval.setText(String.valueOf(freqUserDefine.getFreqInterval()));
                etFreqCount.setText(String.valueOf((freqUserDefine.getFreqQuantity() & 0xFF)));
            } else {
                radioGroupCategory.check(R.id.rb_normal);
                FreqNormal freqNormal = bean.getFreqNormal();
                int startPos, endPos;
                if (freqNormal.getRegion() == Region.ETSI) {
                    radioGroupNormal.check(R.id.rb_ets);
                    startPos = freqNormal.getFreqStart().getValue() & 0xFF;
                    endPos = freqNormal.getFreqEnd().getValue() & 0xFF;
                } else if (freqNormal.getRegion() == Region.CHN) {
                    radioGroupNormal.check(R.id.rb_chn);
                    startPos = (freqNormal.getFreqStart().getValue() & 0xFF) - 43;
                    endPos = (freqNormal.getFreqEnd().getValue() & 0xFF) - 43;
                } else {
                    radioGroupNormal.check(R.id.rb_fcc);
                    startPos = (freqNormal.getFreqStart().getValue() & 0xFF) - 7;
                    endPos = (freqNormal.getFreqEnd().getValue() & 0xFF) - 7;
                }
                changeData(radioGroupNormal.getCheckedRadioButtonId());
                if (startPos >= 0 && startPos < spStartFreq.getCount()) {
                    spStartFreq.setSelection(startPos);
                }
                if (endPos >= 0 && endPos < spEndFreq.getCount()) {
                    spEndFreq.setSelection(endPos);
                }
            }
        });
    }

    /**
     * 提示
     *
     * @param msg msg
     */
    private void promptUi(String msg) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.runOnUiThread(() -> ToastUtils.makeText(clParent, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
