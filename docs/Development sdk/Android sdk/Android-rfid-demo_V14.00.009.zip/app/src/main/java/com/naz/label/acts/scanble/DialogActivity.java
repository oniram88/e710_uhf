package com.naz.label.acts.scanble;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.naz.label.R;
import com.naz.label.base.OldBaseActivity;

import butterknife.OnClick;

/**
 * 提示蓝牙断开的activity
 *
 * @author naz
 */
public class DialogActivity extends OldBaseActivity {

    @Override
    public int getLayoutResId() {
        return R.layout.activity_dialog;
    }

    @Override
    public void initView() {
        setFinishOnTouchOutside(false);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.height = WindowManager.LayoutParams.WRAP_CONTENT;
        params.width = (int) (getScreenWidth(this) * 0.85);
        getWindow().setAttributes(params);
    }

    /**
     * 获取屏幕宽度
     *
     * @param activity Activity
     * @return ScreenWidth
     */
    public static int getScreenWidth(Activity activity) {
        WindowManager manager = activity.getWindowManager();
        DisplayMetrics outMetrics = new DisplayMetrics();
        manager.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }

    @OnClick(R.id.tv_sure)
    public void onViewClicked() {
        getApplication().onTerminate();
    }
}
