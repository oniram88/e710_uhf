package com.naz.label;


import androidx.annotation.NonNull;

import com.payne.reader.base.TempLabel2Info;
import com.payne.reader.bean.config.AntennaCount;
import com.payne.reader.bean.send.InventoryParam;
import com.payne.reader.bean.send.MtEnableRtcMeasTemp;
import com.payne.reader.bean.send.MtReadMemory;
import com.payne.reader.bean.send.MtWriteMemory;
import com.payne.reader.communication.DataPacket;
import com.payne.reader.util.ArrayUtils;
import com.payne.reader.util.CheckUtils;
import com.payne.reader.util.ThreadPool;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    String str = new String("good");

    private void sleep(long sleepMs) {
        try {
            Thread.sleep(sleepMs);
        } catch (InterruptedException e) {
            System.out.println("finish:" + e.getMessage());
        }
    }

    @Test
    public void isCorrect() {
        Runnable command = new Runnable() {
            @Override
            public void run() {
                System.out.println("sleep...10000");
                sleep(10000);
                String name = Thread.currentThread().getName();
                System.out.println("run=" + name + "----------------");
            }

        };
        Thread t0 = new Thread(command);
        t0.start();
        sleep(1000);
        t0.interrupt();

        Thread thread = new Thread();
        thread.setName("Rfid-Read-");
        thread.start();
        System.out.println("---------------" + thread.getName());

        String strData = "12345678900012345678900012345678";
//        String strData1 = "12 34 56 78 90 00 12 34 56 78 90 00 12 34 56 78";
        byte[] btData = ArrayUtils.hexStringToBytes(strData);
//        byte[] btData1 = ArrayUtils.hexStrToByteArr(strData1, " ");
        System.out.println(Arrays.toString(btData));
//        System.out.println(Arrays.toString(btData1));
//        System.out.println(Integer.parseInt("12", 16));
//        System.out.println(Integer.parseInt("34", 16));
//
//        byte[] bytes = ArrayUtils.hexStringToBytes("1800");
//        int length = ArrayUtils.getEpcLengthByPC(bytes);
//        System.out.println(length);

//        byte readLen = (byte) ((btData.length >>> 1) + (btData.length & 0x01));
//
//        String text = String.format("%02X", readLen);
//        System.out.println(text);
//        System.out.println(ArrayUtils.CalcPC(6));
    }

    @Test
    public void addition_isCorrect() {
        // int length = 32 * 4;
        // byte selectLength = (byte) (length & 0xff);
        // System.out.println("l->" + selectLength);

//        byte[] bytes = ArrayUtils.toBinBytes(16);
//        String str = Integer.toBinaryString(22);


        byte[] coreBs = new byte[5];
        coreBs[0] = ArrayUtils.intToByteArray(100, 1)[0];
        byte[] bytes = ArrayUtils.intToByteArray(915000, 3);
        coreBs[1] = bytes[0];
        coreBs[2] = bytes[1];
        coreBs[3] = bytes[2];
        coreBs[4] = ArrayUtils.intToByteArray(20, 1)[0];
        DataPacket p = new DataPacket((byte) 0x01, (byte) 0xAC, coreBs);

        System.out.println(ArrayUtils.bytesToHexString(p.getData(), 0, p.getLen() + 2));
    }

    @Test
    public void test() throws InterruptedException {
        System.out.println((byte) 0x22);
//        LinkedBlockingQueue queue = new LinkedBlockingQueue(1);
//        queue.put("111");
//        System.out.println("put ok");
//        queue.put("222");
//        System.out.println("put ok");
//        boolean offer = queue.offer("333");
//        System.out.println("put ok? " + offer);

//        System.out.println(queue.take());
//        System.out.println("take ok size=" + queue.size());
        //        change(str, ch);
//        System.out.println(str);
//        System.out.println(ch);

//        System.out.println(ArrayUtils.CalcPC(1*4));
    }

    @Test
    public void testValid() {
        String str = "A0 05 01 72 22 05 C1";
        // String str = "A0 1E 01 81 00 21 15 30 00 33 B4 31 41 93 AD E2 80 68 94 4E 05 2C 11 1A 12 A0 18 01 81 00 21 0F";
        byte[] bytes = ArrayUtils.hexStrToByteArr(str, " ");

        byte checkSum = CheckUtils.getCheckSum(bytes, 0, bytes.length - 1);
        System.out.printf(" getCheckSum: %02X", checkSum);

        // int numLen = 1;
        //
        // byte[] strArr = new byte[numLen];
        // for (int i = 0; i < numLen; i++) {
        //     strArr[i] = bytes[3 - numLen + i];
        // }
        // System.out.println(ArrayUtils.bytesToHexString(strArr, 0, strArr.length));
    }

    @Test
    public void testHex() {
        byte[] bytes = ArrayUtils.hexStringToBytes("0001");
        System.out.println("->" + Arrays.toString(bytes));
        byte[] bytes1 = ArrayUtils.hexStringToBytes("1122");
        System.out.println("->" + Arrays.toString(bytes1));
        byte[] bytes11 = ArrayUtils.hexStringToBytes("4568");
        System.out.println("->" + Arrays.toString(bytes11));
        byte[] bytes111 = ArrayUtils.hexStringToBytes("0011");
        System.out.println("->" + Arrays.toString(bytes111));

        int i = ArrayUtils.byteArrayToInt(bytes111, 0, bytes111.length);
        System.out.println(i);

        byte[] bs = ArrayUtils.toBinBytes(4);
        System.out.println(Arrays.toString(bs));
        String s = Integer.toBinaryString(4);
        System.out.println(s);
    }

    public static int bitToInt(@NonNull byte[] bytes, int bit) {
        return (int) ((byte2ToUnsignedShort(bytes, 0) << (32 - bit)) / Math.pow(2, 32 - bit));
    }

    public static int byte2ToUnsignedShort(byte[] bytes, int off) {
        int high = bytes[off];
        int low = bytes[off + 1];
        return (high << 8 & 0xFF00) | (low & 0xFF);
    }

    @Test
    public void testTemp() {
//        onXYData("59 D2 0F F2 1F FF");
//        System.out.println(String.class);

        str = "69 40 04 3F 69 40 05 BF 69 40 06 BF 69 40 07 3F 69 40 08 3F 69 40 09 BF 69 40 0A BF 69 40 0B 3F";
        byte[] bytes = ArrayUtils.hexStrToByteArr(str, " ");
        int count = 41;
        int len = count % 8 == 0 ? 8 : count / 8;

        for (int i = 0; i < len; i++) {
            byte[] point = new byte[]{bytes[i * 4 + 1], bytes[i * 4]};
            System.out.println(i + "," + bitToInt(point, 10) / 4.0);
        }
        MtEnableRtcMeasTemp build = new MtEnableRtcMeasTemp.Builder()
                .setPasswords("99000066")
                .setDelayMeasTime(1)
                .setMeasInterval(2)
                .setTempMax(9)
                .setTempMin(6)
                .setMeasCount(3)
                .build();
//        MtReadMemory build = new MtReadMemory.Builder()
//                .setPasswords("01020304")
//                .setAuthPwd("06070809")
//                .setStartAddress(0x10)
//                .setLength(0x20)
//                .build();
//        byte[] b = new byte[]{0x06, 0x06, 0x06, 0x06};
//        MtWriteMemory build = new MtWriteMemory.Builder()
//                .setPasswords("01020304")
//                .setAuthPwd("06070809")
//                .setStartAddress(0x10)
//                .setCount(0x04)
//                .setData(b)
//                .build();
        byte[] info = build.getTempLabel2Info();
        System.out.println(ArrayUtils.bytesToHexString(info, 0, info.length));
        DataPacket dataPacket = new DataPacket((byte) 0xff, (byte) 0xfd, info);
        System.out.println(dataPacket);
    }

    private double p1 = 0.0001517;
    private double p2 = -0.003199;
    private double p3 = 1.557;
    private double p4 = -62.8;
    private double p11 = 0.003351;
    private double p22 = -0.7194;
    private double p33 = 54.94;
    private double p44 = -1388.07;

    private void onXYData(String strEpc) {
        strEpc = strEpc.replace(" ", "");
        byte[] bytes = ArrayUtils.hexStringToBytes(strEpc);

        int srcPos = bytes.length - 4;
        if (srcPos < 0) {
            return;
        }
        byte[] tmpBytes = new byte[4];
        System.arraycopy(bytes, srcPos, tmpBytes, 0, 4);
        int Adc = ArrayUtils.byteArrayToInt(tmpBytes, 0, 2, true);
        String end3Str = strEpc.substring(strEpc.length() - 3);
        int Cali = Integer.parseInt(end3Str, 16) - 256;
        double xAdc = (Adc - Cali) / 100.00 + 10;
        double temp;
        if ((Adc - Cali) < 6052) {
            temp = p1 * xAdc * xAdc * xAdc + p2 * xAdc * xAdc + p3 * xAdc + p4;
        } else {
            temp = p11 * xAdc * xAdc * xAdc + p22 * xAdc * xAdc + p33 * xAdc + p44;
        }
        System.out.println(strEpc + "\nTemp = " + temp + ",end3Str =" + end3Str + ", Adc = " + Adc + ", Cali = " + Cali + ", xAdc = " + xAdc);
    }
}