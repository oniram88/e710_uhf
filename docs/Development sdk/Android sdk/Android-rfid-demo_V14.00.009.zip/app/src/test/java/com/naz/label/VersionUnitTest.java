package com.naz.label;

import com.payne.reader.bean.config.ResultCode;
import com.payne.reader.bean.receive.Version;
import com.payne.reader.communication.DataPacket;
import com.payne.reader.util.ArrayUtils;
import com.payne.reader.util.CheckUtils;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class VersionUnitTest {
    private StringBuilder mSb = new StringBuilder();
    Formatter mFormatter = new Formatter(mSb);

    @Test
    public void testValid() {
        byte lByte = -64;
        byte rByte = 31;
        short result = (short) (lByte << 8 | 255 & rByte);
        String str = mFormatter.format("%X", result).toString();
        mSb.setLength(0);
        str = mFormatter.format("%X", result).toString();
        String hexStr = Integer.toHexString(result);
        System.out.println(str + " - " + hexStr);


        System.out.println("ms: " + formatSeconds(7 * 60 * 60 * 1000 + 5 * 60 * 1000));
    }

    public String formatSeconds(long totalSeconds) {
        totalSeconds = totalSeconds / 1000;
        if (totalSeconds < 1) {
            return "00:01";
        }

        long hours = totalSeconds / 3600;

        long rem = totalSeconds % 3600;
        long minutes = rem / 60;
        long seconds = rem % 60;
        if (minutes == 0 && hours == 0) {
            return String.format("%02ds", seconds);
        }
        if (hours == 0) {
            return String.format("%02dm:%02ds", minutes, seconds);
        }
        return String.format("%02dh:%02dm:%02ds", hours, minutes, seconds);
    }
}